package com.wextra.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.net.HttpURLConnection
import java.util.Locale
import org.json.JSONArray
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import kotlinx.coroutines.delay
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.random.Random
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.app.Activity
import android.media.ToneGenerator
import android.media.AudioManager

private val Background = androidx.compose.ui.graphics.Color(0xFF07101F)
private val Surface = androidx.compose.ui.graphics.Color(0xFF101E31)
private val Accent = androidx.compose.ui.graphics.Color(0xFF6572FF)
private val TextMuted = androidx.compose.ui.graphics.Color(0xFF9EABC0)
private val CategoryColors = listOf(
    Color(0xFF39D6A3),
    Color(0xFF8B7BFF),
    Color(0xFFFF7AA8),
    Color(0xFFFFB457),
    Color(0xFF4CB7FF)
)

// WEXTRA HOME FEATURE UPDATE MARKER
// Keşfet: kullanıcı gönderilerinin yayınlanacağı Community/Keşfet alanı.
// Popüler: kategori yerine beğeni sayısına göre sıralanan Top 50 alanı.
// Sol üst giriş: Premium/Fiyatlandırma alanı.

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WextraTheme { WextraApp() } }
    }
}

@Composable
fun WextraTheme(
    theme: ThemeOption = ThemeOption("Gece Mor", Accent, Background, Surface, Color.White, true),
    accentOverride: Color? = null,
    textOverride: Color? = null,
    content: @Composable () -> Unit
) {
    val uiAccent = accentOverride ?: theme.accent
    val uiText = textOverride ?: theme.text
    val scheme = if (theme.dark) darkColorScheme(
        primary = uiAccent,
        secondary = uiAccent,
        tertiary = uiAccent,
        primaryContainer = uiAccent.copy(alpha = 0.18f),
        secondaryContainer = uiAccent.copy(alpha = 0.14f),
        background = theme.background,
        surface = theme.surface,
        onPrimary = if (theme.dark) Color.White else Color.White,
        onBackground = uiText,
        onSurface = uiText,
        onSurfaceVariant = uiText.copy(alpha = 0.70f)
    ) else lightColorScheme(
        primary = uiAccent,
        secondary = uiAccent,
        tertiary = uiAccent,
        primaryContainer = uiAccent.copy(alpha = 0.18f),
        secondaryContainer = uiAccent.copy(alpha = 0.14f),
        background = theme.background,
        surface = theme.surface,
        onPrimary = Color.White,
        onBackground = uiText,
        onSurface = uiText,
        onSurfaceVariant = uiText.copy(alpha = 0.65f)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String? = null,
    val localResId: Int? = null,
    val resolutionLabel: String? = "4K",
    val likes: Int = 0,
    val views: Int = 0
)

data class ResolutionOption(val label: String, val detail: String, val width: Int)
data class ThemeOption(
    val name: String,
    val accent: Color,
    val background: Color,
    val surface: Color,
    val text: Color,
    val dark: Boolean
)

class WallpaperViewModel : androidx.lifecycle.ViewModel() {
    private val wallpapersKey = "favorite_wallpapers"

    // Her kategori için 20 adet yerel, yüksek çözünürlüklü görsel.
    // Görseller Firebase Storage'a yüklenmez; doğrudan görsel bağlantıları kullanılır.
    val wallpapers = mutableStateListOf<Wallpaper>().apply {
        addAll(seedWallpapers())
    }

    private fun seedWallpapers(): List<Wallpaper> {
        // Uygulamada yalnızca eklenen 9 özel İstanbul duvar kâğıdı kullanılır.
        val items = listOf(
            Triple("Yıldızlı İstanbul", "Yıldızlar", "wp_istanbul_01.jpg"),
            Triple("Boğazda Gün Batımı", "Şehir", "wp_istanbul_02.jpg"),
            Triple("Gece Şehir Işıkları", "Şehir", "wp_istanbul_03.jpg"),
            Triple("Boğaz Köprüsü", "Mimari", "wp_istanbul_04.jpg"),
            Triple("Galata ve Martılar", "Şehir", "wp_istanbul_05.jpg"),
            Triple("Kız Kulesi Gün Batımı", "Şehir", "wp_istanbul_06.jpg"),
            Triple("Mor Boğaz Gecesi", "Şehir", "wp_istanbul_07.jpg"),
            Triple("İstanbul Neon", "Minimal", "wp_istanbul_08.jpg"),
            Triple("İstanbul Gün Batımı", "Doğa", "wp_istanbul_09.jpg")
        )
        return items.mapIndexed { index, (title, category, assetName) ->
            Wallpaper(
                id = "istanbul_$index",
                title = title,
                category = category,
                imageUrl = "file:///android_asset/wallpapers/$assetName"
            )
        }
    }

    val resolutions = listOf(
        ResolutionOption("1080P", "FHD", 1080),
        ResolutionOption("2K", "1440p", 1440),
        ResolutionOption("4K", "2160p", 2160),
        ResolutionOption("8K", "4320p", 4320)
    )
    val categories = listOf("Doğa", "Yıldızlar", "Şehir", "Araçlar", "Minimal", "Soyut", "Oyun", "Hayvanlar", "Mimari")

    var selectedResolution by mutableStateOf(resolutions[2])
        private set
    fun selectResolution(option: ResolutionOption) { selectedResolution = option }

    var favorites by mutableStateOf(setOf<String>())
        private set
    var recentIds by mutableStateOf<List<String>>(emptyList())
        private set
    var collections by mutableStateOf<Map<String, Set<String>>>(emptyMap())
        private set
    var likeCounts by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var viewCounts by mutableStateOf<Map<String, Int>>(emptyMap())
        private set
    var randomWallpaperId by mutableStateOf(wallpapers.first().id)
        private set

    fun loadFavorites(context: Context) {
        val prefs = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        favorites = prefs.getStringSet(wallpapersKey, emptySet()) ?: emptySet()
        recentIds = prefs.getString("recent_ids", "")!!.split("|").filter { it.isNotBlank() }
        val names = prefs.getString("collection_names", "")!!.split("|").filter { it.isNotBlank() }
        collections = names.associateWith { name -> prefs.getStringSet("collection_" + name, emptySet()) ?: emptySet() }
        likeCounts = wallpapers.associate { it.id to prefs.getInt("likes_"+it.id, it.likes) }
        viewCounts = wallpapers.associate { it.id to prefs.getInt("views_"+it.id, it.views) }
    }
    fun recordView(id: String, context: Context) {
        val next = (viewCounts[id] ?: 0) + 1
        viewCounts = viewCounts + (id to next)
        recentIds = (listOf(id) + recentIds.filter { it != id }).take(50)
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit()
            .putInt("views_"+id,next).putString("recent_ids",recentIds.joinToString("|")).apply()
    }
    fun likeCount(id:String)=likeCounts[id] ?: wallpapers.firstOrNull{it.id==id}?.likes ?: 0
    fun viewCount(id:String)=viewCounts[id] ?: wallpapers.firstOrNull{it.id==id}?.views ?: 0
    fun toggleLike(id:String, context:Context) {
        val was = id in favorites
        toggleFavorite(id, context)
        val next = ((likeCounts[id] ?: 0) + if(was) -1 else 1).coerceAtLeast(0)
        likeCounts = likeCounts + (id to next)
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit().putInt("likes_"+id,next).apply()
    }
    fun createCollection(name:String, context:Context) {
        val clean=name.trim(); if(clean.isBlank() || collections.containsKey(clean)) return
        collections = collections + (clean to emptySet())
        saveCollections(context)
    }
    fun toggleInCollection(name:String,id:String,context:Context){
        val set=collections[name] ?: emptySet()
        collections=collections + (name to if(id in set) set-id else set+id)
        saveCollections(context)
    }
    private fun saveCollections(context:Context){
        val e=context.getSharedPreferences("wextra_prefs",Context.MODE_PRIVATE).edit().putString("collection_names",collections.keys.joinToString("|"))
        collections.forEach{(n,ids)->e.putStringSet("collection_"+n,ids)}; e.apply()
    }
    fun toggleFavorite(id: String, context: Context) {
        favorites = if (id in favorites) favorites - id else favorites + id
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit().putStringSet(wallpapersKey, favorites).apply()
    }
    fun pickRandom() { if (wallpapers.isNotEmpty()) randomWallpaperId = wallpapers.random().id }
    fun dailyWallpaper(): Wallpaper {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        return wallpapers[day % wallpapers.size]
    }
    fun imageFor(item: Wallpaper): Any {
        item.localResId?.let { return it }
        val url = item.imageUrl ?: ""
        if (url.startsWith("file:///android_asset/")) return url
        return url.substringBefore("?") + "?auto=format&fit=crop&w=${selectedResolution.width}&q=90"
    }
    fun addWallpaper(title: String, category: String, imageUrl: String, resolution: ResolutionOption) {
        if (title.isBlank() || imageUrl.isBlank()) return
        wallpapers.add(0, Wallpaper("custom_${System.currentTimeMillis()}", title.trim(), category, imageUrl.trim(), resolutionLabel = resolution.label))
        selectedResolution = resolution
    }

    var themeDark by mutableStateOf(true); private set
    var themeIndex by mutableStateOf(0); private set
    var accentIndex by mutableStateOf(0); private set
    var textColorIndex by mutableStateOf(0); private set
    var wifiOnly by mutableStateOf(true); private set
    var animationsEnabled by mutableStateOf(true); private set
    var notificationsEnabled by mutableStateOf(true); private set
    var dailyEnabled by mutableStateOf(true); private set
    var language by mutableStateOf("Türkçe"); private set
    var currentUserEmail by mutableStateOf<String?>(null); private set
    var currentUserName by mutableStateOf("Wextra Kullanıcı"); private set
    var isAdmin by mutableStateOf(false); private set

    // Tema: uygulamanın genel arka plan ve kart görünümü.
    // Renk Teması ve Yazı Rengi aşağıdaki ayrı ayarlardan bağımsızdır.
    // Eclipse logosuyla uyumlu, koyu WEXTRA paleti. Tema değişse bile yüzeyler
    // logonun lacivert tabanını korur; vurgu rengi kontrollü biçimde değişir.
    val themeOptions = listOf(
        ThemeOption("Gece Eclipse", Color(0xFF9B5CFF), Color(0xFF050711), Color(0xFF0D1224), Color.White, true),
        ThemeOption("Okyanus Eclipse", Color(0xFF35BFFF), Color(0xFF040A15), Color(0xFF0A1728), Color.White, true),
        ThemeOption("Pembe Eclipse", Color(0xFFFF4FD8), Color(0xFF090510), Color(0xFF180D22), Color.White, true),
        ThemeOption("Turkuaz Eclipse", Color(0xFF21D4FF), Color(0xFF030A11), Color(0xFF0A1720), Color.White, true),
        ThemeOption("Gün Işığı", Color(0xFF7C5CFF), Color(0xFFF5F4FF), Color(0xFFFFFFFF), Color(0xFF16142A), false)
    )

    val accentOptions = listOf(
        "Eclipse Mor" to Color(0xFF9B5CFF),
        "Eclipse Mavi" to Color(0xFF3B82FF),
        "Eclipse Pembe" to Color(0xFFFF4FD8),
        "Eclipse Kırmızı" to Color(0xFFFF5570),
        "Eclipse Turuncu" to Color(0xFFFF9B4A),
        "Eclipse Sarı" to Color(0xFFFFD45C),
        "Eclipse Yeşil" to Color(0xFF46E6A5),
        "Eclipse Turkuaz" to Color(0xFF29D9FF),
        "Dinamik" to Color(0xFFB06CFF)
    )
    val textColorOptions = listOf(
        "Eclipse Beyaz" to Color(0xFFF8F7FF),
        "Lavanta" to Color(0xFFE2D7FF),
        "Buz Mavisi" to Color(0xFFD8ECFF),
        "Neon Turkuaz" to Color(0xFFBFF8FF),
        "Yumuşak Pembe" to Color(0xFFFFDDF5)
    )
    val currentTheme: ThemeOption get() = themeOptions[themeIndex]
    val currentAccent: Color get() = accentOptions[accentIndex].second
    val currentTextColor: Color get() = textColorOptions[textColorIndex].second

    fun loadAppState(context: Context) {
        val p = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        themeIndex = p.getInt("theme_index", 0).coerceIn(0, themeOptions.lastIndex)
        themeDark = themeOptions[themeIndex].dark
        accentIndex = p.getInt("accent_index", 0).coerceIn(0, accentOptions.lastIndex)
        textColorIndex = p.getInt("text_color_index", 0).coerceIn(0, textColorOptions.lastIndex)
        wifiOnly = p.getBoolean("wifi_only", true); animationsEnabled = p.getBoolean("animations", true)
        notificationsEnabled = p.getBoolean("notifications", true); dailyEnabled = p.getBoolean("daily", true)
        language = p.getString("language", "Türkçe") ?: "Türkçe"
        currentUserEmail = p.getString("current_email", null)
        currentUserName = p.getString("current_name", "Wextra Kullanıcı") ?: "Wextra Kullanıcı"
        isAdmin = p.getBoolean("current_admin", false)
    }
    private fun save(context: Context) { context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit()
        .putBoolean("theme_dark", themeDark).putInt("theme_index", themeIndex).putInt("accent_index", accentIndex).putInt("text_color_index", textColorIndex).putBoolean("wifi_only", wifiOnly)
        .putBoolean("animations", animationsEnabled).putBoolean("notifications", notificationsEnabled).putBoolean("daily", dailyEnabled)
        .putString("language", language).putString("current_email", currentUserEmail).putString("current_name", currentUserName)
        .putBoolean("current_admin", isAdmin).apply() }
    fun setThemeChoice(i:Int,c:Context){
        themeIndex=i.coerceIn(0, themeOptions.lastIndex)
        themeDark=themeOptions[themeIndex].dark
        save(c)
    }
    fun setAccent(i:Int,c:Context){ accentIndex=i; save(c) }
    fun setTextColor(i:Int,c:Context){ textColorIndex=i; save(c) }
    fun tr(tr:String,en:String):String = if(language=="English") en else tr
    fun setWifi(v:Boolean,c:Context){ wifiOnly=v; save(c) }
    fun setAnimations(v:Boolean,c:Context){ animationsEnabled=v; save(c) }
    fun setNotifications(v:Boolean,c:Context){ notificationsEnabled=v; save(c) }
    fun setDaily(v:Boolean,c:Context){ dailyEnabled=v; save(c) }
    fun setLanguage(v:String,c:Context){ language=v; save(c) }
    fun signIn(email:String,name:String,admin:Boolean,c:Context){ currentUserEmail=email; currentUserName=name; isAdmin=admin; save(c) }
    fun updateName(name: String, c: Context) { currentUserName = name; save(c) }
    fun signOut(c:Context){ FirebaseAuth.getInstance().signOut(); currentUserEmail=null; currentUserName="Wextra Kullanıcı"; isAdmin=false; save(c) }
    fun logout(c: Context) = signOut(c)
}
@Composable
fun WextraApp(vm: WallpaperViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { vm.loadFavorites(context); vm.loadAppState(context) }
    WextraTheme(theme = vm.currentTheme, accentOverride = vm.currentAccent, textOverride = vm.currentTextColor) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = "splash") {
            composable("splash") { SplashScreen(vm) { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
            composable("home") { MainScaffold(nav, vm, "home") { HomeScreen(vm, nav) } }
            composable("latest") { LatestScreen(vm, nav) }
            composable("swipe") { SwipeScreen(vm, nav) }
            composable("colors") { ColorExploreScreen(vm, nav) }
            composable("categories") { MainScaffold(nav, vm, "categories") { CategoriesScreen(vm, nav) } }
            composable("categoriesList") { CategoryListScreen(vm, nav) }
            composable("popular") { PopularScreen(vm, nav) }
            composable("community") { CommunityScreen(vm, nav) }
            composable("category/{name}", arguments = listOf(navArgument("name") { type = NavType.StringType })) {
                CategoryWallpapersScreen(it.arguments?.getString("name").orEmpty(), vm, nav)
            }
            composable("favorites") { MainScaffold(nav, vm, "favorites") { FavoritesScreen(vm, nav) } }
            composable("profile") { MainScaffold(nav, vm, "profile") { ProfileScreen(nav, vm) } }
            composable("pro") { ProScreen(nav, vm) }
            composable("history") { HistoryScreen(vm, nav) }
            composable("collections") { CollectionsScreen(vm, nav) }
            composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                val item = vm.wallpapers.first { w -> w.id == it.arguments?.getString("id") }
                DetailScreen(item, vm, item.id in vm.favorites, { vm.toggleLike(item.id, context) }, nav)
            }
            composable("login") { LoginScreen(nav, vm) }
            composable("register") { RegisterScreen(nav, vm) }
            composable("settings") { MainScaffold(nav, vm, "settings") { SettingsScreen(nav, vm) } }
            composable("settingsAppearance") { SettingsDetailScaffold(nav, vm, "Görünüm") { AppearanceSettingsScreen(nav, vm) } }
            composable("settingsWallpaper") { SettingsDetailScaffold(nav, vm, "Duvar Kâğıdı") { WallpaperSettingsScreen(nav, vm) } }
            composable("settingsNotifications") { SettingsDetailScaffold(nav, vm, "Bildirimler") { NotificationSettingsScreen(nav, vm) } }
            composable("settingsPreferences") { SettingsDetailScaffold(nav, vm, "İçerik Tercihleri") { ContentPreferencesScreen(nav, vm) } }
            composable("settingsAccount") { SettingsDetailScaffold(nav, vm, "Hesap ve Veri") { AccountSettingsScreen(nav, vm) } }
            composable("settingsPrivacy") { SettingsDetailScaffold(nav, vm, "Gizlilik ve Güvenlik") { PrivacySettingsScreen(nav, vm) } }
            composable("settingsAbout") { SettingsDetailScaffold(nav, vm, "Uygulama Hakkında") { AboutSettingsScreen(nav, vm) } }
            composable("adminLogin") { AdminLoginScreen(nav, vm) }
            composable("admin") { AdminScreen(nav, vm) }
            composable("adminAdd") { AdminAddWallpaperScreen(nav, vm) }
        }
    }
}
@Composable
fun SplashScreen(vm: WallpaperViewModel, onStart: () -> Unit) {
    /*
     * WEXTRA uygulama içi tanıtım ekranı.
     * 4 sayfa yatay olarak kaydırılır; alttaki noktalar gerçek pager durumuna bağlıdır.
     * Son sayfadaki "Başla" ile ana sayfaya geçilir.
     */
    val accent = vm.currentAccent
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { 4 })
    val wallpapers = vm.wallpapers
    val featured = wallpapers.firstOrNull { it.category == "Yıldızlar" } ?: wallpapers.firstOrNull()
    val nature = wallpapers.firstOrNull { it.category == "Doğa" } ?: featured
    val city = wallpapers.firstOrNull { it.category == "Şehir" } ?: featured
    val abstract = wallpapers.firstOrNull { it.category == "Soyut" } ?: featured

    val pages = listOf(
        IntroPageData(
            title = vm.tr("WEXTRA'YA HOŞ GELDİN", "WELCOME TO WEXTRA"),
            subtitle = vm.tr("Ekranını kendi tarzınla yeniden keşfet.", "Rediscover your screen with your own style."),
            kicker = vm.tr("SINIRSIZ GÖRSEL DÜNYA", "LIMITLESS VISUAL WORLD"),
            icon = Icons.Default.AutoAwesome,
            image = featured?.let { vm.imageFor(it) }
        ),
        IntroPageData(
            title = vm.tr("TARZINI KEŞFET", "DISCOVER YOUR STYLE"),
            subtitle = vm.tr("Doğa, şehir, uzay ve daha onlarca kategori seni bekliyor.", "Nature, cities, space and dozens of categories are waiting for you."),
            kicker = vm.tr("SANA UYGUN KATEGORİLER", "CATEGORIES FOR YOU"),
            icon = Icons.Default.Explore,
            image = nature?.let { vm.imageFor(it) }
        ),
        IntroPageData(
            title = vm.tr("SEVDİKLERİN HEP YANINDA", "KEEP WHAT YOU LOVE"),
            subtitle = vm.tr("Favorilerini kaydet, koleksiyon oluştur ve istediğine anında dön.", "Save favorites, create collections and return anytime."),
            kicker = vm.tr("KİŞİSEL ALANIN", "YOUR PERSONAL SPACE"),
            icon = Icons.Default.FavoriteBorder,
            image = abstract?.let { vm.imageFor(it) }
        ),
        IntroPageData(
            title = vm.tr("EKRANINI YENİLE", "REFRESH YOUR SCREEN"),
            subtitle = vm.tr("Yüksek kaliteli duvar kâğıtlarını keşfet ve WEXTRA deneyimine başla.", "Explore high-quality wallpapers and start your WEXTRA experience."),
            kicker = vm.tr("HAZIRSIN", "YOU'RE READY"),
            icon = Icons.Default.HighQuality,
            image = city?.let { vm.imageFor(it) }
        )
    )

    Box(
        Modifier.fillMaxSize().background(Color(0xFF03030B))
    ) {
        // Uygulamanın mevcut mor/pembe/mavi neon atmosferi.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0xFF03030B), Color(0xFF06051A), Color(0xFF02030A))
                )
            )
        )
        Box(
            Modifier.fillMaxWidth().height(430.dp).align(Alignment.TopCenter).background(
                Brush.radialGradient(
                    listOf(accent.copy(alpha = .28f), Color(0xFF160B3B).copy(alpha = .20f), Color.Transparent)
                )
            )
        )
        Box(
            Modifier.fillMaxWidth().height(300.dp).align(Alignment.BottomCenter).background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF6D32FF).copy(alpha=.12f), Color(0xFFE6007D).copy(alpha=.16f), Color(0xFF147CFF).copy(alpha=.10f))
                )
            )
        )

        Column(
            Modifier.fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Sabit üst kimlik alanı; içerik uzunluğundan etkilenmez.
            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text("W", color = Color(0xFF9A42FF), fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("EXTRA", color = MaterialTheme.colorScheme.onBackground, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                beyondViewportPageCount = 1
            ) { page ->
                IntroOnboardingPage(
                    page = pages[page],
                    vm = vm,
                    accent = accent,
                    pageIndex = page,
                    totalPages = pages.size
                )
            }

            // Etkin noktalar: sayfa değiştikçe gerçek zamanlı güncellenir ve dokunularak da sayfa değiştirilebilir.
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(pages.size) { index ->
                    val selected = pagerState.currentPage == index
                    Box(
                        Modifier
                            .padding(horizontal = 5.dp)
                            .height(8.dp)
                            .width(if (selected) 30.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (selected) accent else MaterialTheme.colorScheme.onBackground.copy(alpha = .18f))
                            .clickable { scope.launch { pagerState.animateScrollToPage(index) } }
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth().height(64.dp)
                    .clickable {
                        scope.launch {
                            if (pagerState.currentPage < pages.lastIndex) {
                                pagerState.animateScrollToPage(pagerState.currentPage + 1)
                            } else {
                                onStart()
                            }
                        }
                    },
                shape = RoundedCornerShape(34.dp),
                color = Color.Transparent,
                border = BorderStroke(1.dp, Color.White.copy(alpha = .36f))
            ) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF7228FF), Color(0xFFE6007D), Color(0xFFFF7A38))
                        )
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            if (pagerState.currentPage == pages.lastIndex) vm.tr("WEXTRA'YI KEŞFET", "START EXPLORING") else vm.tr("DEVAM ET", "CONTINUE"),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            letterSpacing = .4.sp
                        )
                        Icon(
                            if (pagerState.currentPage == pages.lastIndex) Icons.Default.RocketLaunch else Icons.Default.ArrowForward,
                            null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (pagerState.currentPage == pages.lastIndex) vm.tr("Hazırsın. Keşfetmeye başla.", "You're ready. Start exploring.") else vm.tr("Yana kaydırarak tanıtıma devam et.", "Swipe sideways to continue the tour."),
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = .58f),
                fontSize = 12.sp
            )
        }
    }
}

private data class IntroPageData(
    val title: String,
    val subtitle: String,
    val kicker: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val image: Any?
)

@Composable
private fun IntroOnboardingPage(
    page: IntroPageData,
    vm: WallpaperViewModel,
    accent: Color,
    pageIndex: Int,
    totalPages: Int
) {
    val titleColor = MaterialTheme.colorScheme.onBackground
    val imageShape = RoundedCornerShape(34.dp)

    Column(
        Modifier.fillMaxSize().padding(top = 18.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().height(310.dp),
            shape = imageShape,
            color = Color(0xFF0B0B1B),
            border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(accent.copy(alpha=.95f), Color(0xFFE73A9D).copy(alpha=.75f), Color(0xFF1A8CFF).copy(alpha=.75f))))
        ) {
            Box(Modifier.fillMaxSize()) {
                if (page.image != null) {
                    AsyncImage(
                        model = page.image,
                        contentDescription = page.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        alpha = .86f
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF26105D), Color(0xFF0A1231), Color(0xFF25051F)))))
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF060611).copy(alpha=.28f), Color(0xFF060611).copy(alpha=.90f)))))

                Surface(
                    modifier = Modifier.padding(18.dp).align(Alignment.TopStart),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF090A18).copy(alpha=.72f),
                    border = BorderStroke(1.dp, accent.copy(alpha=.55f))
                ) {
                    Row(Modifier.padding(horizontal=12.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(page.icon, null, tint=accent, modifier=Modifier.size(18.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(page.kicker, color=Color.White, fontSize=10.sp, fontWeight=FontWeight.Bold, letterSpacing=.5.sp)
                    }
                }

                Text(
                    text = "${pageIndex + 1} / $totalPages",
                    modifier = Modifier.padding(18.dp).align(Alignment.TopEnd),
                    color = Color.White.copy(alpha=.75f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        Surface(
            modifier = Modifier.size(72.dp),
            shape = CircleShape,
            color = accent.copy(alpha=.14f),
            border = BorderStroke(1.dp, accent.copy(alpha=.68f))
        ) {
            Box(contentAlignment=Alignment.Center) {
                Icon(page.icon, null, tint=accent, modifier=Modifier.size(34.dp))
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            page.title,
            color = titleColor,
            fontSize = 28.sp,
            lineHeight = 34.sp,
            fontWeight = FontWeight.Black,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            page.subtitle,
            color = titleColor.copy(alpha=.68f),
            fontSize = 15.sp,
            lineHeight = 22.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal=14.dp)
        )
    }
}

@Composable
private fun IntroReferenceCard(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    image: String?,
    vm: WallpaperViewModel
) {
    Surface(
        modifier = modifier.height(280.dp),
        shape = RoundedCornerShape(28.dp),
        color = Color(0xFF080815).copy(alpha=.90f),
        border = BorderStroke(1.dp, Color(0xFF9D38FF).copy(alpha=.75f))
    ) {
        Box(Modifier.fillMaxSize()) {
            if (image != null) {
                AsyncImage(
                    model=image, contentDescription=null,
                    modifier=Modifier.fillMaxSize().padding(top=74.dp).clip(RoundedCornerShape(bottomStart=28.dp,bottomEnd=28.dp)),
                    contentScale=ContentScale.Crop, alpha=.70f
                )
            }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF080815).copy(alpha=.12f), Color(0xFF080815).copy(alpha=.96f)))))
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Surface(Modifier.size(50.dp), shape=RoundedCornerShape(14.dp), color=Color(0xFF15112C).copy(alpha=.9f), border=BorderStroke(1.dp, vm.currentAccent.copy(alpha=.75f))) {
                    Box(contentAlignment=Alignment.Center) { Icon(icon, null, tint=Color(0xFFB84CFF), modifier=Modifier.size(27.dp)) }
                }
                Spacer(Modifier.weight(1f))
                Text(title, fontWeight=FontWeight.Bold, fontSize=17.sp)
                Spacer(Modifier.height(10.dp))
                Text(body, color=Color.White.copy(alpha=.68f), fontSize=12.sp, lineHeight=20.sp)
            }
        }
    }
}

@Composable
private fun IntroTile(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    vm: WallpaperViewModel
) {
    Surface(
        modifier=modifier.height(112.dp),
        shape=RoundedCornerShape(22.dp),
        color=Color(0xFF0D132A).copy(alpha=.88f),
        border=BorderStroke(1.dp, Color.White.copy(alpha=.08f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint=vm.currentAccent, modifier=Modifier.size(24.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontSize=14.sp, fontWeight=FontWeight.Bold)
            Text(subtitle, fontSize=10.sp, color=TextMuted, maxLines=1)
        }
    }
}

@Composable
private fun IntroWideTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    vm: WallpaperViewModel
) {
    Surface(
        modifier=Modifier.fillMaxWidth().height(76.dp),
        shape=RoundedCornerShape(22.dp),
        color=Color(0xFF111633).copy(alpha=.9f),
        border=BorderStroke(1.dp, vm.currentAccent.copy(alpha=.18f))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalAlignment=Alignment.CenterVertically) {
            Surface(Modifier.size(44.dp), shape=CircleShape, color=vm.currentAccent.copy(alpha=.16f)) {
                Box(contentAlignment=Alignment.Center) { Icon(icon, null, tint=vm.currentAccent) }
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight=FontWeight.Bold, fontSize=15.sp)
                Text(subtitle, color=TextMuted, fontSize=11.sp)
            }
        }
    }
}

@Composable
private fun IntroFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Column(
        modifier = Modifier.width(100.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(76.dp),
            shape = CircleShape,
            color = Color(0xFF071021).copy(alpha = .76f),
            border = BorderStroke(1.dp, Color(0xFF7B78FF).copy(alpha = .36f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    null,
                    modifier = Modifier.size(32.dp),
                    tint = Accent
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color(0xFFE7E7F0), fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Color(0xFFB9BBC8), fontSize = 13.sp)
    }
}


@Composable
fun MainScaffold(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, selected: String, content: @Composable () -> Unit) {
    Scaffold(
        containerColor = Color(0xFF05050B),
        bottomBar = {
            Surface(
                color = Color(0xFF090A15),
                border = BorderStroke(1.dp, Color.White.copy(alpha = .08f)),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().height(78.dp).padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    fun Modifier.navItem(route: String) = this.weight(1f).fillMaxHeight()
                    BottomNavItem("home", vm.tr("Ana Sayfa","Home"), Icons.Default.Home, selected, nav, Modifier.navItem("home"))
                    BottomNavItem("categories", vm.tr("Keşfet","Explore"), Icons.Default.Explore, selected, nav, Modifier.navItem("categories"))
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clickable {
                            if (selected != "home") nav.navigate("home") { launchSingleTop = true }
                        },
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            modifier = Modifier.size(58.dp).offset(y = (-12).dp),
                            shape = CircleShape,
                            color = Color(0xFF090A15),
                            border = BorderStroke(2.dp, Brush.linearGradient(listOf(Color(0xFF7D35FF), Color(0xFFFF5A35), Color(0xFF18BFFF))))
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.wextra_logo),
                                contentDescription = "Wextra",
                                modifier = Modifier.fillMaxSize().padding(5.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                    BottomNavItem("profile", vm.tr("Profil","Profile"), Icons.Default.PersonOutline, selected, nav, Modifier.navItem("profile"))
                    BottomNavItem("settings", vm.tr("Ayarlar","Settings"), Icons.Default.Settings, selected, nav, Modifier.navItem("settings"))
                }
            }
        }
    ) { padding -> Box(Modifier.padding(padding)) { content() } }
}

@Composable
private fun BottomNavItem(
    route: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: String,
    nav: androidx.navigation.NavHostController,
    modifier: Modifier
) {
    val active = selected == route
    Column(
        modifier.clickable { if (!active) nav.navigate(route) { launchSingleTop = true } },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = if (active) Color(0xFFC058FF) else Color.White.copy(alpha=.62f), modifier=Modifier.size(26.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color=if(active) Color(0xFFD88AFF) else Color.White.copy(alpha=.62f), fontSize=10.sp)
    }
}

@Composable
fun HomeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val dailyPicks = listOfNotNull(
        vm.wallpapers.firstOrNull { it.category == "Şehir" },
        vm.wallpapers.firstOrNull { it.category == "Doğa" },
        vm.wallpapers.firstOrNull { it.category == "Soyut" },
        vm.wallpapers.firstOrNull { it.category == "Oyun" }
    ).distinctBy { it.id }.ifEmpty { vm.wallpapers.take(1) }
    val pager = rememberPagerState(pageCount = { dailyPicks.size.coerceAtLeast(1) })
    val scope = rememberCoroutineScope()
    val popular = vm.wallpapers.take(8)
    val latest = vm.wallpapers.asReversed().take(8)
    val selectedForYou = (vm.wallpapers.drop(4) + vm.wallpapers).distinctBy { it.id }.take(8)

    Column(
        Modifier.fillMaxSize().background(Color(0xFF05050B))
            .verticalScroll(rememberScrollState())
            .padding(horizontal=16.dp, vertical=10.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(54.dp), verticalAlignment=Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment=Alignment.CenterVertically) {
                Text("WEX", color=Color(0xFFA557FF), fontSize=28.sp, fontWeight=FontWeight.Black)
                Text("TRA", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Black)
            }
            IconButton(onClick={ nav.navigate("popular") }) { Icon(Icons.Default.Search,null,tint=Color.White,modifier=Modifier.size(29.dp)) }
            IconButton(onClick={ nav.navigate("favorites") }) { Icon(Icons.Default.NotificationsNone,null,tint=Color.White,modifier=Modifier.size(28.dp)) }
        }

        HorizontalPager(state=pager, modifier=Modifier.fillMaxWidth().height(305.dp)) { page ->
            val item = dailyPicks[page]
            Card(
                Modifier.fillMaxSize().clickable { nav.navigate("detail/${item.id}") },
                shape=RoundedCornerShape(24.dp),
                colors=CardDefaults.cardColors(containerColor=Color(0xFF090914)),
                border=BorderStroke(1.dp, Color(0xFF8E4CFF).copy(alpha=.55f))
            ) {
                Box(Modifier.fillMaxSize()) {
                    AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF05050B).copy(alpha=.15f), Color(0xFF05050B).copy(alpha=.82f)))))
                    Surface(
                        modifier=Modifier.padding(16.dp).align(Alignment.TopStart),
                        shape=RoundedCornerShape(14.dp), color=Color(0xFF090914).copy(alpha=.75f)
                    ) { Text("⭐  ${vm.tr("GÜNÜN SEÇİMİ","TODAY'S PICK")}",Modifier.padding(horizontal=10.dp,vertical=7.dp),color=Color(0xFFFFD66B),fontSize=10.sp,fontWeight=FontWeight.Bold) }
                    Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                        Text(item.title.ifBlank { vm.tr("Günün seçimi","Today's pick") },color=Color.White,fontSize=27.sp,fontWeight=FontWeight.ExtraBold,maxLines=2)
                        Spacer(Modifier.height(6.dp))
                        Text(vm.tr("Yeni dünyaları keşfetmeye devam et.","Keep discovering new worlds."),color=Color.White.copy(alpha=.72f),fontSize=13.sp)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick={nav.navigate("detail/${item.id}")},shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF6F38D7))) {
                            Text(vm.tr("Duvar Kâğıdını Gör","View Wallpaper")); Spacer(Modifier.width(7.dp)); Icon(Icons.Default.ArrowForward,null,modifier=Modifier.size(18.dp))
                        }
                    }
                    Surface(Modifier.padding(14.dp).align(Alignment.BottomEnd),shape=RoundedCornerShape(10.dp),color=Color(0xFF090914).copy(alpha=.72f)) {
                        Text(item.resolutionLabel ?: "4K",Modifier.padding(horizontal=9.dp,vertical=6.dp),color=Color.White,fontWeight=FontWeight.Bold,fontSize=12.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top=10.dp),horizontalArrangement=Arrangement.Center) {
            repeat(dailyPicks.size) { i ->
                val active=pager.currentPage==i
                Box(Modifier.padding(horizontal=4.dp).width(if(active)25.dp else 8.dp).height(7.dp).clip(CircleShape).background(if(active)Color(0xFFB54BFF) else Color.White.copy(alpha=.25f)).clickable{scope.launch{pager.animateScrollToPage(i)}})
            }
        }

        Spacer(Modifier.height(16.dp))
        HomeWallpaperStrip(vm.tr("Popüler 🔥","Popular 🔥"), popular, vm, nav, "popular")
        Spacer(Modifier.height(18.dp))
        HomeWallpaperStrip(vm.tr("Yeni Eklenenler ✨","New Additions ✨"), latest, vm, nav, "latest")
        Spacer(Modifier.height(18.dp))
        HomeWallpaperStrip(vm.tr("Senin için Seçtiklerimiz 💜","Picked for You 💜"), selectedForYou, vm, nav, "latest")
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun CompactHomeTile(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, tint: Color, onClick: () -> Unit) {
    Surface(modifier.height(116.dp).clickable(onClick=onClick), shape=RoundedCornerShape(20.dp), color=Color(0xFF0C0D19), border=BorderStroke(1.dp,tint.copy(alpha=.65f)), contentColor=Color.White) {
        Row(Modifier.fillMaxSize().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Surface(Modifier.size(46.dp),shape=RoundedCornerShape(15.dp),color=tint.copy(alpha=.13f),border=BorderStroke(1.dp,tint.copy(alpha=.32f))) { Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=tint,modifier=Modifier.size(26.dp))} }
            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=15.sp,maxLines=1); Spacer(Modifier.height(6.dp)); Text(subtitle,color=Color(0xFFB7B4C1),fontSize=11.sp,lineHeight=15.sp,maxLines=3) }
            Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFC68AFF),modifier=Modifier.size(22.dp))
        }
    }
}

@Composable
private fun HomeWallpaperStrip(title: String, items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController, allRoute: String) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text(title,color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            TextButton(onClick={nav.navigate(allRoute)}) { Text(vm.tr("Tümünü Gör","See All"),color=Color(0xFFE0A0FF),fontSize=12.sp); Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFC852FF),modifier=Modifier.size(18.dp)) }
        }
        LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(end=4.dp)) {
            items(items.take(8), key={it.id}) { item ->
                Card(Modifier.width(112.dp).height(154.dp).clickable{nav.navigate("detail/${item.id}")},shape=RoundedCornerShape(16.dp),border=BorderStroke(1.dp,Color(0xFFB747FF).copy(alpha=.55f)),colors=CardDefaults.cardColors(containerColor=Color(0xFF0A0913))) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                        Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(8.dp).align(Alignment.TopEnd).size(21.dp))
                        Surface(Modifier.padding(7.dp).align(Alignment.BottomStart),shape=RoundedCornerShape(7.dp),color=Color(0xFF9139E1).copy(alpha=.92f),contentColor=Color.White) { Text(item.resolutionLabel?:"4K",Modifier.padding(horizontal=6.dp,vertical=3.dp),color=Color.White,fontSize=9.sp,fontWeight=FontWeight.Bold) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NeonHomeFeature(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    image1: Wallpaper,
    image2: Wallpaper,
    vm: WallpaperViewModel,
    onClick: () -> Unit
) {
    Surface(
        modifier=modifier.clickable(onClick=onClick),
        shape=RoundedCornerShape(22.dp),
        color=Color(0xFF090914),
        border=BorderStroke(1.dp, Color(0xFFB23BFF).copy(alpha=.62f))
    ) {
        Box(Modifier.fillMaxSize().padding(18.dp)) {
            Column(Modifier.align(Alignment.TopStart)) {
                Surface(Modifier.size(40.dp), shape=CircleShape, color=Color(0xFF24104A), border=BorderStroke(1.dp, Color(0xFF7D49FF).copy(alpha=.5f))) {
                    Box(contentAlignment=Alignment.Center) { Icon(icon,null,tint=Color(0xFFC15CFF),modifier=Modifier.size(23.dp)) }
                }
                Spacer(Modifier.height(10.dp))
                Text(title,fontWeight=FontWeight.Bold,fontSize=20.sp)
                Spacer(Modifier.height(8.dp))
                Text(body,color=Color.White.copy(alpha=.64f),fontSize=12.sp,lineHeight=18.sp)
            }
            Row(
                Modifier.align(Alignment.BottomEnd).padding(bottom=4.dp),
                horizontalArrangement=Arrangement.spacedBy((-18).dp)
            ) {
                listOf(image1,image2).forEachIndexed { index, item ->
                    AsyncImage(
                        vm.imageFor(item), null,
                        Modifier.size(width=82.dp,height=116.dp)
                            .graphicsLayer { rotationZ=if(index==0)-10f else 8f }
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp,Color(0xFFD84CFF).copy(alpha=.42f),RoundedCornerShape(12.dp)),
                        contentScale=ContentScale.Crop
                    )
                }
            }
            Text(vm.tr("Keşfet  →","Explore  →"), modifier=Modifier.align(Alignment.BottomStart), color=Color(0xFFD88CFF), fontWeight=FontWeight.Bold, fontSize=13.sp)
        }
    }
}

@Composable
private fun NeonColorFeature(modifier:Modifier, vm:WallpaperViewModel, onClick:()->Unit) {
    Surface(modifier=modifier.clickable(onClick=onClick), shape=RoundedCornerShape(22.dp), color=Color(0xFF090914), border=BorderStroke(1.dp, Color(0xFFFF5C47).copy(alpha=.55f))) {
        Box(Modifier.fillMaxSize().padding(18.dp)) {
            Column {
                Surface(Modifier.size(40.dp), shape=CircleShape, color=Color(0xFF2B1035), border=BorderStroke(1.dp,Color(0xFFFF4C96).copy(alpha=.4f))) {
                    Box(contentAlignment=Alignment.Center) { Icon(Icons.Default.ColorLens,null,tint=Color(0xFFFF5A9F),modifier=Modifier.size(22.dp)) }
                }
                Spacer(Modifier.height(10.dp))
                Text(vm.tr("Renge Göre","By Color"),fontWeight=FontWeight.Bold,fontSize=20.sp)
                Spacer(Modifier.height(8.dp))
                Text(vm.tr("Favori rengini seç,\nsana uygun duvar\nkâğıtlarını bulalım.","Pick your favorite color."),color=Color.White.copy(alpha=.64f),fontSize=12.sp,lineHeight=18.sp)
            }
            Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf(0xFF8038FF,0xFFE63898,0xFFFF7B45,0xFFFFA928,0xFFFFE15B,0xFF2B86FF,0xFF25BEEA,0xFF35C88B).forEach {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(Color(it)))
                }
            }
        }
    }
}

@Composable
private fun NeonSwipeFeature(modifier:Modifier,item:Wallpaper,vm:WallpaperViewModel,onClick:()->Unit) {
    Surface(modifier=modifier.clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),color=Color(0xFF090914),border=BorderStroke(1.dp,Color(0xFFD23EFF).copy(alpha=.52f))) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.padding(18.dp).align(Alignment.TopStart)) {
                Surface(Modifier.size(40.dp),shape=CircleShape,color=Color(0xFF1D1140)) { Box(contentAlignment=Alignment.Center){ Icon(Icons.Default.Swipe,null,tint=Color(0xFFB754FF)) } }
                Spacer(Modifier.height(9.dp))
                Text("Wallpaper Swipe",fontWeight=FontWeight.Bold,fontSize=17.sp)
                Spacer(Modifier.height(8.dp))
                Text(vm.tr("Beğen, kaydet\nya da geç.","Like, save\nor skip."),color=Color.White.copy(alpha=.62f),fontSize=12.sp)
            }
            AsyncImage(vm.imageFor(item),null,Modifier.align(Alignment.BottomEnd).size(width=128.dp,height=150.dp).padding(end=14.dp,bottom=0.dp).clip(RoundedCornerShape(18.dp)),contentScale=ContentScale.Crop)
            Row(Modifier.align(Alignment.BottomStart).padding(14.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Surface(Modifier.size(42.dp),shape=CircleShape,color=Color(0xFF11121E),border=BorderStroke(1.dp,Color(0xFF8143FF).copy(alpha=.6f))){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Close,null,tint=Color.White.copy(alpha=.7f))}}
                Surface(Modifier.size(42.dp),shape=CircleShape,color=Color(0xFF11121E),border=BorderStroke(1.dp,Color(0xFFFF477C).copy(alpha=.8f))){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Favorite,null,tint=Color(0xFFFF4D89))}}
            }
        }
    }
}

@Composable
private fun NeonPremiumFeature(modifier:Modifier,item:Wallpaper,vm:WallpaperViewModel,onClick:()->Unit) {
    Surface(modifier=modifier.clickable(onClick=onClick),shape=RoundedCornerShape(22.dp),color=Color(0xFF090914),border=BorderStroke(1.dp,Color(0xFF7A36FF).copy(alpha=.56f))) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(vm.imageFor(item),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF090914).copy(alpha=.97f),Color(0xFF090914).copy(alpha=.55f)))))
            Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.Center) {
                Surface(shape=RoundedCornerShape(6.dp),color=Color(0xFFFF6B91).copy(alpha=.88f)){Text("PRO",modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp),fontSize=8.sp,fontWeight=FontWeight.Black)}
                Spacer(Modifier.height(12.dp))
                Text(vm.tr("Premium'u Keşfet","Discover Premium"),fontWeight=FontWeight.Bold,fontSize=18.sp)
                Spacer(Modifier.height(8.dp))
                Text(vm.tr("Reklamsız deneyim,\nözel koleksiyonlar\nve daha fazlası!","Ad-free and exclusive."),color=Color.White.copy(alpha=.65f),fontSize=11.sp,lineHeight=17.sp)
                Spacer(Modifier.height(12.dp))
                Surface(shape=RoundedCornerShape(18.dp),color=Color(0xFF150D2C).copy(alpha=.88f),border=BorderStroke(1.dp,Color(0xFFAD54FF).copy(alpha=.6f))) {
                    Text(vm.tr("Şimdi Yükselt  →","Upgrade  →"),modifier=Modifier.padding(horizontal=13.dp,vertical=8.dp),color=Color(0xFFE1B5FF),fontWeight=FontWeight.Bold,fontSize=11.sp)
                }
            }
        }
    }
}

@Composable
private fun NeonWallpaperSection(
    title:String,
    items:List<Wallpaper>,
    vm:WallpaperViewModel,
    nav:androidx.navigation.NavHostController,
    allRoute:String,
    modifier:Modifier=Modifier
) {
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            TextButton(onClick={nav.navigate(allRoute)},contentPadding=PaddingValues(0.dp)) {
                Text(vm.tr("Tümünü Gör","See All"),color=Color(0xFFE4A8FF),fontSize=11.sp)
                Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFCC54FF),modifier=Modifier.size(17.dp))
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().weight(1f),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items.take(6).forEach { item ->
                Column(Modifier.weight(1f).fillMaxHeight().clickable { nav.navigate("detail/${item.id}") }) {
                    Card(
                        shape=RoundedCornerShape(14.dp),
                        border=BorderStroke(1.dp,Color(0xFFB247FF).copy(alpha=.34f)),
                        modifier=Modifier.fillMaxWidth().weight(1f),
                        colors=CardDefaults.cardColors(containerColor=Color(0xFF090914))
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                            Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(6.dp).align(Alignment.TopEnd).size(18.dp))
                            Surface(
                                modifier=Modifier.padding(6.dp).align(Alignment.BottomStart),
                                shape=RoundedCornerShape(7.dp),
                                color=Color(0xFF8D38D8).copy(alpha=.88f)
                            ) { Text(item.resolutionLabel ?: "4K",modifier=Modifier.padding(horizontal=6.dp,vertical=3.dp),fontSize=8.sp,fontWeight=FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReferenceHomeSection(title:String, items:List<Wallpaper>, vm:WallpaperViewModel, nav:androidx.navigation.NavHostController, allRoute:String, modifier:Modifier=Modifier) {
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment=Alignment.CenterVertically) {
            Text(title, fontSize=16.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
            TextButton(onClick={nav.navigate(allRoute)}, contentPadding=PaddingValues(0.dp)) { Text(vm.tr("Tümünü Gör","See All"), color=Color.White.copy(alpha=.72f), fontSize=11.sp); Icon(Icons.Default.ChevronRight,null,tint=vm.currentAccent,modifier=Modifier.size(16.dp)) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items.take(4).forEach { item ->
                Column(Modifier.weight(1f).fillMaxHeight().clickable { nav.navigate("detail/${item.id}") }) {
                    Card(shape=RoundedCornerShape(15.dp), border=BorderStroke(1.dp, Color.White.copy(alpha=.12f)), modifier=Modifier.fillMaxWidth().weight(1f)) {
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                            Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(6.dp).align(Alignment.TopEnd).size(17.dp))
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun HomeAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier=modifier.height(66.dp).clickable(onClick=onClick),
        shape=RoundedCornerShape(18.dp),
        color=Surface,
        border=BorderStroke(1.dp, Color.White.copy(alpha=.07f))
    ) {
        Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
            Icon(icon, null, tint=Accent, modifier=Modifier.size(21.dp))
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize=9.sp, maxLines=1)
        }
    }
}

@Composable
private fun HomeFeatureRow(vm: WallpaperViewModel) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        listOf(Triple("4K","4K & HD",Icons.Default.HighQuality),Triple("🔥","Trend",Icons.Default.LocalFireDepartment),Triple("◈","Premium",Icons.Default.Diamond),Triple("☆","Yeni",Icons.Default.StarBorder)).forEach { (iconText,label,icon) ->
            Surface(Modifier.weight(1f).height(70.dp), shape=RoundedCornerShape(18.dp), color=Surface, border=BorderStroke(1.dp, Color.White.copy(alpha=.08f))) {
                Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){ Icon(icon,null,tint=vm.currentAccent,modifier=Modifier.size(22.dp)); Spacer(Modifier.height(4.dp)); Text(label,fontSize=10.sp,fontWeight=FontWeight.Medium) }
            }
        }
    }
}

@Composable
private fun QuickExploreCard(modifier: Modifier, title: String, subtitle: String, onClick:()->Unit) {
    Card(modifier=modifier.height(92.dp).clickable(onClick=onClick), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Surface)) {
        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.Center){ Text(title,fontWeight=FontWeight.Bold,fontSize=14.sp); Spacer(Modifier.height(5.dp)); Text(subtitle,color=TextMuted,fontSize=11.sp) }
    }
}

@Composable
private fun CompactHomeSection(
    title: String,
    items: List<Wallpaper>,
    vm: WallpaperViewModel,
    nav: androidx.navigation.NavHostController,
    modifier: Modifier = Modifier,
    allRoute: String = "categories"
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight=FontWeight.Bold, fontSize=17.sp, modifier=Modifier.weight(1f))
            TextButton(onClick={nav.navigate(allRoute)}, contentPadding=PaddingValues(horizontal=4.dp, vertical=0.dp)) {
                Text("Tümünü Gör", fontSize=12.sp); Icon(Icons.Default.ChevronRight,null,modifier=Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.take(5).forEach { item ->
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { nav.navigate("detail/${item.id}") }
                ) {
                    Card(
                        shape=RoundedCornerShape(13.dp),
                        border=BorderStroke(1.dp, Color.White.copy(alpha=.12f)),
                        modifier=Modifier.fillMaxWidth().weight(1f)
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                            Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(5.dp).align(Alignment.TopEnd).size(16.dp))
                            Surface(color=MaterialTheme.colorScheme.primary.copy(alpha=.82f), shape=RoundedCornerShape(6.dp), modifier=Modifier.padding(5.dp).align(Alignment.BottomStart)) {
                                Text(item.resolutionLabel ?: "4K", fontSize=8.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=5.dp,vertical=2.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(item.title, fontWeight=FontWeight.SemiBold, maxLines=1, fontSize=10.sp)
                    Text("⇩ ${((item.id.hashCode().toUInt().toLong()%80)+42)/10.0}K", color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=8.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Text(title, fontWeight=FontWeight.Bold, fontSize=20.sp, modifier=Modifier.weight(1f))
        TextButton(onClick=onAction) { Text(action); Icon(Icons.Default.ChevronRight,null,modifier=Modifier.size(18.dp)) }
    }
}

@Composable
private fun WallpaperHorizontalRow(items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    LazyRow(horizontalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(top=6.dp)) {
        items(items) { item ->
            Column(Modifier.width(150.dp).clickable{nav.navigate("detail/${item.id}")}) {
                Card(shape=RoundedCornerShape(18.dp), border=BorderStroke(1.dp, Color.White.copy(alpha=.14f)), modifier=Modifier.fillMaxWidth().height(200.dp)) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                        Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(9.dp).align(Alignment.TopEnd))
                        Surface(color=MaterialTheme.colorScheme.primary.copy(alpha=.78f), shape=RoundedCornerShape(8.dp), modifier=Modifier.padding(8.dp).align(Alignment.BottomStart)) { Text(vm.selectedResolution.label, fontSize=10.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=7.dp,vertical=4.dp)) }
                    }
                }
                Spacer(Modifier.height(7.dp)); Text(item.title, fontWeight=FontWeight.SemiBold, maxLines=1, fontSize=13.sp)
                Text("⇩ ${((item.id.hashCode().toUInt().toLong()%80)+42)/10.0}K", color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=11.sp)
            }
        }
    }
}
@Composable
fun ResolutionSelector(vm: WallpaperViewModel) {
    Card(
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f))
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Çözünürlük", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Uygulama içi görüntüleme kalitesi", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                vm.resolutions.forEachIndexed { index, option ->
                    val selected = vm.selectedResolution == option
                    val tone = CategoryColors[index % CategoryColors.size]
                    FilledTonalButton(
                        onClick = { vm.selectResolution(option) },
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(horizontal = 1.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (selected) tone.copy(alpha = 0.32f) else tone.copy(alpha = 0.10f),
                            contentColor = if (selected) Color.White else tone
                        )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(option.label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(option.detail, fontSize = 7.sp, color = if (selected) Color.White.copy(alpha = 0.8f) else tone.copy(alpha = 0.85f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WallpaperGrid(items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController, modifier: Modifier = Modifier) {
    LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier.fillMaxWidth()) {
        items(items) { item ->
            Card(modifier = Modifier.fillMaxWidth().aspectRatio(.72f).clickable { nav.navigate("detail/${item.id}") }, shape = RoundedCornerShape(14.dp)) {
                Box {
                    AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Icon(Icons.Default.FavoriteBorder, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(7.dp).align(Alignment.TopEnd).size(20.dp))
                    Surface(color = Background.copy(alpha = .72f), modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()) {
                        Column(Modifier.padding(7.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                            Text(vm.selectedResolution.label, color = MaterialTheme.colorScheme.primary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoriesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val cards = listOf(
        Triple(vm.tr("Popüler","Popular"), vm.tr("En çok beğenilen duvar kâğıtları","Most liked wallpapers"), Icons.Default.LocalFireDepartment),
        Triple(vm.tr("Kategoriler","Categories"), vm.tr("Tarzına uygun kategorileri keşfet","Discover categories for your style"), Icons.Default.GridView),
        Triple(vm.tr("Yeni","New"), vm.tr("En yeni duvar kâğıtlarını keşfet","Discover newest wallpapers"), Icons.Default.AutoAwesome),
        Triple(vm.tr("Renge Göre","By Color"), vm.tr("Favori rengini seç, sana uygunları bul","Pick a color and find your style"), Icons.Default.Palette),
        Triple(vm.tr("Favoriler","Favorites"), vm.tr("Beğendiğin duvar kâğıtları burada","Your liked wallpapers"), Icons.Default.Favorite),
        Triple(vm.tr("Topluluk","Community"), vm.tr("Topluluğun paylaştığı en iyi görseller","Best community shares"), Icons.Default.Groups)
    )
    val routes = listOf("popular","categoriesList","latest","colors","favorites","community")
    val tones = listOf(Color(0xFFFF6A3D),Color(0xFF4A9CFF),Color(0xFF79D34F),Color(0xFFFFB04A),Color(0xFFFF4D92),Color(0xFF9C70FF))

    Column(Modifier.fillMaxSize().background(Color(0xFF05050B)).verticalScroll(rememberScrollState()).padding(horizontal=16.dp, vertical=20.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text(vm.tr("Keşfet","Explore"),color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            Icon(Icons.Default.Search,null,tint=Color.White,modifier=Modifier.size(29.dp))
        }
        Spacer(Modifier.height(16.dp))

        Surface(Modifier.fillMaxWidth().height(112.dp).clickable{nav.navigate("community")},shape=RoundedCornerShape(24.dp),color=Color(0xFF171336),border=BorderStroke(1.dp,Color(0xFF7D4DFF).copy(alpha=.55f))) {
            Row(Modifier.fillMaxSize().padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
                Surface(Modifier.size(58.dp),shape=CircleShape,color=Color(0xFF6D35D5).copy(alpha=.28f),border=BorderStroke(1.dp,Color(0xFFC071FF).copy(alpha=.7f))) { Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Explore,null,tint=Color(0xFFD08CFF),modifier=Modifier.size(30.dp))} }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.tr("Keşfet","Explore"),color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp)
                    Text(vm.tr("Binlerce duvar kâğıdını keşfet ve ilham al.","Discover wallpapers and get inspired."),color=Color.White.copy(alpha=.68f),fontSize=12.sp)
                }
                Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFCAA0FF))
            }
        }

        Spacer(Modifier.height(16.dp))
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
            cards.chunked(2).forEachIndexed { rowIndex, row ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    row.forEachIndexed { colIndex, (title, subtitle, icon) ->
                        val index=rowIndex*2+colIndex
                        val tone=tones[index]
                        Surface(
                            Modifier.weight(1f).height(138.dp).clickable { nav.navigate(routes[index]) },
                            shape = RoundedCornerShape(22.dp),
                            color = Color(0xFF10111E),
                            border = BorderStroke(1.dp, tone.copy(alpha = .58f))
                        ) {
                            Row(
                                Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    Modifier.size(54.dp),
                                    shape = RoundedCornerShape(17.dp),
                                    color = tone.copy(alpha = .20f),
                                    border = BorderStroke(1.dp, tone.copy(alpha = .55f))
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(icon, null, tint = tone, modifier = Modifier.size(28.dp))
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                    Text(
                                        title,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        maxLines = 1
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        subtitle,
                                        color = Color(0xFFD1D0D9),
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp,
                                        maxLines = 3
                                    )
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    null,
                                    tint = tone.copy(alpha = .95f),
                                    modifier = Modifier.size(23.dp)
                                )
                            }
                        }
                    }
                    if(row.size==1) Spacer(Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        HomeWallpaperStrip(vm.tr("Editörün Seçimi","Editor's Pick"), vm.wallpapers.shuffled().take(8), vm, nav, "latest")
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Text("👥  ${vm.tr("Topluluktan","From Community")}",color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            Text(vm.tr("Tümünü Gör  →","See All  →"),color=Color(0xFFC58AFF),fontSize=12.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
            listOf("A","S","B","D","M").forEach { initial ->
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Surface(Modifier.size(48.dp),shape=CircleShape,color=Color(0xFF20113E),border=BorderStroke(1.dp,Color(0xFF9D65FF).copy(alpha=.45f))) { Box(contentAlignment=Alignment.Center){Text(initial,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp)} }
                    Spacer(Modifier.height(5.dp)); Text("$initial.",color=Color.White.copy(alpha=.72f),fontSize=10.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun PageSectionTitle(title: String, modifier: Modifier = Modifier) {
    // Ana sayfadaki “Yeni Eklenenler” başlığıyla aynı sade hiyerarşi.
    Text(
        title,
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
    )
}

@Composable
fun PopularScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val ranked = vm.wallpapers.sortedByDescending { if (it.id in vm.favorites) 1 else 0 }.take(50)
    WallpaperGridScreen(vm.tr("Popüler Top 50","Popular Top 50"), ranked, vm, nav)
}

@Composable
fun CommunityScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    Column(
        Modifier.fillMaxSize()
            .background(Color(0xFF05050B))
            .statusBarsPadding()
            .padding(horizontal=16.dp, vertical=14.dp)
    ) {
        PageSectionTitle(vm.tr("Topluluk","Community"))
        Spacer(Modifier.height(8.dp))
        Text(vm.tr("Kullanıcıların gönderdiği görseller burada yayınlanacak. Gönderi ve yönetici onay sistemi VDS/backend kurulunca aktif olacak.","User submissions will appear here. Upload and approval will be activated when the VDS/backend is ready."),color=Color(0xFFB8B5C2))
    }
}

@Composable
fun WallpaperGridScreen(title:String, items:List<Wallpaper>, vm:WallpaperViewModel, nav:androidx.navigation.NavHostController) {
    Column(
        Modifier.fillMaxSize()
            .background(Color(0xFF05050B))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        PageSectionTitle(title)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            items(items) { item ->
                Card(Modifier.height(250.dp).clickable { nav.navigate("detail/${item.id}") },shape=RoundedCornerShape(18.dp)) {
                    AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryListScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val names = vm.categories.filter { name -> vm.wallpapers.any { it.category == name } }
    Column(
        Modifier.fillMaxSize()
            .background(Color(0xFF05050B))
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        PageSectionTitle(vm.tr("Kategoriler","Categories"))
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            items(names) { name ->
                val item=vm.wallpapers.first { it.category==name }
                Card(Modifier.height(220.dp).clickable { nav.navigate("category/$name") },shape=RoundedCornerShape(20.dp)) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(vm.imageFor(item),name,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color(0xFF05050B).copy(alpha=.9f)))))
                        Text(name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.align(Alignment.BottomStart).padding(14.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryWallpapersScreen(categoryName: String, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val categoryItems = vm.wallpapers.filter { it.category == categoryName }
    Scaffold(
        containerColor = Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(categoryName, fontWeight = FontWeight.Bold)
                        Text("${categoryItems.size} duvar kâğıdı", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Background)
            )
        }
    ) { padding ->
        if (categoryItems.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Bu kategoride henüz görsel yok.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            WallpaperGrid(
                categoryItems,
                vm,
                nav,
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun WallpaperCard(
    item: Wallpaper,
    vm: WallpaperViewModel,
    nav: androidx.navigation.NavHostController
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isFavorite = item.id in vm.favorites

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .clickable { nav.navigate("detail/${item.id}") },
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(
                model = vm.imageFor(item),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(88.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Background.copy(alpha = 0.94f))
                        )
                    )
            )

            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(38.dp),
                shape = CircleShape,
                color = Background.copy(alpha = 0.72f)
            ) {
                IconButton(onClick = { vm.toggleLike(item.id, context) }) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isFavorite) "Favorilerden kaldır" else "Favorilere ekle",
                        tint = if (isFavorite) vm.currentAccent else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(9.dp),
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f)
            ) {
                Text(
                    item.resolutionLabel ?: vm.selectedResolution.label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(start = 9.dp, end = 9.dp, bottom = 9.dp)
                    .padding(top = 34.dp)
            ) {
                Text(
                    item.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Spacer(Modifier.height(3.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "❤️ ${formatCount(vm.likeCount(item.id))}",
                        color = Color.White.copy(alpha = 0.88f),
                        fontSize = 10.sp
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "👁 ${formatCount(vm.viewCount(item.id))}",
                        color = Color.White.copy(alpha = 0.88f),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

private fun formatCount(value: Int): String = when {
    value >= 1000 -> String.format(java.util.Locale.US, "%.1fK", value / 1000f)
    else -> value.toString()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LatestScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val latest = vm.wallpapers.takeLast(50).reversed()
    Scaffold(topBar={TopAppBar(title={Text("Yeni Eklenenler")},navigationIcon={IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)}})}){pad->
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.padding(pad).fillMaxSize().padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)){
            items(latest){w-> WallpaperCard(w, vm, nav)}
        }
    }
}
@Composable
fun ColorExploreScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController){
    val colors=listOf(
        "Mor" to Color(0xFF8B5CF6),"Mavi" to Color(0xFF3B82F6),"Pembe" to Color(0xFFEC4899),"Yeşil" to Color(0xFF22C55E),"Turuncu" to Color(0xFFF97316),
        "Sarı" to Color(0xFFFBBF24),"Turkuaz" to Color(0xFF14B8A6),"Kırmızı" to Color(0xFFEF4444),"Beyaz" to Color(0xFFF1F5F9),"Siyah" to Color(0xFF050505)
    )
    var selected by remember{mutableStateOf("Mor")}
    val selectedIndex=colors.indexOfFirst{it.first==selected}.coerceAtLeast(0)
    val shown=vm.wallpapers.filter { (it.id.hashCode().toUInt().toInt() and Int.MAX_VALUE) % colors.size == selectedIndex }.take(30)
    Column(
        Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal=16.dp,vertical=14.dp)
    ){
        PageSectionTitle("Renge Göre Keşfet")
        Spacer(Modifier.height(8.dp))
        Text("Bir renk seç ve keşfet",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Column(verticalArrangement=Arrangement.spacedBy(14.dp)){
            colors.chunked(5).forEach{ row-> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){ row.forEach{ c-> ColorChoice(c.first,c.second,selected==c.first){selected=c.first} } } }
        }
        Spacer(Modifier.height(22.dp))
        val display=if(shown.isEmpty()) vm.wallpapers.take(20) else shown
        LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxWidth().height(1100.dp),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),userScrollEnabled=false){ items(display){w-> ColorWallpaperCard(w,vm,nav) } }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ColorChoice(name:String,color:Color,selected:Boolean,onClick:()->Unit){
    Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(58.dp).clickable(onClick=onClick)){
        Surface(Modifier.size(48.dp),shape=CircleShape,color=color,border=BorderStroke(if(selected)3.dp else 1.dp,if(selected)Color.White else Color.White.copy(alpha=.35f))){ if(selected) Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Check,null,tint=if(name=="Beyaz"||name=="Sarı")Color.Black else Color.White)} }
        Spacer(Modifier.height(5.dp)); Text(name,fontSize=10.sp,maxLines=1)
    }
}

@Composable
private fun ColorWallpaperCard(w:Wallpaper,vm:WallpaperViewModel,nav:androidx.navigation.NavHostController){
    Card(modifier=Modifier.fillMaxWidth().height(255.dp).clickable{nav.navigate("detail/${w.id}")},shape=RoundedCornerShape(20.dp),border=BorderStroke(1.dp,Color.White.copy(alpha=.12f))){
        Box(Modifier.fillMaxSize()){
            AsyncImage(vm.imageFor(w),w.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Background.copy(alpha=.94f)))) )
            Surface(Modifier.padding(10.dp).size(44.dp).align(Alignment.TopEnd),shape=CircleShape,color=Background.copy(alpha=.70f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.FavoriteBorder,null,tint=Color.White)}}
            Surface(color=vm.currentAccent.copy(alpha=.90f),shape=RoundedCornerShape(9.dp),modifier=Modifier.padding(10.dp).align(Alignment.BottomStart)){Text("4K",fontSize=11.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=8.dp,vertical=4.dp))}
            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp)){Text(w.title,fontWeight=FontWeight.Bold,fontSize=15.sp,maxLines=1);Text("◉ ${(w.id.hashCode().toUInt().toLong()%20+40)/10.0}K",fontSize=10.sp,color=Color.White.copy(alpha=.72f),modifier=Modifier.align(Alignment.End))}
        }
    }
}

@Composable
fun SwipeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var index by remember { mutableStateOf(0) }
    if (vm.wallpapers.isEmpty()) return
    val w = vm.wallpapers[index % vm.wallpapers.size]

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, null)
            }
            Text("Wallpaper Swipe", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Text("Kaydır, beğen, keşfet", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        AsyncImage(
            model = vm.imageFor(w),
            contentDescription = w.title,
            modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(18.dp))
        Text(w.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(onClick = { index++ }) {
                Icon(Icons.Default.Close, null)
                Text(" Geç")
            }
            Button(onClick = {
                vm.toggleFavorite(w.id, context)
                index++
            }) {
                Icon(Icons.Default.Favorite, null)
                Text(" Beğen")
            }
            OutlinedButton(onClick = { nav.navigate("detail/${w.id}") }) {
                Icon(Icons.Default.Info, null)
                Text(" Detay")
            }
        }
    }
}

@Composable
fun FavoritesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val list = vm.wallpapers.filter { it.id in vm.favorites }
    Column(
        Modifier.fillMaxSize()
            .background(Color(0xFF05050B))
            .statusBarsPadding()
            .padding(horizontal=16.dp,vertical=14.dp)
    ) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){PageSectionTitle(vm.tr("Favoriler","Favorites"));Spacer(Modifier.height(6.dp));Text(vm.tr("Beğendiğin duvar kâğıtlarına buradan hızlıca erişebilirsin.","Quickly access wallpapers you like from here."),color=Color(0xFFB8B5C2),fontSize=12.sp)}
            Surface(Modifier.size(48.dp),shape=CircleShape,color=MaterialTheme.colorScheme.primary.copy(alpha=.12f),border=BorderStroke(1.dp,MaterialTheme.colorScheme.primary.copy(alpha=.25f))){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Tune,null,tint=vm.currentAccent)}}
        }
        Spacer(Modifier.height(16.dp))
        if(list.isEmpty()){
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Surface(Modifier.size(86.dp),shape=CircleShape,color=MaterialTheme.colorScheme.primary.copy(alpha=.10f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.FavoriteBorder,null,Modifier.size(38.dp),tint=vm.currentAccent)}};Spacer(Modifier.height(14.dp));Text(vm.tr("Henüz favorin yok","No favorites yet"),fontWeight=FontWeight.Bold);Text(vm.tr("Beğendiğin duvar kâğıtları burada görünür.","Wallpapers you like will appear here."),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)}}
        } else {
            LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),modifier=Modifier.fillMaxSize()){
                items(list){item->
                    Card(onClick={nav.navigate("detail/${item.id}")},shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth().height(250.dp),border=BorderStroke(1.dp,Color.White.copy(alpha=.08f))){
                        Box(Modifier.fillMaxSize()){
                            AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color(0xFF07101F).copy(alpha=.92f)))) )
                            Surface(Modifier.padding(10.dp).size(42.dp).align(Alignment.TopEnd),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Favorite,null,tint=Color.White)}}
                            Surface(color=MaterialTheme.colorScheme.primary.copy(alpha=.84f),shape=RoundedCornerShape(8.dp),modifier=Modifier.padding(10.dp).align(Alignment.TopStart)){Text(item.resolutionLabel?:vm.selectedResolution.label,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp))}
                            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp)){Text(item.title,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1);Text("${item.category} • ${vm.selectedResolution.detail}",color=Color.White.copy(alpha=.72f),fontSize=11.sp)}
                        }
                    }
                }
            }
        }
    }
}


private suspend fun loadWallpaperBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.doInput = true
        connection.connect()
        connection.inputStream.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) {
        null
    }
}

private suspend fun applyWallpaper(context: Context, item: Wallpaper, imageModel: Any, which: Int): Boolean =
    withContext(Dispatchers.IO) {
        try {
            val bitmap = when (imageModel) {
                is Int -> BitmapFactory.decodeResource(context.resources, imageModel)
                is String -> loadWallpaperBitmap(imageModel)
                else -> null
            } ?: return@withContext false
            val manager = WallpaperManager.getInstance(context)
            manager.setBitmap(bitmap, null, true, which)
            true
        } catch (_: Exception) {
            false
        }
    }

@Composable
fun DetailScreen(item: Wallpaper, vm: WallpaperViewModel, isFavorite: Boolean, onFavorite: () -> Unit, nav: androidx.navigation.NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(item.id) { vm.recordView(item.id, context) }
    val scope = rememberCoroutineScope()
    var showWallpaperChoice by remember { mutableStateOf(false) }
    var showCollectionChoice by remember { mutableStateOf(false) }
    var showPreview by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }

    fun shareWallpaper() {
        try {
            val model = vm.imageFor(item)
            val extra = if (model is String && model.isNotBlank()) "\n$model" else ""
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, item.title)
                putExtra(Intent.EXTRA_TEXT, "${item.title} - WEXTRA$extra")
            }
            context.startActivity(Intent.createChooser(intent, vm.tr("Duvar kâğıdını paylaş", "Share wallpaper")))
        } catch (_: Exception) {
            Toast.makeText(context, vm.tr("Paylaşım başlatılamadı", "Unable to start sharing"), Toast.LENGTH_SHORT).show()
        }
    }

    if (showWallpaperChoice) AlertDialog(
        onDismissRequest={ if(!working) showWallpaperChoice=false },
        title={ Text(vm.tr("Duvar kâğıdı yap","Set wallpaper")) },
        text={ Text(vm.tr("Nerede kullanmak istiyorsun?","Where would you like to use it?")) },
        confirmButton={ TextButton(enabled=!working,onClick={ working=true;scope.launch{ val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Duvar kâğıdı ayarlandı","Wallpaper applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_LONG).show() }}){Text(vm.tr("Her ikisi","Both"))} },
        dismissButton={ Row{
            TextButton(enabled=!working,onClick={scope.launch{working=true;val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_SYSTEM);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Ana ekran ayarlandı","Home screen applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_SHORT).show()}}){Text(vm.tr("Ana ekran","Home screen"))}
            TextButton(enabled=!working,onClick={scope.launch{working=true;val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_LOCK);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Kilit ekranı ayarlandı","Lock screen applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_SHORT).show()}}){Text(vm.tr("Kilit ekranı","Lock screen"))}
        }}
    )

    if (showPreview) {
        Dialog(onDismissRequest={ showPreview=false }, properties=DialogProperties(usePlatformDefaultWidth=false)) {
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Fit)
                Surface(Modifier.align(Alignment.TopEnd).padding(18.dp).statusBarsPadding(), shape=CircleShape, color=Color.Black.copy(alpha=.58f)) {
                    IconButton(onClick={showPreview=false}) { Icon(Icons.Default.Close,null,tint=Color.White) }
                }
                Text(item.title, color=Color.White, modifier=Modifier.align(Alignment.BottomCenter).padding(24.dp).navigationBarsPadding(), fontWeight=FontWeight.SemiBold)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha=.28f),Color.Transparent,Color.Black.copy(alpha=.18f)))))
                Row(Modifier.fillMaxWidth().padding(18.dp).statusBarsPadding(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)) { IconButton(onClick={nav.popBackStack()}) { Icon(Icons.Default.ArrowBack,null,tint=Color.White) } }
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)) { IconButton(onClick=onFavorite) { Icon(if(isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(isFavorite)vm.currentAccent else Color.White) } }
                        Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)) { IconButton(onClick=::shareWallpaper) { Icon(Icons.Default.Share,null,tint=Color.White) } }
                    }
                }
                // Resmin üzerindeki sayfa/nokta göstergeleri kaldırıldı.
            }
            Card(shape=RoundedCornerShape(topStart=30.dp,topEnd=30.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.background),modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal=20.dp,vertical=14.dp)) {
                    Box(Modifier.width(42.dp).height(4.dp).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(4.dp)).background(TextMuted.copy(alpha=.6f)))
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(item.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text("♧  ${item.category}",color=CategoryColors.first(),fontSize=15.sp) }
                        Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.13f)) { Text("${item.resolutionLabel?:"4K"} Ultra HD",color=vm.currentAccent,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=14.dp,vertical=10.dp)) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Text("❤️ ${formatCount(vm.likeCount(item.id))}",fontSize=14.sp,fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("👁 ${formatCount(vm.viewCount(item.id))}",fontSize=14.sp,fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)) { DetailInfo(Modifier.weight(1f),Icons.Default.AspectRatio,vm.selectedResolution.detail,vm.tr("Çözünürlük","Resolution"),vm);DetailInfo(Modifier.weight(1f),Icons.Default.PhotoSizeSelectLarge,"9:16",vm.tr("Oran","Ratio"),vm);DetailInfo(Modifier.weight(1f),Icons.Default.Storage,"3,2 MB",vm.tr("Boyut","Size"),vm) }
                    Spacer(Modifier.height(14.dp))
                    val descriptionScroll = rememberScrollState()
                    Text(
                        vm.tr("Doğanın büyüleyici güzelliğini yansıtan bu duvar kâğıdı, cihazınıza huzur ve ferahlık getirir. Uzun açıklamalar burada kaydırılarak rahatça okunabilir.","This wallpaper reflects the captivating beauty of nature and brings calm to your device. Longer descriptions can be scrolled here comfortably."),
                        color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp,lineHeight=20.sp,
                        modifier=Modifier.fillMaxWidth().heightIn(max=92.dp).verticalScroll(descriptionScroll)
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        Button(enabled=!working,onClick={ if(vm.currentUserEmail==null) nav.navigate("login") else showWallpaperChoice=true },modifier=Modifier.weight(1f).height(58.dp),shape=RoundedCornerShape(20.dp)) { Icon(Icons.Default.Wallpaper,null);Spacer(Modifier.width(8.dp));Text(if(working)vm.tr("İşleniyor...","Working...")else vm.tr("Duvar Kâğıdı Yap","Set Wallpaper"),fontWeight=FontWeight.Bold) }
                        OutlinedButton(onClick={showPreview=true},modifier=Modifier.width(70.dp).height(58.dp),shape=RoundedCornerShape(20.dp)) { Icon(Icons.Default.Visibility,null);Spacer(Modifier.width(3.dp));Text(vm.tr("Önizle","Preview"),fontSize=10.sp) }
                        OutlinedButton(onClick=::shareWallpaper,modifier=Modifier.width(58.dp).height(58.dp),shape=RoundedCornerShape(20.dp)) { Icon(Icons.Default.Share,null) }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
@Composable private fun DetailInfo(modifier:Modifier,icon:androidx.compose.ui.graphics.vector.ImageVector,value:String,label:String,vm:WallpaperViewModel){Card(modifier=modifier.height(72.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=vm.currentAccent,modifier=Modifier.size(22.dp));Spacer(Modifier.width(7.dp));Column{Text(value,fontWeight=FontWeight.Bold,fontSize=13.sp);Text(label,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=10.sp)}}}}


@Composable
fun LoginScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

    val activity = context.findActivity()
    val auth = remember { FirebaseAuth.getInstance() }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val purple = Color(0xFF7B35F4)
    val pink = Color(0xFFE72F9A)
    val orange = Color(0xFFFF8B3D)
    val cyan = Color(0xFF2AABFF)

    fun finishLogin(user: FirebaseUser?) {
        if (user == null) {
            loading = false
            error = vm.tr("Kullanıcı bulunamadı.", "User not found.")
            return
        }
        vm.signIn(
            user.email.orEmpty(),
            user.displayName ?: user.email?.substringBefore("@").orEmpty(),
            rememberMe,
            context
        )
        loading = false
        nav.navigate("profile") { popUpTo("login") { inclusive = true } }
    }

    val googleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(r.data)
            try {
                val account = task.result
                val token = account.idToken
                if (token.isNullOrBlank()) {
                    loading = false
                    error = "Google token alınamadı."
                } else {
                    auth.signInWithCredential(
                        GoogleAuthProvider.getCredential(token, null)
                    ).addOnSuccessListener { finishLogin(it.user) }
                        .addOnFailureListener { ex ->
                            loading = false
                            error = ex.message ?: "Google ile giriş başarısız."
                        }
                }
            } catch (ex: Exception) {
                loading = false
                error = ex.message ?: "Google ile giriş başarısız."
            }
        } else {
            loading = false
            error = vm.tr("Google girişi iptal edildi.", "Google sign-in was cancelled.")
        }
    }

    fun googleLogin() {
        if (activity == null) {
            error = "Google girişi başlatılamadı."
            return
        }
        val id = try {
            context.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            ""
        }
        if (id.isBlank()) {
            error = "Google yapılandırması eksik."
            return
        }
        loading = true
        error = ""
        val client = GoogleSignIn.getClient(
            context,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(id)
                .requestEmail()
                .build()
        )
        client.signOut().addOnCompleteListener {
            googleLauncher.launch(client.signInIntent)
        }
    }

    val screenBackground = Brush.verticalGradient(
        listOf(Color(0xFF030512), Color(0xFF07091A), Color(0xFF03040D))
    )
    val neonButton = Brush.horizontalGradient(
        listOf(Color(0xFF5424D9), purple, pink, Color(0xFFD9258E))
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(screenBackground)
    ) {
        // Referanstaki neon ışık atmosferini ekranın arkasında oluşturur.
        Box(
            Modifier
                .fillMaxWidth()
                .height(470.dp)
                .background(
                    Brush.radialGradient(
                        listOf(purple.copy(alpha = .24f), Color.Transparent),
                        radius = 850f
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 32.dp)
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                Surface(
                    modifier = Modifier.size(64.dp),
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF090B1B),
                    border = BorderStroke(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(purple.copy(alpha = .85f), pink.copy(alpha = .55f))
                        )
                    )
                ) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(
                            Icons.Default.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color(0xFFE5E5EF)
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Kullanıcı avatarı
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .clip(CircleShape)
                    .border(
                        2.dp,
                        Brush.sweepGradient(
                            listOf(purple, pink, orange, cyan, purple)
                        ),
                        CircleShape
                    )
                    .background(Color(0xFF080B1C)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(244.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0xFF2C174B), Color(0xFF0A0D20))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.AccountCircle,
                        contentDescription = "Profil",
                        modifier = Modifier.size(172.dp),
                        tint = purple
                    )
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier
                            .size(32.dp)
                            .offset(x = 74.dp, y = (-72).dp),
                        tint = Color(0xFFFFC1F0)
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            Text(
                vm.tr("Tekrar hoş geldin", "Welcome back"),
                fontSize = 38.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                vm.tr("Favorilerin ve hesabın seni bekliyor.", "Your favorites and account are waiting for you."),
                color = Color(0xFFB7B5C4),
                fontSize = 17.sp,
                modifier = Modifier.padding(top = 8.dp)
            )

            Box(
                Modifier
                    .padding(top = 22.dp)
                    .width(86.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.horizontalGradient(listOf(purple, pink, orange)))
            )

            Spacer(Modifier.height(28.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(purple.copy(alpha = .75f), pink.copy(alpha = .75f), orange.copy(alpha = .55f))
                        ),
                        RoundedCornerShape(28.dp)
                    ),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xCC0B0D1D)
                )
            ) {
                Column(Modifier.padding(28.dp)) {
                    Text(
                        vm.tr("Hesabına giriş yap", "Sign in to your account"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        color = Color.White
                    )

                    Spacer(Modifier.height(24.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        placeholder = { Text(vm.tr("E-posta adresin", "Email address"), color = TextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Email, null, tint = purple)
                        },
                        singleLine = true,
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(92.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = purple,
                            unfocusedBorderColor = Color(0xFF2B3044),
                            focusedContainerColor = Color(0xFF0D1020),
                            unfocusedContainerColor = Color(0xFF0D1020),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        placeholder = { Text(vm.tr("Şifren", "Password"), color = TextMuted) },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, null, tint = purple)
                        },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    null,
                                    tint = TextMuted
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        enabled = !loading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(92.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = purple,
                            unfocusedBorderColor = Color(0xFF2B3044),
                            focusedContainerColor = Color(0xFF0D1020),
                            unfocusedContainerColor = Color(0xFF0D1020),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    if (error.isNotEmpty()) {
                        Text(
                            error,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = rememberMe,
                            onCheckedChange = { rememberMe = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = purple,
                                uncheckedColor = TextMuted
                            )
                        )
                        Text(
                            vm.tr("Beni hatırla", "Remember me"),
                            color = Color(0xFFE2E0EA),
                            fontSize = 17.sp
                        )
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            Toast.makeText(context, vm.tr("Şifre sıfırlama yakında eklenecek.", "Password reset will be added soon."), Toast.LENGTH_SHORT).show()
                        }) {
                            Text(
                                vm.tr("Şifremi unuttum?", "Forgot password?"),
                                color = Color(0xFFB476FF),
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Button(
                        enabled = !loading,
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                error = vm.tr("E-posta ve şifreyi gir.", "Enter email and password.")
                                return@Button
                            }
                            loading = true
                            error = ""
                            auth.signInWithEmailAndPassword(email.trim(), password)
                                .addOnSuccessListener { finishLogin(it.user) }
                                .addOnFailureListener { ex ->
                                    loading = false
                                    error = ex.message ?: vm.tr("Giriş başarısız.", "Sign-in failed.")
                                }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(92.dp),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        contentPadding = PaddingValues()
                    ) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(neonButton, RoundedCornerShape(28.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    if (loading) vm.tr("Giriş yapılıyor...", "Signing in...") else vm.tr("Giriş yap", "Sign in"),
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(46.dp))
                                Icon(Icons.Default.ArrowForward, null, tint = Color.White, modifier = Modifier.size(30.dp))
                            }
                        }
                    }

                    Spacer(Modifier.height(24.dp))

                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(Modifier.weight(1f), color = Color(0xFF25293A))
                        Text(
                            vm.tr("veya", "or"),
                            color = TextMuted,
                            modifier = Modifier.padding(horizontal = 20.dp)
                        )
                        HorizontalDivider(Modifier.weight(1f), color = Color(0xFF25293A))
                    }

                    Spacer(Modifier.height(20.dp))

                    OutlinedButton(
                        enabled = !loading,
                        onClick = ::googleLogin,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(82.dp),
                        shape = RoundedCornerShape(22.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = BorderStroke(
                            1.dp,
                            Brush.horizontalGradient(listOf(cyan, purple, pink, orange))
                        )
                    ) {
                        Icon(
                            Icons.Default.GMobiledata,
                            null,
                            tint = Color(0xFFEA4335),
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(Modifier.width(22.dp))
                        Text(
                            vm.tr("Google ile devam et", "Continue with Google"),
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            TextButton(
                onClick = { nav.navigate("register") },
                modifier = Modifier.padding(top = 24.dp, bottom = 24.dp)
            ) {
                Text(
                    vm.tr("Hesabın yok mu? ", "No account? "),
                    color = Color(0xFFCECDD6),
                    fontSize = 17.sp
                )
                Text(
                    vm.tr("Hesap oluştur", "Create account"),
                    color = Color(0xFFB476FF),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun RegisterScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmVisible by remember { mutableStateOf(false) }
    var acceptedTerms by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val purple = Color(0xFF7B35F4)
    val pink = Color(0xFFE72F9A)
    val orange = Color(0xFFFF8B3D)
    val cyan = Color(0xFF2AABFF)
    val pageBg = Color(0xFF050716)
    val cardBg = Color(0xF00B0E20)
    val fieldBg = Color(0xFF101326)
    val neon = Brush.horizontalGradient(listOf(purple, Color(0xFF9B39E8), pink))

    fun register() {
        val cleanName = name.trim()
        when {
            cleanName.length !in 3..20 -> error = vm.tr("Kullanıcı adı 3-20 karakter arasında olmalıdır.", "Username must be 3-20 characters.")
            email.trim().isBlank() || !email.contains("@") -> error = vm.tr("Geçerli bir e-posta adresi gir.", "Enter a valid email address.")
            password.length < 6 -> error = vm.tr("Şifre en az 6 karakter olmalıdır.", "Password must be at least 6 characters.")
            password != confirmPassword -> error = vm.tr("Şifrelerin eşleşmesi gerekiyor.", "Passwords must match.")
            !acceptedTerms -> error = vm.tr("Devam etmek için kullanım şartlarını kabul et.", "Accept the terms to continue.")
            else -> {
                loading = true; error = ""
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { result ->
                        val user = result.user
                        if (user == null) { loading = false; error = vm.tr("Hesap oluşturulamadı.", "Account could not be created."); return@addOnSuccessListener }
                        val request = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                            .setDisplayName(cleanName).build()
                        user.updateProfile(request).addOnCompleteListener {
                            vm.signIn(user.email.orEmpty(), cleanName, false, context)
                            loading = false
                            nav.navigate("profile") { popUpTo("register") { inclusive = true } }
                        }
                    }
                    .addOnFailureListener { ex -> loading = false; error = ex.message ?: vm.tr("Kayıt başarısız.", "Registration failed.") }
            }
        }
    }

    Box(Modifier.fillMaxSize().background(pageBg)) {
        // Referanstaki neon uzay hissini uygulama arka planında oluşturur.
        Box(Modifier.fillMaxWidth().height(420.dp).align(Alignment.TopCenter)
            .background(Brush.radialGradient(listOf(Color(0x332B43FF), Color.Transparent))))
        Box(Modifier.size(420.dp).offset(x=(-170).dp,y=120.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(pink.copy(alpha=.20f), Color.Transparent))))
        Box(Modifier.size(380.dp).align(Alignment.TopEnd).offset(x=150.dp,y=80.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(cyan.copy(alpha=.18f), Color.Transparent))))

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().navigationBarsPadding().padding(horizontal=32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.Start) {
                Surface(Modifier.size(62.dp), shape=RoundedCornerShape(20.dp), color=Color(0xE6090B1B),
                    border=BorderStroke(1.dp, Brush.horizontalGradient(listOf(purple, pink.copy(alpha=.65f))))) {
                    IconButton(onClick={nav.popBackStack()}) { Icon(Icons.Default.ArrowBack, "Geri", tint=Color.White, modifier=Modifier.size(30.dp)) }
                }
            }

            Spacer(Modifier.height(8.dp))
            // Portre yerine uygulamanın kullanıcı simgesi; giriş ekranındaki görsel dil ile uyumlu.
            Box(Modifier.size(260.dp).clip(CircleShape)
                .border(2.dp, Brush.sweepGradient(listOf(purple,pink,orange,cyan,purple)), CircleShape)
                .background(Color(0xFF090B1C)), contentAlignment=Alignment.Center) {
                Box(Modifier.size(228.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF231342),Color(0xFF080B1C)))), contentAlignment=Alignment.Center) {
                    Icon(Icons.Default.AccountCircle, null, modifier=Modifier.size(172.dp), tint=purple)
                    Icon(Icons.Default.AutoAwesome, null, modifier=Modifier.size(30.dp).offset(x=70.dp,y=(-70).dp), tint=Color(0xFFFFC1F0))
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(vm.tr("Hesap oluştur", "Create account"), fontSize=38.sp, fontWeight=FontWeight.Bold,
                color=Color.White)
            Text(vm.tr("E-posta veya Google hesabınla kayıt ol", "Sign up with your email or Google account"),
                color=Color(0xFFC0BEC9), fontSize=17.sp, modifier=Modifier.padding(top=8.dp))
            Box(Modifier.padding(top=18.dp).width(86.dp).height(4.dp).clip(RoundedCornerShape(10.dp))
                .background(Brush.horizontalGradient(listOf(purple,pink,orange))))

            Spacer(Modifier.height(24.dp))
            Card(Modifier.fillMaxWidth().border(1.dp, Brush.linearGradient(listOf(purple.copy(alpha=.8f),pink.copy(alpha=.72f),orange.copy(alpha=.55f))), RoundedCornerShape(28.dp)),
                shape=RoundedCornerShape(28.dp), colors=CardDefaults.cardColors(containerColor=cardBg)) {
                Column(Modifier.padding(28.dp)) {
                    // Google
                    GoogleSignInButton(nav, vm, vm.tr("Google ile kayıt ol", "Sign up with Google"))
                    Row(Modifier.fillMaxWidth().padding(vertical=20.dp), verticalAlignment=Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color=Color(0xFF292C3D))
                        Text(vm.tr("veya", "or"), color=TextMuted, modifier=Modifier.padding(horizontal=18.dp))
                        HorizontalDivider(Modifier.weight(1f), color=Color(0xFF292C3D))
                    }

                    @Composable fun fieldColors() = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor=purple, unfocusedBorderColor=Color(0xFF2B3044),
                        focusedContainerColor=fieldBg, unfocusedContainerColor=fieldBg,
                        focusedTextColor=Color.White, unfocusedTextColor=Color.White,
                        cursorColor=purple
                    )
                    @Composable fun Hint(text:String) { Text(text, color=TextMuted) }

                    OutlinedTextField(name,{name=it}, placeholder={Hint(vm.tr("Kullanıcı adı","Username"))}, leadingIcon={Icon(Icons.Default.Person,null,tint=purple)},
                        modifier=Modifier.fillMaxWidth().height(78.dp), shape=RoundedCornerShape(22.dp), singleLine=true, enabled=!loading, colors=fieldColors())
                    Text(vm.tr("3-20 karakter arasında olmalıdır", "Must be between 3-20 characters"), color=TextMuted, fontSize=12.sp, modifier=Modifier.padding(start=18.dp,top=6.dp))
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(email,{email=it}, placeholder={Hint(vm.tr("E-posta adresi","Email address"))}, leadingIcon={Icon(Icons.Default.Email,null,tint=purple)},
                        modifier=Modifier.fillMaxWidth().height(78.dp), shape=RoundedCornerShape(22.dp), singleLine=true, enabled=!loading, colors=fieldColors())
                    Text(vm.tr("Geçerli bir e-posta adresi girin", "Enter a valid email address"), color=TextMuted, fontSize=12.sp, modifier=Modifier.padding(start=18.dp,top=6.dp))
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(password,{password=it}, placeholder={Hint(vm.tr("Şifre","Password"))}, leadingIcon={Icon(Icons.Default.Lock,null,tint=purple)}, trailingIcon={IconButton(onClick={passwordVisible=!passwordVisible}){Icon(if(passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,null,tint=TextMuted)}},
                        visualTransformation=if(passwordVisible) VisualTransformation.None else PasswordVisualTransformation(), modifier=Modifier.fillMaxWidth().height(78.dp), shape=RoundedCornerShape(22.dp), singleLine=true, enabled=!loading, colors=fieldColors())
                    Text(vm.tr("En az 6 karakter olmalıdır", "Must be at least 6 characters"), color=TextMuted, fontSize=12.sp, modifier=Modifier.padding(start=18.dp,top=6.dp))
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(confirmPassword,{confirmPassword=it}, placeholder={Hint(vm.tr("Şifreyi tekrar gir","Repeat password"))}, leadingIcon={Icon(Icons.Default.Lock,null,tint=purple)}, trailingIcon={IconButton(onClick={confirmVisible=!confirmVisible}){Icon(if(confirmVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,null,tint=TextMuted)}},
                        visualTransformation=if(confirmVisible) VisualTransformation.None else PasswordVisualTransformation(), modifier=Modifier.fillMaxWidth().height(78.dp), shape=RoundedCornerShape(22.dp), singleLine=true, enabled=!loading, colors=fieldColors())
                    Text(vm.tr("Şifrelerin eşleşmesi gerekiyor", "Passwords must match"), color=TextMuted, fontSize=12.sp, modifier=Modifier.padding(start=18.dp,top=6.dp))

                    Row(Modifier.fillMaxWidth().padding(top=16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Checkbox(acceptedTerms,{acceptedTerms=it}, enabled=!loading, colors=CheckboxDefaults.colors(checkedColor=purple, uncheckedColor=TextMuted))
                        Text(vm.tr("Kullanım şartlarını", "Terms of service"), color=Color(0xFFB78AFF), fontSize=14.sp)
                        Text(vm.tr(" ve gizlilik politikasını kabul ediyorum.", " and privacy policy accepted."), color=Color(0xFFC8C6D0), fontSize=14.sp)
                    }
                    if(error.isNotEmpty()) Text(error, color=MaterialTheme.colorScheme.error, fontSize=12.sp, modifier=Modifier.padding(top=4.dp))

                    Spacer(Modifier.height(18.dp))
                    Button(enabled=!loading,onClick=::register,modifier=Modifier.fillMaxWidth().height(88.dp),shape=RoundedCornerShape(28.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.Transparent),contentPadding=PaddingValues()) {
                        Box(Modifier.fillMaxSize().background(neon,RoundedCornerShape(28.dp)),contentAlignment=Alignment.Center) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Text(if(loading) vm.tr("Hesap oluşturuluyor...","Creating account...") else vm.tr("E-posta ile kayıt ol","Sign up with email"),color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold)
                                Spacer(Modifier.width(36.dp)); Icon(Icons.Default.ArrowForward,null,tint=Color.White,modifier=Modifier.size(30.dp))
                            }
                        }
                    }
                }
            }
            TextButton(enabled=!loading,onClick={nav.popBackStack()},modifier=Modifier.padding(top=22.dp,bottom=18.dp)) {
                Text(vm.tr("Zaten hesabın var mı? ","Already have an account? "),color=Color(0xFFCECDD6),fontSize=17.sp)
                Text(vm.tr("Giriş yap","Sign in"),color=Color(0xFFB476FF),fontSize=17.sp,fontWeight=FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun GoogleSignInButton(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, label: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
    val activity = context.findActivity()
    val auth = remember { FirebaseAuth.getInstance() }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun finish(user: FirebaseUser?) {
        if (user == null) { loading=false; error="Google hesabı alınamadı."; return }
        vm.signIn(user.email.orEmpty(), user.displayName ?: user.email?.substringBefore("@").orEmpty(), false, context)
        loading=false
        nav.navigate("profile") { launchSingleTop = true }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK) {
            loading=false
            error="Google hesabı seçilmedi veya giriş iptal edildi."
            return@rememberLauncherForActivityResult
        }
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                .getResult(com.google.android.gms.common.api.ApiException::class.java)
            val token = account.idToken
            if (token.isNullOrBlank()) {
                loading=false; error="Google kimlik belirteci alınamadı. google-services.json ve OAuth istemci yapılandırmasını kontrol et."
            } else {
                auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null))
                    .addOnSuccessListener { finish(it.user) }
                    .addOnFailureListener { ex -> loading=false; error=ex.message ?: "Firebase Google girişi başarısız." }
            }
        } catch (ex: com.google.android.gms.common.api.ApiException) {
            loading=false
            error = "Google giriş hatası (${ex.statusCode}): " + when(ex.statusCode) {
                10 -> "Bu APK'nın SHA-1/SHA-256 değeri Firebase'e eklenmemiş veya OAuth Android istemcisi eşleşmiyor."
                12500 -> "OAuth istemcisi yapılandırılmamış."
                7 -> "Ağ bağlantısını kontrol et."
                else -> (ex.message ?: "Google hesabı doğrulanamadı.")
            }
        } catch (ex: Exception) { loading=false; error=ex.message ?: "Google girişi başarısız." }
    }

    OutlinedButton(enabled=!loading, onClick={
        if (activity == null) { error="Google girişi bu cihazda başlatılamadı."; return@OutlinedButton }
        val webClientId = try { context.getString(R.string.default_web_client_id) } catch (_: Exception) { "" }
        if (webClientId.isBlank()) { error="default_web_client_id bulunamadı. Güncel google-services.json gerekli."; return@OutlinedButton }
        loading=true; error=""
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId).requestEmail().build()
        val client = GoogleSignIn.getClient(context, options)
        client.signOut().addOnCompleteListener { launcher.launch(client.signInIntent) }
    }, modifier=Modifier.fillMaxWidth().height(50.dp), colors=ButtonDefaults.outlinedButtonColors(contentColor=Color.White)) {
        Icon(Icons.Default.AccountCircle, null, tint=Color.White); Spacer(Modifier.width(8.dp)); Text(if(loading) "Google açılıyor..." else label, color=Color.White)
    }
    if(error.isNotEmpty()) Text(error, color=MaterialTheme.colorScheme.error, fontSize=11.sp, modifier=Modifier.padding(top=6.dp))
}

@Composable
fun GuestProfileScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val scroll = rememberScrollState()
    Box(Modifier.fillMaxSize().background(Color(0xFF03030B))) {
        // Referans ekrandaki koyu zemin ve iki taraftan gelen neon ışık akışları.
        Box(Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF02020A), Color(0xFF060616), Color(0xFF020208)))
        ))
        Box(Modifier.fillMaxWidth().height(470.dp).align(Alignment.TopCenter).background(
            Brush.radialGradient(listOf(Color(0xFF24105E).copy(alpha=.30f), Color.Transparent))
        ))
        Box(
            Modifier.width(210.dp).height(600.dp).align(Alignment.TopStart)
                .graphicsLayer { rotationZ = -18f }
                .background(Brush.radialGradient(listOf(Color(0xFFD900C0).copy(alpha=.22f), Color(0xFF205CFF).copy(alpha=.12f), Color.Transparent)))
        )
        Box(
            Modifier.width(240.dp).height(600.dp).align(Alignment.TopEnd)
                .graphicsLayer { rotationZ = 20f }
                .background(Brush.radialGradient(listOf(Color(0xFFFF4D18).copy(alpha=.23f), Color(0xFFE718A5).copy(alpha=.15f), Color.Transparent)))
        )

        Column(
            Modifier.fillMaxSize().verticalScroll(scroll)
                .padding(horizontal=26.dp, vertical=18.dp),
            horizontalAlignment=Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier=Modifier.size(190.dp), shape=CircleShape,
                color=Color(0xFF080813).copy(alpha=.82f),
                border=BorderStroke(1.7.dp, Brush.linearGradient(listOf(Color(0xFF605BFF), Color(0xFFFF5B8F)))),
                shadowElevation=10.dp
            ) {
                Box(contentAlignment=Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint=Color(0xFF9554FF), modifier=Modifier.size(82.dp))
                    Icon(Icons.Default.AutoAwesome, null, tint=Color(0xFFF3C5FF), modifier=Modifier.size(24.dp).align(Alignment.TopEnd).padding(3.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("Kullanıcı", color=Color(0xFF9A63FF), fontSize=31.sp, fontWeight=FontWeight.ExtraBold)
                Spacer(Modifier.width(7.dp))
                Text("Profili", color=Color.White, fontSize=31.sp, fontWeight=FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(8.dp))
            Text(vm.tr("Favorilerin, geçmişin ve hesabın için giriş yap.","Sign in for your favorites, history and account."), color=Color.White.copy(alpha=.62f), fontSize=14.sp)

            Spacer(Modifier.height(26.dp))
            Surface(
                modifier=Modifier.fillMaxWidth().height(74.dp).clickable { nav.navigate("login") },
                shape=RoundedCornerShape(38.dp), color=Color.Transparent,
                border=BorderStroke(1.dp, Color.White.copy(alpha=.48f))
            ) {
                Row(
                    Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF6424E8), Color(0xFFA13DDD), Color(0xFFDD2E98)))).padding(horizontal=42.dp),
                    verticalAlignment=Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Person, null, modifier=Modifier.size(28.dp), tint=Color.White)
                    Spacer(Modifier.width(26.dp))
                    Text(vm.tr("Giriş yap","Sign in"), color=Color.White, fontSize=19.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                    Icon(Icons.Default.ArrowForward, null, modifier=Modifier.size(34.dp), tint=Color.White)
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                HorizontalDivider(Modifier.weight(1f), color=Color.White.copy(alpha=.12f))
                Text(vm.tr("veya devam et","or continue"), color=Color.White.copy(alpha=.56f), fontSize=13.sp, modifier=Modifier.padding(horizontal=20.dp))
                HorizontalDivider(Modifier.weight(1f), color=Color.White.copy(alpha=.12f))
            }
            Spacer(Modifier.height(20.dp))

            // Google satırı doğrudan giriş ekranına gider; Google OAuth işlemi burada başlatılır.
            GuestProfileReferenceRow(
                icon=Icons.Default.AccountCircle,
                title=vm.tr("Google ile devam et","Continue with Google"),
                subtitle=vm.tr("Tek tıkla hızlı ve güvenli giriş","Fast and secure sign in"),
                iconTint=Color(0xFF7D64FF),
                textColor=vm.currentTextColor
            ) { nav.navigate("login") }
            Spacer(Modifier.height(12.dp))
            GuestProfileReferenceRow(
                icon=Icons.Default.Email,
                title=vm.tr("Hesap oluştur","Create account"),
                subtitle=vm.tr("Yeni bir hesap oluşturarak başla","Create a new account to begin"),
                iconTint=Color(0xFFB24CFF),
                textColor=vm.currentTextColor
            ) { nav.navigate("register") }

            Spacer(Modifier.height(24.dp))
            Surface(
                modifier=Modifier.fillMaxWidth().heightIn(min=205.dp), shape=RoundedCornerShape(28.dp),
                color=Color(0xFF090A18).copy(alpha=.90f), border=BorderStroke(1.dp, Color(0xFF2B3553))
            ) {
                Row(Modifier.fillMaxWidth().padding(vertical=22.dp, horizontal=8.dp), horizontalArrangement=Arrangement.SpaceEvenly) {
                    ProfileBenefit(Icons.Default.Favorite, vm.tr("Favorilerini Kaydet","Save Favorites"), vm.tr("Beğendiğin duvar\nkâğıtlarını kaydet.","Save wallpapers\nyou like."), Color(0xFFFF5B9E), Modifier.weight(1f))
                    VerticalDivider(Modifier.padding(vertical=18.dp), color=Color.White.copy(alpha=.08f))
                    ProfileBenefit(Icons.Default.History, vm.tr("Geçmişini Gör","View History"), vm.tr("Görüntülediklerini\ntakip et.","Track viewed wallpapers."), Color(0xFF7183FF), Modifier.weight(1f))
                    VerticalDivider(Modifier.padding(vertical=18.dp), color=Color.White.copy(alpha=.08f))
                    ProfileBenefit(Icons.Default.CloudUpload, vm.tr("Cihazlarınla Senkronize","Sync Devices"), vm.tr("Hesabınla tüm cihazlarında\nerişim sağla.","Access on all devices\nwith your account."), Color(0xFFFF8A6B), Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(18.dp))
            WextraProCard { nav.navigate("pro") }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.padding(bottom=6.dp)) {
                Icon(Icons.Default.VerifiedUser, null, tint=Color(0xFF9B52FF), modifier=Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(vm.tr("Verilerin güvende. Gizliliğin bizim önceliğimiz.","Your data is secure. Privacy comes first."), color=Color.White.copy(alpha=.54f), fontSize=11.sp)
            }
        }
    }
}

@Composable
private fun GuestProfileReferenceRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String, subtitle: String, iconTint: Color, textColor: Color, onClick: () -> Unit
) {
    Surface(
        modifier=Modifier.fillMaxWidth().height(108.dp).clickable { onClick() },
        shape=RoundedCornerShape(24.dp), color=Color(0xFF0A0B19).copy(alpha=.92f),
        border=BorderStroke(1.dp, Color(0xFF28334D))
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal=24.dp), verticalAlignment=Alignment.CenterVertically) {
            Surface(Modifier.size(58.dp), shape=CircleShape, color=Color(0xFF101127), border=BorderStroke(1.dp, iconTint.copy(alpha=.6f))) {
                Box(contentAlignment=Alignment.Center) { Icon(icon,null,tint=iconTint,modifier=Modifier.size(30.dp)) }
            }
            Spacer(Modifier.width(22.dp))
            Column(Modifier.weight(1f)) {
                // Yazılar tema varsayılanına bırakılmaz; Ayarlar > Yazı Rengi seçimine bağlıdır.
                Text(title, color=textColor, fontSize=17.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(7.dp))
                Text(subtitle, fontSize=12.sp, color=textColor.copy(alpha=.68f))
            }
            Icon(Icons.Default.ArrowForward, null, tint=Color(0xFFB74CFF), modifier=Modifier.size(30.dp))
        }
    }
}

@Composable
private fun ProfileBenefit(icon: androidx.compose.ui.graphics.vector.ImageVector, title:String, body:String, tint:Color, modifier:Modifier=Modifier) {
    Column(modifier, horizontalAlignment=Alignment.CenterHorizontally) {
        Surface(Modifier.size(62.dp), shape=CircleShape, color=Color(0xFF10111F), border=BorderStroke(1.dp,tint.copy(alpha=.35f))) {
            Box(contentAlignment=Alignment.Center) { Icon(icon,null,tint=tint,modifier=Modifier.size(29.dp)) }
        }
        Spacer(Modifier.height(16.dp))
        Text(title, textAlign=androidx.compose.ui.text.style.TextAlign.Center, color=tint.copy(alpha=.95f), fontSize=12.sp, fontWeight=FontWeight.SemiBold, maxLines=2)
        Spacer(Modifier.height(8.dp))
        Text(body, textAlign=androidx.compose.ui.text.style.TextAlign.Center, color=Color.White.copy(alpha=.52f), fontSize=10.sp, lineHeight=17.sp, maxLines=3)
    }
}

@Composable
fun ProfileScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var nameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    val firebaseUser = FirebaseAuth.getInstance().currentUser
    if (firebaseUser == null && vm.currentUserEmail == null) { GuestProfileScreen(nav, vm); return }

    val email = firebaseUser?.email ?: vm.currentUserEmail
    val displayName = firebaseUser?.displayName ?: vm.currentUserName.ifBlank { "Wextra Kullanıcısı" }
    val photo = firebaseUser?.photoUrl
    val favoriteCount = vm.favorites.size
    val completion = when { photo != null && !email.isNullOrBlank() && displayName.isNotBlank() -> 100; !email.isNullOrBlank() && displayName.isNotBlank() -> 60; else -> 35 }
    val accentA = Color(0xFF9B3DFF); val accentB = Color(0xFF11C9FF); val danger = Color(0xFFFF3B69)

    LazyColumn(
        modifier=Modifier.fillMaxSize().background(Color(0xFF03040D)).padding(horizontal=16.dp),
        contentPadding=PaddingValues(top=16.dp,bottom=12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(28.dp),
                colors=CardDefaults.cardColors(containerColor=Color(0xFF0B0E1F)),
                border=BorderStroke(1.dp, Brush.linearGradient(listOf(Color(0xFF9B3DFF),Color(0xFF1BCFFF))))
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Surface(Modifier.size(118.dp),shape=CircleShape,color=Color(0xFF0A0B17),border=BorderStroke(2.dp,Brush.linearGradient(listOf(accentA,accentB)))) {
                        if(photo!=null) AsyncImage(photo,"Profil fotoğrafı",Modifier.fillMaxSize().clip(CircleShape),contentScale=ContentScale.Crop)
                        else Box(contentAlignment=Alignment.Center){ Text(displayName.take(1).uppercase(),fontSize=44.sp,fontWeight=FontWeight.ExtraBold,color=Color.White) }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(displayName,color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold)
                    Text(email ?: "Misafir kullanıcı",color=Color(0xFFADB0C0),fontSize=14.sp)
                    Spacer(Modifier.height(10.dp))
                    Surface(shape=RoundedCornerShape(50),color=Color(0xFF111528),border=BorderStroke(1.dp,Color(0xFF8991AE).copy(alpha=.45f))) {
                        Row(Modifier.padding(horizontal=15.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.WorkspacePremium,null,tint=Color(0xFFFFB53D),modifier=Modifier.size(19.dp));Spacer(Modifier.width(8.dp));Text(if(favoriteCount>0) "Aktif Kullanıcı" else "Yeni Kullanıcı",color=Color(0xFFE8E9F2),fontWeight=FontWeight.Medium) }
                    }
                    HorizontalDivider(Modifier.padding(top=18.dp),color=Color.White.copy(alpha=.10f))
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                        Box(contentAlignment=Alignment.Center,modifier=Modifier.size(72.dp)) {
                            CircularProgressIndicator(progress={completion/100f},modifier=Modifier.size(66.dp),strokeWidth=7.dp,color=accentB,trackColor=Color(0xFF1A1D2D))
                            Text("$completion%",fontWeight=FontWeight.Bold,color=Color.White,fontSize=14.sp)
                        }
                        Spacer(Modifier.width(15.dp));Column(Modifier.weight(1f)){Text("Profil tamamlama oranı",color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=16.sp);Text("Profilini tamamlayarak deneyimini\nkişiselleştir.",color=Color(0xFFABB0C1),fontSize=12.sp)}
                        Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFAEB2C3))
                    }
                }
            }
        }
        item { WextraProCard { nav.navigate("pro") } }
        item { ProfileSectionTitle("KULLANICI ALANLARIM") }
        item {
            NeonListCard {
                ProfileReferenceRow(Icons.Default.Favorite,"Favorilerim",if(favoriteCount==0)"0 duvar kâğıdı" else "$favoriteCount duvar kâğıdı",accentA){nav.navigate("favorites")}
                HorizontalDivider(color=Color.White.copy(alpha=.09f))
                ProfileReferenceRow(Icons.Default.History,"Geçmişim","Görüntülediklerin",Color(0xFF9C61FF)){nav.navigate("history")}
                HorizontalDivider(color=Color.White.copy(alpha=.09f))
                ProfileReferenceRow(Icons.Default.Folder,"Koleksiyonlarım","Kendi listelerin",Color(0xFFB24CFF)){nav.navigate("collections")}
            }
        }
        item { ProfileSectionTitle("HESABIM") }
        item {
            NeonListCard {
                ProfileReferenceRow(Icons.Default.Edit,"Kullanıcı adını değiştir","Profil adını güncelle",Color(0xFFAA5DFF)){newName=displayName;nameDialog=true}
                HorizontalDivider(color=Color.White.copy(alpha=.09f))
                ProfileReferenceRow(Icons.Default.Logout,"Çıkış yap","Hesaptan güvenli çıkış",Color(0xFF9A61FF)){vm.signOut(context);nav.navigate("login"){popUpTo(0)}}
                HorizontalDivider(color=Color.White.copy(alpha=.09f))
                ProfileReferenceRow(Icons.Default.Delete,"Hesabımı kalıcı olarak sil","Bu işlem geri alınamaz",danger,true){deleteDialog=true}
            }
        }
    }
    if(nameDialog) AlertDialog(onDismissRequest={nameDialog=false},containerColor=Color(0xFF101326),title={Text("Kullanıcı adını değiştir",color=Color.White)},text={OutlinedTextField(newName,{newName=it},label={Text("Yeni kullanıcı adı")},singleLine=true)},confirmButton={TextButton(onClick={val t=newName.trim();if(t.isNotEmpty()){val req=com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(t).build();FirebaseAuth.getInstance().currentUser?.updateProfile(req);vm.updateName(t,context);Toast.makeText(context,"Kullanıcı adı güncellendi.",Toast.LENGTH_SHORT).show()};nameDialog=false}){Text("Kaydet")}},dismissButton={TextButton(onClick={nameDialog=false}){Text("İptal")}})
    if(deleteDialog) AlertDialog(onDismissRequest={deleteDialog=false},containerColor=Color(0xFF101326),title={Text("Hesabı sil",color=Color.White)},text={Text("Hesabın kalıcı olarak silinecek. Bu işlem geri alınamaz. Devam etmek istiyor musun?",color=Color(0xFFC1C5D2))},confirmButton={TextButton(onClick={FirebaseAuth.getInstance().currentUser?.delete()?.addOnCompleteListener{vm.signOut(context);nav.navigate("login"){popUpTo(0)}};deleteDialog=false}){Text("Kalıcı olarak sil",color=danger)}},dismissButton={TextButton(onClick={deleteDialog=false}){Text("Vazgeç")}})
}

@Composable
private fun WextraProCard(onClick:()->Unit) {
    Surface(
        modifier=Modifier.fillMaxWidth().clickable(onClick=onClick),
        shape=RoundedCornerShape(26.dp),
        color=Color(0xFF101226),
        border=BorderStroke(1.dp, Brush.linearGradient(listOf(Color(0xFFB03CFF), Color(0xFFFF6B3D), Color(0xFFFFC857))))
    ) {
        Row(
            Modifier.fillMaxWidth().background(
                Brush.horizontalGradient(listOf(Color(0xFF17103A), Color(0xFF1A1230), Color(0xFF25101D)))
            ).padding(18.dp),
            verticalAlignment=Alignment.CenterVertically
        ) {
            Surface(Modifier.size(58.dp),shape=RoundedCornerShape(18.dp),color=Color(0xFFFFB93E).copy(alpha=.12f),border=BorderStroke(1.dp,Color(0xFFFFC857).copy(alpha=.35f))) {
                Box(contentAlignment=Alignment.Center) { Icon(Icons.Default.WorkspacePremium,null,tint=Color(0xFFFFC857),modifier=Modifier.size(31.dp)) }
            }
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text("Wextra Pro",color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=20.sp)
                Text("Reklamsız deneyim ve özel içerikler",color=Color(0xFFC8C9D6),fontSize=12.sp)
                Spacer(Modifier.height(5.dp))
                Text("Avantajları ve fiyatları gör",color=Color(0xFFFFC857),fontSize=12.sp,fontWeight=FontWeight.Bold)
            }
            Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFFFD38A),modifier=Modifier.size(30.dp))
        }
    }
}

@Composable
fun ProScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context=androidx.compose.ui.platform.LocalContext.current
    var selected by rememberSaveable { mutableStateOf("Aylık") }
    val price=if(selected=="Aylık") "₺49,99 / ay" else "₺399,99 / yıl"
    LazyColumn(
        modifier=Modifier.fillMaxSize().background(Color(0xFF03040D)).padding(horizontal=18.dp),
        contentPadding=PaddingValues(top=20.dp,bottom=32.dp), verticalArrangement=Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={nav.popBackStack()}) { Icon(Icons.Default.ArrowBack,"Geri",tint=Color.White) }
                Column(Modifier.padding(start=6.dp)) { Text("Wextra Pro",color=Color.White,fontSize=28.sp,fontWeight=FontWeight.ExtraBold); Text("Daha fazlasını keşfet",color=Color(0xFFB7BAC8),fontSize=13.sp) }
            }
        }
        item {
            Card(shape=RoundedCornerShape(30.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF12142A)),border=BorderStroke(1.dp,Brush.linearGradient(listOf(Color(0xFFB03CFF),Color(0xFFFF6B3D),Color(0xFFFFC857))))) {
                Column(Modifier.fillMaxWidth().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                    Surface(Modifier.size(74.dp),shape=CircleShape,color=Color(0xFFFFC857).copy(alpha=.12f)) { Box(contentAlignment=Alignment.Center){Icon(Icons.Default.WorkspacePremium,null,tint=Color(0xFFFFC857),modifier=Modifier.size(40.dp))} }
                    Spacer(Modifier.height(14.dp)); Text("Wextra Pro ile sınırları kaldır",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("Özel içerikler • Reklamsız deneyim • Öncelikli yenilikler",color=Color(0xFFBFC2D0),fontSize=13.sp)
                }
            }
        }
        item { Text("PRO AVANTAJLARI",color=Color(0xFFA7AABC),fontWeight=FontWeight.Bold,fontSize=13.sp,letterSpacing=1.sp) }
        items(listOf(
            Triple(Icons.Default.Block,"Reklamsız deneyim","Daha temiz ve kesintisiz kullanım"),
            Triple(Icons.Default.AutoAwesome,"Özel içerikler","Pro üyelerine özel seçkiler"),
            Triple(Icons.Default.HighQuality,"Yüksek kalite önceliği","Yeni kalite özelliklerine erken erişim")
        )) { (icon,title,subtitle) ->
            NeonListCard { ProfileReferenceRow(icon,title,subtitle,Color(0xFFB86BFF)){} }
        }
        item { Text("PLANINI SEÇ",color=Color(0xFFA7AABC),fontWeight=FontWeight.Bold,fontSize=13.sp,letterSpacing=1.sp) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                listOf("Aylık","Yıllık").forEach { plan ->
                    val active=selected==plan
                    Surface(Modifier.weight(1f).clickable{selected=plan},shape=RoundedCornerShape(18.dp),color=if(active) Color(0xFF6E35D8) else Color(0xFF111425),border=BorderStroke(1.dp,if(active) Color(0xFFC075FF) else Color(0xFF3A4059))) {
                        Column(Modifier.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(plan,color=Color.White,fontWeight=FontWeight.Bold);Text(if(plan=="Aylık") "₺49,99" else "₺399,99",color=Color(0xFFFFC857),fontWeight=FontWeight.ExtraBold,fontSize=18.sp)}
                    }
                }
            }
        }
        item {
            Button(onClick={Toast.makeText(context,"Ödeme altyapısı eklendiğinde Pro üyeliği buradan etkinleştirilecek.",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth().height(58.dp),shape=RoundedCornerShape(18.dp),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF7C3AED))) { Text("Pro'ya Geç • $price",fontWeight=FontWeight.Bold,fontSize=16.sp) }
        }
        item { Text("Ödeme sistemi henüz aktif değil. Bu ekran, Pro üyelik ve fiyatlandırma alanı için hazırlandı.",color=Color(0xFF7F8495),fontSize=11.sp) }
    }
}

@Composable private fun ProfileSectionTitle(text:String){Text(text,color=Color(0xFFA7AABC),fontWeight=FontWeight.Bold,fontSize=14.sp,letterSpacing=1.sp,modifier=Modifier.padding(start=8.dp,top=10.dp))}
@Composable private fun NeonListCard(content:@Composable ColumnScope.()->Unit){Card(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF101326)),border=BorderStroke(1.dp,Color(0xFF66708E).copy(alpha=.38f))){Column(content=content)}}
@Composable private fun ProfileReferenceRow(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,subtitle:String,tint:Color,danger:Boolean=false,onClick:()->Unit){Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(horizontal=18.dp,vertical=17.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(52.dp),shape=RoundedCornerShape(15.dp),color=tint.copy(alpha=.08f),border=BorderStroke(1.dp,tint.copy(alpha=.22f))){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=tint,modifier=Modifier.size(27.dp))}};Spacer(Modifier.width(18.dp));Column(Modifier.weight(1f)){Text(title,color=if(danger)Color(0xFFFFCDD7) else Color.White,fontWeight=FontWeight.SemiBold,fontSize=17.sp);Text(subtitle,color=if(danger)Color(0xFFFF7B95) else Color(0xFFA7ABBB),fontSize=13.sp)};Icon(Icons.Default.ChevronRight,null,tint=Color(0xFFA9ADBC))}}

@Composable
fun UserActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
    }
}


@Composable
fun HistoryScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val list = vm.recentIds.mapNotNull { id -> vm.wallpapers.firstOrNull { it.id==id } }
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text("Son Görüntülenenler",fontSize=24.sp,fontWeight=FontWeight.Bold)}
        if(list.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("Henüz görüntüleme geçmişi yok.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        else LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){items(list){WallpaperCard(it,vm,nav)}}
    }
}
@Composable
fun CollectionsScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val context=androidx.compose.ui.platform.LocalContext.current
    var name by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text("Koleksiyonlarım",fontSize=24.sp,fontWeight=FontWeight.Bold)}
        Row{OutlinedTextField(name,{name=it},label={Text("Yeni koleksiyon")},modifier=Modifier.weight(1f));Spacer(Modifier.width(8.dp));Button(onClick={vm.createCollection(name,context);name=""}){Text("Ekle")}}
        Spacer(Modifier.height(16.dp))
        if(vm.collections.isEmpty()) Text("Henüz koleksiyon oluşturmadın.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(vm.collections.keys.toList()){n->Card{Column(Modifier.padding(16.dp)){Text(n,fontWeight=FontWeight.Bold,fontSize=18.sp);Text("${vm.collections[n]?.size ?: 0} duvar kâğıdı",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)}}}}
    }
}

@Composable
fun SimpleUserListScreen(
    title: String,
    emptyMessage: String,
    nav: androidx.navigation.NavHostController
) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyMessage, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp).statusBarsPadding().navigationBarsPadding()) {
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
            Surface(Modifier.size(48.dp), shape = RoundedCornerShape(15.dp), color = Color(0xFF0C1020), border = BorderStroke(1.dp, vm.currentAccent.copy(alpha=.45f))) {
                Image(painterResource(R.drawable.wextra_logo), "WEXTRA", Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
            }
            Spacer(Modifier.width(12.dp)); Column { Text("Ayarlar", fontSize=27.sp, fontWeight=FontWeight.ExtraBold); Text("WEXTRA'yı senin için daha özel hale getir.", color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp) }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value="", onValueChange={}, enabled=false, placeholder={Text("Ayar arayın...")}, leadingIcon={Icon(Icons.Default.Search,null)}, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp), singleLine=true)
        SettingsHero(title="WEXTRA Pro", subtitle="Daha fazlasını keşfet", icon=Icons.Default.Star, accent=Color(0xFFFFC83D), onClick={nav.navigate("pro")})
        Spacer(Modifier.height(4.dp))
        SettingsMainRow(Icons.Default.Palette, "Görünüm", "Tema, renk ve arayüz ayarları", vm.currentAccent) { nav.navigate("settingsAppearance") }
        SettingsMainRow(Icons.Default.Wallpaper, "Duvar Kâğıdı", "Önizleme ve duvar kâğıdı ayarları", Color(0xFF2CCBFF)) { nav.navigate("settingsWallpaper") }
        SettingsMainRow(Icons.Default.Notifications, "Bildirimler", "Sana özel bildirim ayarları", Color(0xFFFF5CA8)) { nav.navigate("settingsNotifications") }
        SettingsMainRow(Icons.Default.Favorite, "İçerik Tercihleri", "İlgi alanlarına göre kişiselleştir", Color(0xFFFF5CA8)) { nav.navigate("settingsPreferences") }
        SettingsMainRow(Icons.Default.Person, "Hesap ve Veri", "Hesap, senkronizasyon ve yedekleme", Color(0xFF36CFFF)) { nav.navigate("settingsAccount") }
        SettingsMainRow(Icons.Default.Security, "Gizlilik ve Güvenlik", "Verilerin her zaman güvende", Color(0xFF49DCA7)) { nav.navigate("settingsPrivacy") }
        SettingsMainRow(Icons.Default.Info, "Uygulama Hakkında", "Sürüm, lisans ve iletişim", Color(0xFF7C8CFF)) { nav.navigate("settingsAbout") }
        Spacer(Modifier.height(14.dp))
        SettingsCard { Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.DarkMode,null,tint=vm.currentAccent); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("Koyu arayüz",fontWeight=FontWeight.Bold);Text("Eclipse tasarımı için önerilen görünüm",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}; Switch(checked=vm.currentTheme.dark,onCheckedChange={ if(it) vm.setThemeChoice(0,context) }) } }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SettingsDetailScaffold(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal=10.dp, vertical=8.dp), verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)}; Text(title,fontSize=21.sp,fontWeight=FontWeight.Bold) }
        Box(Modifier.weight(1f).navigationBarsPadding()) { content() }
    }
}

@Composable private fun SettingsHero(title:String, subtitle:String, icon:androidx.compose.ui.graphics.vector.ImageVector, accent:Color, onClick:()->Unit) {
    Card(onClick=onClick, modifier=Modifier.fillMaxWidth().padding(top=10.dp), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF17102D)), border=BorderStroke(1.dp, Brush.linearGradient(listOf(accent, MaterialTheme.colorScheme.primary)))) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically){ Surface(Modifier.size(48.dp),shape=RoundedCornerShape(15.dp),color=accent.copy(alpha=.18f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=accent)}}; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)){Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=16.sp);Text(subtitle,color=Color.White.copy(alpha=.68f),fontSize=12.sp)};Icon(Icons.Default.ChevronRight,null,tint=Color.White)}
    }
}

@Composable private fun SettingsMainRow(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,subtitle:String,accent:Color,onClick:()->Unit) {
    Card(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(top=8.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),border=BorderStroke(1.dp,Color.White.copy(alpha=.05f))){
        Row(Modifier.padding(horizontal=14.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(42.dp),shape=RoundedCornerShape(13.dp),color=accent.copy(alpha=.14f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=accent)}};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontWeight=FontWeight.Bold,fontSize=14.sp);Text(subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=11.sp,maxLines=1)};Icon(Icons.Default.ChevronRight,null,tint=TextMuted)}
    }
}

@Composable private fun SettingsCard(content:@Composable ColumnScope.()->Unit){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),border=BorderStroke(1.dp,Color.White.copy(alpha=.05f))){Column(Modifier.padding(14.dp),content=content)}}

@Composable fun AppearanceSettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){
    val context=androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){
        SettingsBanner("Senin Tarzın\nSenin Renklerin", "WEXTRA", vm.currentAccent)
        Text("Tema",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=8.dp)); ThemeChoiceCompact(vm)
        Text("Vurgu Rengi",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp,bottom=8.dp)); AccentChoiceRow(vm)
        Text("Yazı Rengi",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=14.dp,bottom=8.dp)); TextColorChoiceRow(vm)
        SettingsSwitch(Icons.Default.AutoAwesome,"Dinamik Renkler","Arayüzü seçilen vurgu rengine göre uyarla",true){ }
        SettingsSwitch(Icons.Default.ViewCompact,"Kompakt Görünüm","Daha fazla içerik göster",false){ }
        SettingsSwitch(Icons.Default.Animation,"Animasyonları Azalt","Daha akıcı bir deneyim",!vm.animationsEnabled){vm.setAnimations(!it,context)}
        SettingsSwitch(Icons.Default.Vibration,"Titreşim Efektleri","Dokunma geri bildirimi",true){ }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable private fun ThemeChoiceCompact(vm:WallpaperViewModel){ val context=androidx.compose.ui.platform.LocalContext.current; LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(vm.themeOptions){item->val selected=vm.currentTheme.name==item.name;Card(onClick={vm.setThemeChoice(vm.themeOptions.indexOf(item), context)},modifier=Modifier.width(104.dp).height(82.dp),shape=RoundedCornerShape(16.dp),border=if(selected)BorderStroke(2.dp,vm.currentAccent) else BorderStroke(1.dp,Color.White.copy(alpha=.08f)),colors=CardDefaults.cardColors(containerColor=item.surface)){Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(item.accent.copy(alpha=.28f),item.background))).padding(10.dp),verticalArrangement=Arrangement.SpaceBetween){Icon(if(item.dark)Icons.Default.DarkMode else Icons.Default.LightMode,null,tint=item.accent);Text(item.name,fontSize=11.sp,fontWeight=FontWeight.Bold,maxLines=1)}}}}}

@Composable private fun AccentChoiceRow(vm:WallpaperViewModel){val context=androidx.compose.ui.platform.LocalContext.current;LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)){items(vm.accentOptions){item->val selected=vm.currentAccent==item.second;Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(52.dp).clickable{vm.setAccent(vm.accentOptions.indexOf(item),context)}){Surface(Modifier.size(34.dp),shape=CircleShape,color=item.second,border=if(selected)BorderStroke(3.dp,Color.White) else null){};Text(item.first.removePrefix("Eclipse "),fontSize=9.sp,maxLines=1)}}}}
@Composable private fun TextColorChoiceRow(vm:WallpaperViewModel){val context=androidx.compose.ui.platform.LocalContext.current;LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp)){items(vm.textColorOptions){item->val selected=vm.currentTextColor==item.second;Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.width(58.dp).clickable{vm.setTextColor(vm.textColorOptions.indexOf(item),context)}){Surface(Modifier.size(30.dp),shape=CircleShape,color=item.second,border=if(selected)BorderStroke(2.dp,vm.currentAccent) else null){};Text(item.first,fontSize=8.sp,maxLines=1)}}}}

@Composable fun WallpaperSettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){val c=androidx.compose.ui.platform.LocalContext.current;Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("Her Ekran\nYeni Bir Hikâye","WEXTRA",vm.currentAccent);SettingsRow(Icons.Default.HighQuality,"Duvar Kâğıdı Önizleme Kalitesi",vm.selectedResolution.label){ } ;SettingsSwitch(Icons.Default.Refresh,"Otomatik Duvar Kâğıdı Değiştir","Belirlediğin aralıklarla yeni görseller",vm.dailyEnabled){vm.setDaily(it,c)};SettingsRow(Icons.Default.Schedule,"Değişim Sıklığı","Her gün"){};SettingsRow(Icons.Default.FitScreen,"Ekrana Sığdırma Tercihi","Ekrana en uygun görünüm"){};SettingsSwitch(Icons.Default.Image,"Önizleme Animasyonları","Daha akıcı bir gezinme deneyimi",vm.animationsEnabled){vm.setAnimations(it,c)};SettingsSwitch(Icons.Default.Star,"Günün Duvar Kâğıdı","Her gün senin için özel bir seçim",vm.dailyEnabled){vm.setDaily(it,c)};SettingsRow(Icons.Default.Favorite,"Favorileri Yönet", "Favori duvar kâğıtlarını düzenle"){nav.navigate("favorites")};SettingsBanner("Güzel duvar kâğıtları,\ndaha güzel bir sen.","WEXTRA",vm.currentAccent)}

@Composable fun NotificationSettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){val c=androidx.compose.ui.platform.LocalContext.current;Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("Sana Özel Bildirimler","Önemli içerikleri kaçırma.",Color(0xFFFF5CA8));SettingsSwitch(Icons.Default.Notifications,"Yeni Duvar Kâğıtları","Koleksiyonlar eklendiğinde",vm.notificationsEnabled){vm.setNotifications(it,c)};SettingsSwitch(Icons.Default.Whatshot,"Popüler Olanlar","Trend içeriklerden haberdar ol",vm.notificationsEnabled){vm.setNotifications(it,c)};SettingsSwitch(Icons.Default.AutoAwesome,"Günün Duvar Kâğıdı","Her gün özel bir öneri al",vm.dailyEnabled){vm.setDaily(it,c)};SettingsSwitch(Icons.Default.Campaign,"WEXTRA Duyuruları","Önemli güncellemeler ve haberler",vm.notificationsEnabled){vm.setNotifications(it,c)};SettingsSwitch(Icons.Default.NotificationsActive,"Sadece Önemli Bildirimler","Diğer bildirimleri sessize al",false){};SettingsRow(Icons.Default.VolumeUp,"Bildirim Sesleri","Varsayılan"){};SettingsRow(Icons.Default.Bedtime,"Rahatsız Etme Modu","Belirli saatlerde bildirimleri kapat"){};SettingsBanner("Doğru zamanda,\ndoğru ilham.","WEXTRA",vm.currentAccent)}}

@Composable fun ContentPreferencesScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){val c=androidx.compose.ui.platform.LocalContext.current;Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("Sana Özel İçerikler","İlgi alanlarına göre daha iyi öneriler.",Color(0xFFFF5CA8));SettingsRow(Icons.Default.Tune,"İlgi Alanlarını Seç","Daha fazla ilgi alanı, daha iyi öneri"){ };LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(listOf("Doğa","Şehir","Minimal","Oyun","Anime","Araç","Spor","Soyut")){cat->Surface(Modifier.width(82.dp).height(66.dp),shape=RoundedCornerShape(14.dp),color=vm.currentAccent.copy(alpha=.12f),border=BorderStroke(1.dp,vm.currentAccent.copy(alpha=.22f))){Box(contentAlignment=Alignment.Center){Text(cat,fontSize=11.sp,fontWeight=FontWeight.Bold)}}}};SettingsSwitch(Icons.Default.AutoAwesome,"İlgi Alanlarına Göre Öneriler","Tercihlerine uygun içerikler",true){};SettingsSwitch(Icons.Default.Security,"Güvenli İçerik Filtresi","Uygunsuz içerikleri gizle",true){};SettingsRow(Icons.Default.DeleteSweep,"Arama Geçmişini Temizle","Geçmiş aramalarını kaldır"){Toast.makeText(c,"Arama geçmişi temizlendi",Toast.LENGTH_SHORT).show()}}}

@Composable fun AccountSettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){val c=androidx.compose.ui.platform.LocalContext.current;Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("WEXTRA Hesabı","Oturum aç, her yerde seninle.",Color(0xFF36CFFF));Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF101A31)),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(if(vm.currentUserEmail==null)"WEXTRA Hesabı" else vm.currentUserName,fontWeight=FontWeight.Bold,fontSize=17.sp);Text(vm.currentUserEmail?:"Google ile hesabına bağlan",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp);Spacer(Modifier.height(12.dp));Button(onClick={nav.navigate("login")},modifier=Modifier.fillMaxWidth()){Text(if(vm.currentUserEmail==null)"Google ile Giriş Yap" else "Hesabı Aç")}}};SettingsRow(Icons.Default.CloudUpload,"Favorileri ve Ayarları Yedekle","Hesabına kaydet"){};SettingsSwitch(Icons.Default.Sync,"Senkronizasyon","Cihazlar arasında eşitle",true){};SettingsRow(Icons.Default.Favorite,"Favorileri Yönet","Beğendiğin duvar kâğıtlarını düzenle"){nav.navigate("favorites")};SettingsRow(Icons.Default.Upload,"Verileri Dışa Aktar","Favorileri ve ayarları yedekle"){};SettingsRow(Icons.Default.Download,"Verileri İçe Aktar","Yedekten geri yükle"){};SettingsBanner("Verilerin güvende,\nilhamın her yerde.","WEXTRA",vm.currentAccent)}}

@Composable fun PrivacySettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("Gizliliğin Bizim İçin Önemli","Verilerin her zaman güvende.",Color(0xFF21D4FF));SettingsRow(Icons.Default.Notifications,"Uygulama İzinleri","Kamera, depolama vb."){};SettingsRow(Icons.Default.Security,"Kişisel Verilerin Korunması","Verilerin güvende"){};SettingsSwitch(Icons.Default.Shield,"Güvenli İçerik Filtresi","Uygunsuz içerikleri gizle",true){};SettingsRow(Icons.Default.Campaign,"Reklam Tercihleri","Daha ilgili içerikler için"){};SettingsSwitch(Icons.Default.VerifiedUser,"Güvenlik Bildirimleri","Hesabınla ilgili önemli uyarılar",true){};SettingsRow(Icons.Default.Email,"Veri Politikası",""){};SettingsRow(Icons.Default.Description,"Kullanım Şartları",""){};SettingsBanner("Güvenle keşfet,\nözgürce ilham al.","WEXTRA",vm.currentAccent)}}

@Composable fun AboutSettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)){SettingsBanner("WEXTRA\nDuvar Kâğıdı","Daha Fazla Duvar Kâğıdı. Daha Güzel Sen.",vm.currentAccent);SettingsRow(Icons.Default.Info,"Sürüm","1.0.0"){};SettingsRow(Icons.Default.Description,"Lisanslar",""){};SettingsRow(Icons.Default.Email,"Geri Bildirim Gönder",""){};SettingsRow(Icons.Default.Star,"Bizi Değerlendir",""){};SettingsRow(Icons.Default.Share,"Paylaş",""){};SettingsRow(Icons.Default.ContactMail,"İletişim","");SettingsBanner("Her ekranda daha fazla sen.","WEXTRA",vm.currentAccent)}}

@Composable private fun SettingsBanner(title:String, subtitle:String, accent:Color){Card(Modifier.fillMaxWidth().padding(bottom=4.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF111B35)),border=BorderStroke(1.dp,accent.copy(alpha=.28f))){Box(Modifier.fillMaxWidth().height(112.dp).background(Brush.linearGradient(listOf(accent.copy(alpha=.26f),Color.Transparent))).padding(16.dp),contentAlignment=Alignment.BottomStart){Column{Text(title,color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=accent,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=1.5.sp)}}}}

@Composable fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,value:String,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(top=7.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(horizontal=15.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(38.dp),shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.width(12.dp));Text(title,modifier=Modifier.weight(1f),fontSize=14.sp);if(value.isNotBlank())Text(value,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=11.sp);Icon(Icons.Default.ChevronRight,null,tint=TextMuted)}}}
@Composable fun SettingsSwitch(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,checked:Boolean,onChecked:(Boolean)->Unit){Card(modifier=Modifier.fillMaxWidth().padding(top=7.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(horizontal=15.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(38.dp),shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,fontSize=14.sp,fontWeight=FontWeight.Medium)};Switch(checked=checked,onCheckedChange=onChecked)}}}

@Composable
fun AdminLoginScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){
    val context=androidx.compose.ui.platform.LocalContext.current; val auth=remember{FirebaseAuth.getInstance()}; val activity=context as? Activity
    var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var loading by remember{mutableStateOf(false)};var showPassword by remember{mutableStateOf(false)};var rememberMe by remember{mutableStateOf(true)}
    fun openAdmin(user:FirebaseUser){val e=user.email?.trim()?.lowercase().orEmpty();user.getIdToken(false).addOnSuccessListener{token->loading=false;if(token.claims["admin"]==true||e=="wextra.project@gmail.com"){vm.signIn(e,user.displayName?:"Wextra",true,context);nav.navigate("admin"){popUpTo("adminLogin"){inclusive=true}}}else{auth.signOut();error=vm.tr("Bu hesap için admin yetkisi yok.","This account has no admin permission.")}}.addOnFailureListener{ex->loading=false;auth.signOut();error=ex.message?:vm.tr("Admin yetkisi doğrulanamadı.","Admin permission could not be verified.")}}
    fun submit(){val e=email.trim().lowercase();if(e.isBlank()||password.isBlank()){error=vm.tr("E-posta ve şifreyi gir.","Enter email and password.");return};loading=true;error="";auth.signInWithEmailAndPassword(e,password).addOnSuccessListener{r->r.user?.let(::openAdmin)?:run{loading=false;error=vm.tr("Kullanıcı bulunamadı.","User not found.")}}.addOnFailureListener{ex->loading=false;error=ex.message?:vm.tr("E-posta veya şifre hatalı.","Incorrect email or password.")}}
    val googleLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r-> if(r.resultCode!=Activity.RESULT_OK){loading=false;return@rememberLauncherForActivityResult};try{val account=GoogleSignIn.getSignedInAccountFromIntent(r.data).getResult(Exception::class.java);val credential=GoogleAuthProvider.getCredential(account.idToken,null);auth.signInWithCredential(credential).addOnSuccessListener{it.user?.let(::openAdmin)}.addOnFailureListener{e->loading=false;error=e.message?:"Google girişi başarısız."}}catch(e:Exception){loading=false;error=e.message?:"Google girişi başarısız."}}
    Box(Modifier.fillMaxSize().background(Color(0xFF03040D))) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF221043).copy(alpha=.38f),Color.Transparent),radius=900f)))
        Box(Modifier.fillMaxWidth().height(500.dp).align(Alignment.TopCenter).background(Brush.verticalGradient(listOf(Color(0xFF08091A),Color.Transparent))))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=30.dp).statusBarsPadding().navigationBarsPadding(),horizontalAlignment=Alignment.CenterHorizontally){
            Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null,tint=Color(0xFF9B57FF))};Spacer(Modifier.width(8.dp));Text("WEXTRA",fontWeight=FontWeight.ExtraBold,color=Color(0xFFA55CFF),letterSpacing=1.sp,fontSize=18.sp)}
            Spacer(Modifier.height(10.dp));Surface(Modifier.size(250.dp),shape=CircleShape,color=Color.Transparent,border=BorderStroke(2.dp,Brush.sweepGradient(listOf(Color(0xFFB73CFF),Color(0xFFFF3F68),Color(0xFFFFC21A),Color(0xFF12CBFF),Color(0xFFB73CFF))))){Box(contentAlignment=Alignment.Center){Image(painterResource(R.drawable.wextra_logo),"Wextra",Modifier.size(175.dp))}}
            Spacer(Modifier.height(14.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("Yönetim",fontSize=36.sp,fontWeight=FontWeight.ExtraBold,color=Color(0xFF9C54FF));Spacer(Modifier.width(8.dp));Text("Merkezi",fontSize=36.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)}
            Text(vm.tr("Yetkili yöneticiler için güvenli erişim","Secure access for authorized administrators"),color=Color(0xFFC0C2CE),fontSize=15.sp)
            Spacer(Modifier.height(28.dp))
            Card(shape=RoundedCornerShape(30.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF0E1021)),border=BorderStroke(1.5.dp,Brush.linearGradient(listOf(Color(0xFF9D45FF),Color(0xFFFF4D5A),Color(0xFFFFB31A)))),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(26.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(48.dp),shape=RoundedCornerShape(14.dp),color=Color(0xFF8A3DFF).copy(alpha=.16f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.VerifiedUser,null,tint=Color(0xFF9B57FF))}};Spacer(Modifier.width(15.dp));Column{Text("Yönetici doğrulaması",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Hesabın ve yetkin Firebase üzerinden kontrol edilir.",color=Color(0xFFAEB1C0),fontSize=12.sp)}}
                    Spacer(Modifier.height(24.dp));NeonInput(email,{email=it},"Admin e-posta",Icons.Default.Email,enabled=!loading)
                    Spacer(Modifier.height(14.dp));NeonInput(password,{password=it},"Şifre",Icons.Default.Lock,enabled=!loading,password=!showPassword,trailing=if(showPassword)Icons.Default.Visibility else Icons.Default.VisibilityOff,onTrailing={showPassword=!showPassword})
                    Spacer(Modifier.height(12.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=rememberMe,onCheckedChange={rememberMe=it});Text("Beni hatırla",color=Color.White,modifier=Modifier.weight(1f));Text("Şifremi unuttum?",color=Color(0xFFC083FF))}
                    if(error.isNotEmpty())Text(error,color=Color(0xFFFF6D86),fontSize=12.sp,modifier=Modifier.padding(top=6.dp))
                    Spacer(Modifier.height(18.dp));Button(enabled=!loading,onClick=::submit,modifier=Modifier.fillMaxWidth().height(62.dp),shape=RoundedCornerShape(22.dp),colors=ButtonDefaults.buttonColors(containerColor=Color.Transparent),contentPadding=PaddingValues(0.dp)){Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF7037F5),Color(0xFFD12BB7),Color(0xFFFF4B28))),RoundedCornerShape(22.dp)),contentAlignment=Alignment.Center){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(18.dp));Text(if(loading)"Doğrulanıyor..." else "Yönetim paneline giriş yap",fontWeight=FontWeight.Bold,fontSize=17.sp);Spacer(Modifier.width(18.dp));Icon(Icons.Default.ArrowForward,null)}}}
                    Spacer(Modifier.height(16.dp));Row(verticalAlignment=Alignment.CenterVertically){HorizontalDivider(Modifier.weight(1f),color=Color.White.copy(alpha=.13f));Text("   veya   ",color=Color(0xFFAEB1BF),fontSize=13.sp);HorizontalDivider(Modifier.weight(1f),color=Color.White.copy(alpha=.13f))}
                    Spacer(Modifier.height(16.dp));OutlinedButton(enabled=!loading,onClick={if(activity==null){error="Google girişi bu cihazda başlatılamadı.";return@OutlinedButton};val id=try{context.getString(R.string.default_web_client_id)}catch(_:Exception){""};if(id.isBlank()){error="Google yapılandırması bulunamadı.";return@OutlinedButton};loading=true;val client=GoogleSignIn.getClient(context,GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(id).requestEmail().build());client.signOut().addOnCompleteListener{googleLauncher.launch(client.signInIntent)}},modifier=Modifier.fillMaxWidth().height(62.dp),shape=RoundedCornerShape(22.dp),border=BorderStroke(1.dp,Brush.linearGradient(listOf(Color(0xFF2F9DFF),Color(0xFFFF4D5D))))){Text("G",fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=Color(0xFF4E9BFF));Spacer(Modifier.width(16.dp));Text("Google ile giriş yap",color=Color.White,fontWeight=FontWeight.SemiBold,fontSize=17.sp)}
                }
            }
            Spacer(Modifier.height(22.dp));Surface(Modifier.size(50.dp),shape=CircleShape,color=Color(0xFF171028)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Security,null,tint=Color(0xFF9C54FF))}};Spacer(Modifier.height(7.dp));Text("Yetkisiz erişim engellenir.",color=Color(0xFFAEB1C0),fontSize=13.sp);Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
private fun NeonInput(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    enabled: Boolean,
    password: Boolean = false,
    trailing: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onTrailing: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null, tint = Color(0xFF9551FF)) },
        trailingIcon = if (trailing != null) {
            {
                IconButton(onClick = { onTrailing?.invoke() }) {
                    Icon(trailing, null, tint = Color(0xFF9EA3B4))
                }
            }
        } else null,
        singleLine = true,
        enabled = enabled,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color(0xFFAA53FF),
            unfocusedBorderColor = Color(0xFF32374B),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedLabelColor = Color(0xFFB46AFF),
            unfocusedLabelColor = Color(0xFFA4A8B7)
        )
    )
}

@Composable
fun AdminScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    if(!vm.isAdmin){ LaunchedEffect(Unit){ nav.navigate("adminLogin") }; return }
    var query by remember { mutableStateOf("") }
    val shown = vm.wallpapers.filter { it.title.contains(query,true) || it.category.contains(query,true) }
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal=16.dp), contentPadding=PaddingValues(vertical=12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.Menu,null)}
                Text("Admin Paneli", fontSize=23.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                BadgedBox(badge={Badge{}}){IconButton(onClick={}){Icon(Icons.Default.Notifications, null)}}
            }
        }
        item {
            Text("Genel Bakış", fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.onSurfaceVariant)
            LazyVerticalGrid(columns=GridCells.Fixed(2), modifier=Modifier.height(190.dp), verticalArrangement=Arrangement.spacedBy(9.dp), horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                item{AdminStat("Toplam Duvar Kâğıdı", vm.wallpapers.size.toString(), Icons.Default.Wallpaper, Color(0xFF8B7BFF))}
                item{AdminStat("Toplam Kullanıcı", "18.256", Icons.Default.People, Color(0xFF4CB7FF))}
                item{AdminStat("Toplam Görüntülenme", "245.7K", Icons.Default.Visibility, Color(0xFF39D6A3))}
                item{AdminStat("Toplam Beğeni", "89.3K", Icons.Default.Favorite, Color(0xFFFF6FA8))}
            }
        }
        item {
            Text("Hızlı İşlemler", fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) {
                AdminAction(Modifier.weight(1f),"Duvar Kâğıdı Ekle",Icons.Default.AddPhotoAlternate,Color(0xFF7A4DFF)){nav.navigate("adminAdd")}
                AdminAction(Modifier.weight(1f),"Kategoriler",Icons.Default.GridView,Color(0xFF377DFF)){nav.navigate("categories")}
            }
        }
        item { OutlinedTextField(query,{query=it},leadingIcon={Icon(Icons.Default.Search,null)},label={Text("Duvar kâğıtlarında ara")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item { Text("Duvar Kâğıtları", fontWeight=FontWeight.Bold, fontSize=19.sp) }
        items(shown.take(40)) { w ->
            Card(shape=RoundedCornerShape(17.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                    AsyncImage(vm.imageFor(w),w.title,Modifier.size(74.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop)
                    Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(w.title,fontWeight=FontWeight.SemiBold); Text("${w.category} • ${w.resolutionLabel ?: vm.selectedResolution.label}",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=11.sp) }
                    IconButton(onClick={}){Icon(Icons.Default.Edit,null,tint=MaterialTheme.colorScheme.primary)}
                    Switch(checked=true,onCheckedChange={})
                }
            }
        }
    }
}

@Composable
fun AdminAddWallpaperScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(vm.categories.first()) }
    var resolution by remember { mutableStateOf(vm.resolutions[2]) }
    var saved by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(18.dp), contentPadding=PaddingValues(bottom=24.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
        item { Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text("Yeni Duvar Kâğıdı Ekle",fontSize=23.sp,fontWeight=FontWeight.Bold)} }
        item {
            Card(shape=RoundedCornerShape(20.dp), border=BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=.3f)), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CloudUpload,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(52.dp)); Spacer(Modifier.height(9.dp)); Text("Görsel bağlantısı ekle",fontWeight=FontWeight.Bold); Text("Yüksek kaliteli doğrudan resim URL'si",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
                }
            }
        }
        item { OutlinedTextField(title,{title=it},label={Text("Başlık")},placeholder={Text("Örn: Gizli Şelale")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item { OutlinedTextField(url,{url=it},label={Text("Görsel bağlantısı")},placeholder={Text("https://...")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item {
            Text("Kategori",fontWeight=FontWeight.SemiBold)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(top=7.dp)) {
                items(vm.categories){ name -> FilterChip(selected=category==name,onClick={category=name},label={Text(name)}) }
            }
        }
        item {
            Text("Çözünürlük",fontWeight=FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) { vm.resolutions.forEach { option -> FilterChip(selected=resolution==option,onClick={resolution=option},label={Text(option.label)},modifier=Modifier.weight(1f)) } }
        }
        item { SwitchRow("Aktif", true) }
        item {
            Button(onClick={vm.addWallpaper(title,category,url,resolution);saved=true}, enabled=title.isNotBlank()&&url.startsWith("http"), modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(16.dp)) { Text("Kaydet") }
        }
        if(saved) item { Text("Duvar kâğıdı eklendi. Kategori ve çözünürlük seçimi kaydedildi.",color=Color(0xFF39D6A3)) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean) {
    Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(label,modifier=Modifier.weight(1f));Switch(checked=checked,onCheckedChange={})} }
}
@Composable fun AdminStat(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color){Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=10.sp);Text(value,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("↗ +8%",color=Color(0xFF39D6A3),fontSize=10.sp)};Icon(icon,null,tint=tint)}}}
@Composable fun AdminAction(modifier:Modifier,title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color,onClick:()->Unit){Card(onClick=onClick,modifier=modifier.padding(bottom=8.dp).height(68.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=tint.copy(alpha=.18f))){Row(Modifier.fillMaxSize().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=tint);Spacer(Modifier.width(8.dp));Text(title,fontSize=11.sp)}}}

