# WEXTRA Pexels Görsel Kaynakları

Bu sürümde duvar kâğıtları uygulama içine kopyalanmadı. 9 kategori için toplam 180 farklı Pexels fotoğrafı Pexels CDN üzerinden doğrudan yüklenir.

Her görsel benzersiz bir Pexels fotoğraf kimliği kullanır.

## Doğa (20 görsel)
- https://www.pexels.com/photo/36231412/
- https://www.pexels.com/photo/13540046/
- https://www.pexels.com/photo/12894706/
- https://www.pexels.com/photo/12303757/
- https://www.pexels.com/photo/17665335/
- https://www.pexels.com/photo/13211417/
- https://www.pexels.com/photo/16839747/
- https://www.pexels.com/photo/12183523/
- https://www.pexels.com/photo/14822137/
- https://www.pexels.com/photo/8316768/
- https://www.pexels.com/photo/5621135/
- https://www.pexels.com/photo/19200683/
- https://www.pexels.com/photo/14910369/
- https://www.pexels.com/photo/36928652/
- https://www.pexels.com/photo/18314497/
- https://www.pexels.com/photo/16839755/
- https://www.pexels.com/photo/14856412/
- https://www.pexels.com/photo/19963910/
- https://www.pexels.com/photo/17940231/
- https://www.pexels.com/photo/28559641/

## Yıldızlar (20 görsel)
- https://www.pexels.com/photo/6306297/
- https://www.pexels.com/photo/24516527/
- https://www.pexels.com/photo/22711142/
- https://www.pexels.com/photo/4994763/
- https://www.pexels.com/photo/2832071/
- https://www.pexels.com/photo/12290594/
- https://www.pexels.com/photo/7311920/
- https://www.pexels.com/photo/19114161/
- https://www.pexels.com/photo/9904249/
- https://www.pexels.com/photo/10699210/
- https://www.pexels.com/photo/11657171/
- https://www.pexels.com/photo/13104488/
- https://www.pexels.com/photo/1564350/
- https://www.pexels.com/photo/6074272/
- https://www.pexels.com/photo/18002238/
- https://www.pexels.com/photo/18537874/
- https://www.pexels.com/photo/20761228/
- https://www.pexels.com/photo/5463766/
- https://www.pexels.com/photo/13747982/
- https://www.pexels.com/photo/5665922/

## Şehir (20 görsel)
- https://www.pexels.com/photo/14740555/
- https://www.pexels.com/photo/4132321/
- https://www.pexels.com/photo/30667702/
- https://www.pexels.com/photo/8303512/
- https://www.pexels.com/photo/13496685/
- https://www.pexels.com/photo/13691275/
- https://www.pexels.com/photo/17872108/
- https://www.pexels.com/photo/17872111/
- https://www.pexels.com/photo/23848514/
- https://www.pexels.com/photo/20131950/
- https://www.pexels.com/photo/9202139/
- https://www.pexels.com/photo/8138677/
- https://www.pexels.com/photo/19502005/
- https://www.pexels.com/photo/6842931/
- https://www.pexels.com/photo/9200163/
- https://www.pexels.com/photo/16092579/
- https://www.pexels.com/photo/7808043/
- https://www.pexels.com/photo/30129371/
- https://www.pexels.com/photo/19852207/
- https://www.pexels.com/photo/5802551/

## Araçlar (20 görsel)
- https://www.pexels.com/photo/30757229/
- https://www.pexels.com/photo/6509106/
- https://www.pexels.com/photo/17918280/
- https://www.pexels.com/photo/6729273/
- https://www.pexels.com/photo/12882895/
- https://www.pexels.com/photo/10394781/
- https://www.pexels.com/photo/4913904/
- https://www.pexels.com/photo/11816505/
- https://www.pexels.com/photo/9827417/
- https://www.pexels.com/photo/13817931/
- https://www.pexels.com/photo/12249430/
- https://www.pexels.com/photo/12339867/
- https://www.pexels.com/photo/12330673/
- https://www.pexels.com/photo/9827419/
- https://www.pexels.com/photo/9827415/
- https://www.pexels.com/photo/18956629/
- https://www.pexels.com/photo/6699273/
- https://www.pexels.com/photo/16545569/
- https://www.pexels.com/photo/14401652/
- https://www.pexels.com/photo/13972551/

## Minimal (20 görsel)
- https://www.pexels.com/photo/7307556/
- https://www.pexels.com/photo/31050234/
- https://www.pexels.com/photo/37060537/
- https://www.pexels.com/photo/30447470/
- https://www.pexels.com/photo/5210769/
- https://www.pexels.com/photo/35431021/
- https://www.pexels.com/photo/36988279/
- https://www.pexels.com/photo/36883078/
- https://www.pexels.com/photo/16563205/
- https://www.pexels.com/photo/32662022/
- https://www.pexels.com/photo/7307567/
- https://www.pexels.com/photo/7307542/
- https://www.pexels.com/photo/7307563/
- https://www.pexels.com/photo/4252672/
- https://www.pexels.com/photo/7307725/
- https://www.pexels.com/photo/7307398/
- https://www.pexels.com/photo/30201498/
- https://www.pexels.com/photo/7543542/
- https://www.pexels.com/photo/7307618/
- https://www.pexels.com/photo/9175405/

## Soyut (20 görsel)
- https://www.pexels.com/photo/13281747/
- https://www.pexels.com/photo/7042639/
- https://www.pexels.com/photo/16353152/
- https://www.pexels.com/photo/24601557/
- https://www.pexels.com/photo/24786238/
- https://www.pexels.com/photo/15275240/
- https://www.pexels.com/photo/24514301/
- https://www.pexels.com/photo/15062251/
- https://www.pexels.com/photo/13343865/
- https://www.pexels.com/photo/23832986/
- https://www.pexels.com/photo/15129947/
- https://www.pexels.com/photo/14596081/
- https://www.pexels.com/photo/6109126/
- https://www.pexels.com/photo/7605755/
- https://www.pexels.com/photo/11646468/
- https://www.pexels.com/photo/36957444/
- https://www.pexels.com/photo/37228187/
- https://www.pexels.com/photo/30601011/
- https://www.pexels.com/photo/7317292/
- https://www.pexels.com/photo/37114518/

## Oyun (20 görsel)
- https://www.pexels.com/photo/7862382/
- https://www.pexels.com/photo/7862453/
- https://www.pexels.com/photo/34543044/
- https://www.pexels.com/photo/19931378/
- https://www.pexels.com/photo/36899797/
- https://www.pexels.com/photo/7862607/
- https://www.pexels.com/photo/9071741/
- https://www.pexels.com/photo/12405516/
- https://www.pexels.com/photo/28114090/
- https://www.pexels.com/photo/7862420/
- https://www.pexels.com/photo/7862404/
- https://www.pexels.com/photo/7862456/
- https://www.pexels.com/photo/7862451/
- https://www.pexels.com/photo/7773751/
- https://www.pexels.com/photo/7774032/
- https://www.pexels.com/photo/7862374/
- https://www.pexels.com/photo/7862349/
- https://www.pexels.com/photo/7862272/
- https://www.pexels.com/photo/7862267/
- https://www.pexels.com/photo/9071735/

## Hayvanlar (20 görsel)
- https://www.pexels.com/photo/16149914/
- https://www.pexels.com/photo/18145372/
- https://www.pexels.com/photo/12612179/
- https://www.pexels.com/photo/12826675/
- https://www.pexels.com/photo/13618858/
- https://www.pexels.com/photo/13015549/
- https://www.pexels.com/photo/17213816/
- https://www.pexels.com/photo/6100105/
- https://www.pexels.com/photo/12270392/
- https://www.pexels.com/photo/21050617/
- https://www.pexels.com/photo/22873562/
- https://www.pexels.com/photo/20058563/
- https://www.pexels.com/photo/17173596/
- https://www.pexels.com/photo/12216186/
- https://www.pexels.com/photo/11611904/
- https://www.pexels.com/photo/17580574/
- https://www.pexels.com/photo/19284158/
- https://www.pexels.com/photo/6966065/
- https://www.pexels.com/photo/13340055/
- https://www.pexels.com/photo/14555826/

## Mimari (20 görsel)
- https://www.pexels.com/photo/11043707/
- https://www.pexels.com/photo/34260162/
- https://www.pexels.com/photo/37376676/
- https://www.pexels.com/photo/31647758/
- https://www.pexels.com/photo/15707646/
- https://www.pexels.com/photo/29736860/
- https://www.pexels.com/photo/14625179/
- https://www.pexels.com/photo/11932134/
- https://www.pexels.com/photo/15489864/
- https://www.pexels.com/photo/20798019/
- https://www.pexels.com/photo/30122379/
- https://www.pexels.com/photo/38695371/
- https://www.pexels.com/photo/16314588/
- https://www.pexels.com/photo/30350574/
- https://www.pexels.com/photo/18381375/
- https://www.pexels.com/photo/6236235/
- https://www.pexels.com/photo/29079181/
- https://www.pexels.com/photo/7729124/
- https://www.pexels.com/photo/10133773/
- https://www.pexels.com/photo/2834188/