# Google ile giriş kontrol listesi

Kod tarafındaki giriş akışı güncellendi. Gerçek cihazda çalışması için Firebase/Google yapılandırmasının da doğru olması gerekir:

1. Firebase Authentication > Sign-in method > Google sağlayıcısını etkinleştir.
2. Firebase Project settings > Your apps bölümünde paket adının `com.wextra.wallpapers` olduğundan emin ol.
3. Debug ve release APK imzalarının SHA-1 ve SHA-256 parmak izlerini Firebase'e ekle.
4. Güncel `google-services.json` dosyasını `app/google-services.json` olarak değiştir.
5. Firebase'den yeni yapılandırmayı aldıktan sonra uygulamayı temiz derle.

Not: Eksik SHA anahtarı Google girişinde çoğunlukla hata kodu 10 (`DEVELOPER_ERROR`) oluşturur. Kod artık bu durumu anlaşılır mesajla gösterir.
