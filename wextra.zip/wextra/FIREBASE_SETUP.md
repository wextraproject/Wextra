# Firebase setup for wextra

## 1. Create Firebase project
Create a project in Firebase Console and add Android app:

`com.wextra.wallpapers`

## 2. Add google-services.json
Download it and place it here:

`app/google-services.json`

This file is ignored by `.gitignore`.

## 3. Enable products
- Authentication: Email/Password, optionally Google
- Cloud Firestore
- Cloud Storage

## 4. Add plugin
In root `build.gradle.kts` add:

```kotlin
id("com.google.gms.google-services") version "4.4.2" apply false
```

In `app/build.gradle.kts` add:

```kotlin
id("com.google.gms.google-services")
```

## 5. Add dependencies
Inside app dependencies:

```kotlin
implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
implementation("com.google.firebase:firebase-auth")
implementation("com.google.firebase:firebase-firestore")
implementation("com.google.firebase:firebase-storage")
```

Then replace the demo repository with Firebase repository code.

## Security
Do not make Firestore/Storage public in production. Add security rules based on the signed-in user's UID.
