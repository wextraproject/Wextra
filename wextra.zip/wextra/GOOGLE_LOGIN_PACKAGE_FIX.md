# Google giriş paket adı düzeltmesi

Sorunun kaynağı:
- Uygulama daha önce `com.wextra.wallpapers` paket adıyla derleniyordu.
- `google-services.json` içindeki SHA-1 sertifikasına bağlı Android OAuth istemcisi ise `com.wextra.wallpaper` içindi.

Bu sürümde Android `namespace`, `applicationId` ve Kotlin paketi `com.wextra.wallpaper` ile eşitlendi.

`google-services.json` dosyası da kullanıcı tarafından sağlanan güncel dosyayla `app/google-services.json` konumuna yerleştirildi.

Not: APK'nın gerçek imza SHA-1 değeri Firebase'deki Android OAuth istemcisiyle eşleşmelidir.
