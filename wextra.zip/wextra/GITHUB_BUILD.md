# GitHub'da telefondan APK oluşturma

1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP'i çıkar ve içindeki dosyaları repository'ye yükle.
3. `Actions` sekmesine gir.
4. `Build wextra APK` iş akışını seç.
5. `Run workflow` düğmesine bas.
6. İşlem tamamlanınca `Artifacts` bölümünden `wextra-debug-apk` dosyasını indir.

## Not
İlk build sırasında GitHub sunucuları Gradle bağımlılıklarını indirir.
Build başarısız olursa Actions ekranındaki hata metnini bana gönder; projeyi ona göre düzeltirim.
