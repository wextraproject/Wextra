# Wextra güncellemesi

- Ana sayfa yeni premium koyu arayüze göre yeniden düzenlendi.
- Logo alanı sadeleştirildi ve yeni arama/hero/kategori düzeni eklendi.
- Alt menü: Ana Sayfa, Kategoriler, Favoriler, Profil, Ayarlar.
- Admin paneli yeniden düzenlendi.
- Admin paneline `Yeni Duvar Kâğıdı Ekle` ekranı eklendi.
- Yeni duvar kağıdı eklerken kategori ve çözünürlük seçimi eklendi.
- 7 kategori için toplam 70 çevrim içi yüksek kaliteli görsel bağlantısı eklendi (kategori başına 10).
- Firebase Storage bağımlılığı kaldırıldı; uygulama görsel bağlantılarıyla çalışacak şekilde bırakıldı.
- Google giriş akışı güçlendirildi ve yapılandırma hataları için anlaşılır mesajlar eklendi.
- Gerçek Google girişinin çalışması için gerekli Firebase SHA / sağlayıcı kontrol listesi `GOOGLE_LOGIN_SETUP.md` dosyasına eklendi.
