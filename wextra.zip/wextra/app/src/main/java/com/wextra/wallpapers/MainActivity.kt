package com.wextra.wallpapers

import android.app.WallpaperManager
import android.content.Context
import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

private val Background = androidx.compose.ui.graphics.Color(0xFF07101F)
private val Surface = androidx.compose.ui.graphics.Color(0xFF101E31)
private val Accent = androidx.compose.ui.graphics.Color(0xFF6572FF)
private val TextMuted = androidx.compose.ui.graphics.Color(0xFF9EABC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WextraTheme { WextraApp() } }
    }
}

@Composable
fun WextraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Surface,
            onPrimary = androidx.compose.ui.graphics.Color.White,
            onBackground = androidx.compose.ui.graphics.Color.White,
            onSurface = androidx.compose.ui.graphics.Color.White
        ),
        content = content
    )
}

data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String
)

class WallpaperViewModel : androidx.lifecycle.ViewModel() {
    private val wallpapersKey = "favorite_wallpapers"

    val wallpapers = listOf(
        Wallpaper("1","Dağ Manzarası","Doğa","https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200"),
        Wallpaper("2","Yıldızlar","Uzay","https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1200"),
        Wallpaper("3","Orman Yolu","Doğa","https://images.unsplash.com/photo-1448375240586-882707db888b?w=1200"),
        Wallpaper("4","Gece Şehri","Şehir","https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=1200"),
        Wallpaper("5","Renk Dalgası","Soyut","https://images.unsplash.com/photo-1557683316-973673baf926?w=1200"),
        Wallpaper("6","Kurt","Hayvanlar","https://images.unsplash.com/photo-1561731216-c3a4d99437d5?w=1200")
    )

    var favorites by mutableStateOf(setOf<String>())
        private set

    var randomWallpaperId by mutableStateOf(wallpapers.first().id)
        private set

    fun loadFavorites(context: Context) {
        val prefs = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        favorites = prefs.getStringSet(wallpapersKey, emptySet()) ?: emptySet()
    }

    fun toggleFavorite(id: String, context: Context) {
        favorites = if (id in favorites) favorites - id else favorites + id
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
            .edit()
            .putStringSet(wallpapersKey, favorites)
            .apply()
    }

    fun pickRandom() {
        if (wallpapers.isNotEmpty()) {
            randomWallpaperId = wallpapers[Random.nextInt(wallpapers.size)].id
        }
    }

    fun dailyWallpaper(): Wallpaper {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        return wallpapers[day % wallpapers.size]
    }
}

@Composable
fun WextraApp(vm: WallpaperViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { vm.loadFavorites(context) }
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") { SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
        composable("home") { MainScaffold(nav, vm, "home") { HomeScreen(vm, nav) } }
        composable("categories") { MainScaffold(nav, vm, "categories") { CategoriesScreen(vm, nav) } }
        composable("favorites") { MainScaffold(nav, vm, "favorites") { FavoritesScreen(vm, nav) } }
        composable("profile") { MainScaffold(nav, vm, "profile") { ProfileScreen(nav) } }
        composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
            val item = vm.wallpapers.first { w -> w.id == it.arguments?.getString("id") }
            DetailScreen(item, item.id in vm.favorites, { vm.toggleFavorite(item.id, context) }, nav)
        }
        composable("login") { LoginScreen(nav) }
        composable("register") { RegisterScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
    }
}

@Composable
fun SplashScreen(onStart: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Background), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
            Image(
                painter = painterResource(id = R.drawable.wextra_logo),
                contentDescription = "Wextra logosu",
                modifier = Modifier.size(112.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text("Wextra", fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Text("Hayalindeki duvar kâğıtları şimdi cebinde!", color = TextMuted)
            Spacer(Modifier.height(44.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp)) {
                Text("Başla")
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Default.ArrowForward, null)
            }
        }
    }
}

@Composable
fun MainScaffold(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, selected: String, content: @Composable () -> Unit) {
    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                listOf(
                    Triple("home","Ana Sayfa",Icons.Default.Home),
                    Triple("categories","Kategoriler",Icons.Default.GridView),
                    Triple("favorites","Favoriler",Icons.Default.Favorite),
                    Triple("profile","Profil",Icons.Default.Person)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = selected == route,
                        onClick = { if (selected != route) nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, null) },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding -> Box(Modifier.padding(padding)) { content() } }
}

@Composable
fun HomeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    var query by remember { mutableStateOf("") }
    val filtered = vm.wallpapers.filter {
        it.title.contains(query, true) || it.category.contains(query, true)
    }
    val daily = vm.dailyWallpaper()
    val random = vm.wallpapers.first { it.id == vm.randomWallpaperId }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(id = R.drawable.wextra_logo),
                contentDescription = "Wextra logosu",
                modifier = Modifier.size(42.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text("Wextra", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Text("Bugün ne keşfetmek istersin?", color = TextMuted)
        Spacer(Modifier.height(14.dp))

        Card(
            modifier = Modifier.fillMaxWidth().height(190.dp)
                .clickable { nav.navigate("detail/${daily.id}") },
            shape = RoundedCornerShape(20.dp)
        ) {
            Box {
                AsyncImage(daily.imageUrl, daily.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Surface(
                    color = Surface.copy(alpha = .82f),
                    modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text("✨ Günün Duvar Kâğıdı", color = Accent, fontWeight = FontWeight.Bold)
                        Text(daily.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { vm.pickRandom() },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Shuffle, null)
            Spacer(Modifier.width(8.dp))
            Text("Rastgele Duvar Kâğıdı")
        }

        Spacer(Modifier.height(12.dp))
        Card(
            modifier = Modifier.fillMaxWidth().height(82.dp)
                .clickable { nav.navigate("detail/${random.id}") },
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxSize().padding(10.dp)) {
                AsyncImage(random.imageUrl, random.title,
                    Modifier.size(62.dp).clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("🎲 Rastgele seçildi", color = Accent, fontSize = 12.sp)
                    Text(random.title, fontWeight = FontWeight.Bold)
                    Text(random.category, color = TextMuted, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Duvar kâğıdı ara") },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text("Popüler", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        WallpaperGrid(filtered, nav)
    }
}

@Composable
fun WallpaperGrid(items: List<Wallpaper>, nav: androidx.navigation.NavHostController) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(items) { item ->
            Card(
                modifier = Modifier.fillMaxWidth().height(240.dp).clickable { nav.navigate("detail/${item.id}") },
                shape = RoundedCornerShape(18.dp)
            ) {
                Box {
                    AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Surface(
                        color = Surface.copy(alpha = .86f),
                        modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold)
                            Text(item.category, color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoriesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val categories = vm.wallpapers.groupBy { it.category }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Kategoriler", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(categories.entries.toList()) { (name, list) ->
                Card(modifier = Modifier.height(170.dp).clickable { nav.navigate("detail/${list.first().id}") }, shape = RoundedCornerShape(18.dp)) {
                    Box {
                        AsyncImage(list.first().imageUrl, name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Surface(color = Surface.copy(alpha = .75f), modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()) {
                            Text("$name • ${list.size}", Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val list = vm.wallpapers.filter { it.id in vm.favorites }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Favoriler", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Henüz favori duvar kâğıdın yok.", color = TextMuted)
            }
        } else WallpaperGrid(list, nav)
    }
}

@Composable
fun DetailScreen(item: Wallpaper, isFavorite: Boolean, onFavorite: () -> Unit, nav: androidx.navigation.NavHostController) {
    Column(Modifier.fillMaxSize().background(Background)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AsyncImage(item.imageUrl, item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.padding(18.dp).align(Alignment.TopStart)) {
                Icon(Icons.Default.ArrowBack, null)
            }
            IconButton(onClick = onFavorite, modifier = Modifier.padding(18.dp).align(Alignment.TopEnd)) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (isFavorite) Accent else androidx.compose.ui.graphics.Color.White)
            }
        }
        Column(Modifier.padding(20.dp)) {
            Text(item.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(item.category, color = TextMuted)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { nav.navigate("settings") }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Wallpaper, null)
                Spacer(Modifier.width(8.dp))
                Text("Duvar Kâğıdı Yap")
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Download, null)
                Spacer(Modifier.width(8.dp))
                Text("İndir")
            }
        }
    }
}

@Composable
fun ProfileScreen(nav: androidx.navigation.NavHostController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Profil", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(22.dp))
        Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(64.dp), tint = Accent)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Misafir Kullanıcı", fontWeight = FontWeight.Bold)
                    Text("Firebase ile giriş yapabilirsin", color = TextMuted, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate("login") }, modifier = Modifier.fillMaxWidth()) { Text("Giriş Yap / Kayıt Ol") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { nav.navigate("settings") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Settings, null)
            Spacer(Modifier.width(8.dp))
            Text("Ayarlar")
        }
    }
}

@Composable
fun LoginScreen(nav: androidx.navigation.NavHostController) {
    AuthScreen(title = "Giriş Yap", action = "Giriş Yap", secondary = "Hesabın yok mu? Kayıt Ol", onAction = { nav.navigate("home") }, onSecondary = { nav.navigate("register") })
}

@Composable
fun RegisterScreen(nav: androidx.navigation.NavHostController) {
    AuthScreen(title = "Kayıt Ol", action = "Kayıt Ol", secondary = "Zaten hesabın var mı? Giriş Yap", onAction = { nav.navigate("home") }, onSecondary = { nav.navigate("login") })
}

@Composable
fun AuthScreen(title: String, action: String, secondary: String, onAction: () -> Unit, onSecondary: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(70.dp))
        Image(
            painter = painterResource(id = R.drawable.wextra_logo),
            contentDescription = "Wextra logosu",
            modifier = Modifier.size(72.dp)
        )
        Text("Wextra", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(email, { email = it }, label = { Text("E-posta adresi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Şifre") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAction, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text(action) }
        TextButton(onClick = onSecondary) { Text(secondary) }
        Text("Firebase bağlantısından sonra gerçek giriş aktif olur.", color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(nav: androidx.navigation.NavHostController) {
    var notifications by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Ayarlar", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bildirimler", fontWeight = FontWeight.Bold)
                    Text("Yeni duvar kâğıtlarından haberdar ol", color = TextMuted, fontSize = 12.sp)
                }
                Switch(checked = notifications, onCheckedChange = { notifications = it })
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Duvar kâğıdı ayarlama", fontWeight = FontWeight.Bold)
                Text("Gerçek duvar kâğıdı seçimi Android API ile sonraki sürümde tamamlanabilir.", color = TextMuted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = { nav.navigate("home") }, modifier = Modifier.fillMaxWidth()) {
            Text("Ana Sayfaya Dön")
        }
    }
}
