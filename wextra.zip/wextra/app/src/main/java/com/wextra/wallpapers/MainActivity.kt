package com.wextra.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONArray
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import kotlinx.coroutines.delay
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.app.Activity
import android.media.ToneGenerator
import android.media.AudioManager

private val Background = androidx.compose.ui.graphics.Color(0xFF07101F)
private val Surface = androidx.compose.ui.graphics.Color(0xFF101E31)
private val Accent = androidx.compose.ui.graphics.Color(0xFF6572FF)
private val TextMuted = androidx.compose.ui.graphics.Color(0xFF9EABC0)
private val CategoryColors = listOf(
    Color(0xFF39D6A3),
    Color(0xFF8B7BFF),
    Color(0xFFFF7AA8),
    Color(0xFFFFB457),
    Color(0xFF4CB7FF)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WextraTheme { WextraApp() } }
    }
}

@Composable
fun WextraTheme(
    dark: Boolean = true,
    accent: Color = Accent,
    textColor: Color = Color.White,
    content: @Composable () -> Unit
) {
    val scheme = if (dark) darkColorScheme(
        primary = accent,
        secondary = accent,
        background = Background,
        surface = Surface,
        onPrimary = Color.White,
        onBackground = textColor,
        onSurface = textColor
    ) else lightColorScheme(
        primary = accent,
        secondary = accent,
        background = Color(0xFFF6F7FB),
        surface = Color.White,
        onPrimary = Color.White,
        onBackground = textColor.copy(alpha = 0.92f),
        onSurface = textColor.copy(alpha = 0.92f)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String? = null,
    val localResId: Int? = null,
    val resolutionLabel: String? = "4K",
    val likes: Int = 0,
    val views: Int = 0
)

data class ResolutionOption(val label: String, val detail: String, val width: Int)

class WallpaperViewModel : androidx.lifecycle.ViewModel() {
    private val wallpapersKey = "favorite_wallpapers"

    // Her kategori için 10 adet yüksek çözünürlüklü çevrim içi görsel.
    // Görseller Firebase Storage'a yüklenmez; doğrudan görsel bağlantıları kullanılır.
    val wallpapers = mutableStateListOf<Wallpaper>().apply {
        addAll(seedWallpapers())
    }

    private fun seedWallpapers(): List<Wallpaper> {
        val data = listOf(
            "Doğa" to listOf(
                "Sisli Orman","Gizli Şelale","Dağ Gölü","Kuzey Işıkları","Vadi Nehri","Gece Yaprakları","Mağara Şelalesi","Dağ Vadisi","Sonbahar Yolu","Sahilde Gün Batımı"
            ),
            "Yıldızlar" to listOf(
                "Yıldızlı Gece","Samanyolu","Mor Bulutsu","Uzay Yolculuğu","Ay Işığı","Kozmik Ufuk","Derin Uzay","Yıldız Yağmuru","Galaksi","Gece Gökyüzü"
            ),
            "Şehir" to listOf(
                "Neon Şehir","Yağmurlu Sokak","Tokyo Gecesi","Modern Şehir","Gökyüzü Hattı","Gece Işıkları","Metropol","Sokak Lambaları","Şehir Köprüsü","Fütüristik Kent"
            ),
            "Araçlar" to listOf(
                "Spor Araba","Gece Sürüşü","Dağ Yolu","Klasik Araba","Yarış Pisti","Kırmızı Coupe","Şehir Sürüşü","Süper Otomobil","Sahil Yolu","Motor Yolculuğu"
            ),
            "Minimal" to listOf(
                "Soyut Dalga","Mavi Geometri","Yumuşak Tonlar","Mor Işık","Basit Form","Minimal Dağ","Pastel Ufuk","Karanlık Çizgi","Daireler","Sakin Doku"
            ),
            "Soyut" to listOf(
                "Renk Akışı","Neon Dalgalar","Sıvı Işık","Kristal Form","Mor Geçiş","Mavi Parıltı","Enerji Hattı","Geometrik Rüya","Renkli Sis","Soyut Gece"
            ),
            "Oyun" to listOf(
                "Oyuncu Dünyası","Neon Arena","Fütüristik Oyun","Uzay Savaşçısı","Dijital Şehir","Pixel Gece","Siber Dünya","Efsane Arena","Oyun Işıkları","Teknoloji Üssü"
            )
        )
        val natureIds = listOf("1464822759023-fed622ff2c3b","1441974231531-c6227db76b6e","1500534623283-312aade485b7","1470770841072-f978cf4d019e","1448375240586-882707db888b","1444464666168-49d633b86797","1444723121867-7a241cacace9","1501785888041-af3ef285b470","1473448912268-2022ce9509d8","1470252649378-9c29740c9fa8")
        val starIds = listOf("1462331940025-496dfbfc7564","1419242902214-272b3f66ee7a","1444703686981-a3abbc4d4fe3","1446776877081-d282a0f896e2","1454789476662-53eb23ba5907","1500530855697-b586d89ba3ee","1451187580459-43490279c0fa","1497250681960-ef046c08a56e","1519608487953-e999c86e7455","1534791547702-8d6c86f5f1e0")
        val cityIds = listOf("1477959858617-67f85cf4f1df","1519608487953-e999c86e7455","1444723121867-7a241cacace9","1480714378408-67cf0d13bc1b","1494526585095-c41746248156","1500530855697-b586d89ba3ee","1486325212027-8081e485255e","1497366754035-f200968a6e72","1519501025264-65ba15a82390","1485871981521-5b1fd3805eee")
        val carIds = listOf("1503376780353-7e6692767b70","1492144534655-ae79c964c9d7","1500534314209-a25ddb2bd429","1503736334956-4c8f8e92946d","1504215680853-026ed2a45def","1494976388531-d1058494cdd8","1511919884226-fd3cad34687c","1517524008697-84bbe3c3fd98","1471479917193-f00955256257","1558981806-ec527fa84c39")
        val minimalIds = listOf("1557683316-973673baf926","1550859492-d5da9d8e45f3","1494438639946-1ebd1d20bf85","1534796636912-3b95b3ab5986","1519608487953-e999c86e7455","1493246507139-91e8fad9978e","1484101403633-562f891dc89a","1511818966892-d7d671e672a2","1499951360447-b19be8fe80f5","1497366811353-6870744d04b2")
        val abstractIds = listOf("1557683316-973673baf926","1550859492-d5da9d8e45f3","1550745165-9bc0b252726f","1557682250-33bd709cbe85","1519608487953-e999c86e7455","1500534314209-a25ddb2bd429","1494438639946-1ebd1d20bf85","1534796636912-3b95b3ab5986","1493246507139-91e8fad9978e","1484101403633-562f891dc89a")
        val gameIds = listOf("1511512578047-dfb367046420","1542751371-adc38448a05e","1542751110-97427bbecf20","1519608487953-e999c86e7455","1535223289827-42f1e9919769","1500534314209-a25ddb2bd429","1486575673194-4e7f6b7b4a8f","1493711662062-fa541adb3fc8","1518005020951-eccb494ad742","1542751371-adc38448a05e")
        val idLists = listOf(natureIds, starIds, cityIds, carIds, minimalIds, abstractIds, gameIds)
        return data.flatMapIndexed { categoryIndex, (category, titles) ->
            titles.mapIndexed { index, title ->
                Wallpaper(
                    id = "${categoryIndex}_${index}",
                    title = title,
                    category = category,
                    imageUrl = "https://images.unsplash.com/photo-${idLists[categoryIndex][index]}?auto=format&fit=crop&w=2400&q=90"
                )
            }
        }
    }

    val resolutions = listOf(
        ResolutionOption("1080P", "FHD", 1080),
        ResolutionOption("2K", "1440p", 1440),
        ResolutionOption("4K", "2160p", 2160),
        ResolutionOption("8K", "4320p", 4320)
    )
    val categories = listOf("Doğa", "Yıldızlar", "Şehir", "Araçlar", "Minimal", "Soyut", "Oyun")

    var selectedResolution by mutableStateOf(resolutions[2])
        private set
    fun selectResolution(option: ResolutionOption) { selectedResolution = option }

    var favorites by mutableStateOf(setOf<String>())
        private set
    var randomWallpaperId by mutableStateOf(wallpapers.first().id)
        private set

    fun loadFavorites(context: Context) {
        val prefs = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        favorites = prefs.getStringSet(wallpapersKey, emptySet()) ?: emptySet()
    }
    fun toggleFavorite(id: String, context: Context) {
        favorites = if (id in favorites) favorites - id else favorites + id
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit().putStringSet(wallpapersKey, favorites).apply()
    }
    fun pickRandom() { if (wallpapers.isNotEmpty()) randomWallpaperId = wallpapers.random().id }
    fun dailyWallpaper(): Wallpaper {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        return wallpapers[day % wallpapers.size]
    }
    fun imageFor(item: Wallpaper): Any = item.localResId ?: ((item.imageUrl ?: "").substringBefore("?") + "?auto=format&fit=crop&w=${selectedResolution.width}&q=90")
    fun addWallpaper(title: String, category: String, imageUrl: String, resolution: ResolutionOption) {
        if (title.isBlank() || imageUrl.isBlank()) return
        wallpapers.add(0, Wallpaper("custom_${System.currentTimeMillis()}", title.trim(), category, imageUrl.trim(), resolutionLabel = resolution.label))
        selectedResolution = resolution
    }

    var themeDark by mutableStateOf(true); private set
    var accentIndex by mutableStateOf(0); private set
    var textColorIndex by mutableStateOf(0); private set
    var wifiOnly by mutableStateOf(true); private set
    var animationsEnabled by mutableStateOf(true); private set
    var notificationsEnabled by mutableStateOf(true); private set
    var dailyEnabled by mutableStateOf(true); private set
    var language by mutableStateOf("Türkçe"); private set
    var currentUserEmail by mutableStateOf<String?>(null); private set
    var currentUserName by mutableStateOf("Wextra Kullanıcı"); private set
    var isAdmin by mutableStateOf(false); private set

    val accentOptions = listOf(
        "Mor" to Color(0xFF8B5CF6),
        "Mavi" to Color(0xFF3B82F6),
        "Turkuaz" to Color(0xFF14B8A6),
        "Yeşil" to Color(0xFF22C55E),
        "Kırmızı" to Color(0xFFEF4444),
        "Pembe" to Color(0xFFEC4899),
        "Turuncu" to Color(0xFFF97316),
        "Sarı" to Color(0xFFEAB308)
    )
    val textColorOptions = listOf(
        "Beyaz" to Color(0xFFFFFFFF),
        "Açık gri" to Color(0xFFE2E8F0),
        "Mor" to Color(0xFFD8B4FE),
        "Mavi" to Color(0xFFBFDBFE),
        "Turkuaz" to Color(0xFF99F6E4),
        "Yeşil" to Color(0xFFBBF7D0),
        "Sarı" to Color(0xFFFDE68A),
        "Pembe" to Color(0xFFFBCFE8)
    )
    val currentAccent: Color get() = accentOptions[accentIndex].second
    val currentTextColor: Color get() = textColorOptions[textColorIndex].second

    fun loadAppState(context: Context) {
        val p = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        themeDark = p.getBoolean("theme_dark", true)
        accentIndex = p.getInt("accent_index", 0).coerceIn(0, accentOptions.lastIndex)
        textColorIndex = p.getInt("text_color_index", 0).coerceIn(0, textColorOptions.lastIndex)
        wifiOnly = p.getBoolean("wifi_only", true); animationsEnabled = p.getBoolean("animations", true)
        notificationsEnabled = p.getBoolean("notifications", true); dailyEnabled = p.getBoolean("daily", true)
        language = p.getString("language", "Türkçe") ?: "Türkçe"
        currentUserEmail = p.getString("current_email", null)
        currentUserName = p.getString("current_name", "Wextra Kullanıcı") ?: "Wextra Kullanıcı"
        isAdmin = p.getBoolean("current_admin", false)
    }
    private fun save(context: Context) { context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit()
        .putBoolean("theme_dark", themeDark).putInt("accent_index", accentIndex).putInt("text_color_index", textColorIndex).putBoolean("wifi_only", wifiOnly)
        .putBoolean("animations", animationsEnabled).putBoolean("notifications", notificationsEnabled).putBoolean("daily", dailyEnabled)
        .putString("language", language).putString("current_email", currentUserEmail).putString("current_name", currentUserName)
        .putBoolean("current_admin", isAdmin).apply() }
    fun setTheme(v:Boolean,c:Context){ themeDark=v; save(c) }
    fun setAccent(i:Int,c:Context){ accentIndex=i; save(c) }
    fun setTextColor(i:Int,c:Context){ textColorIndex=i; save(c) }
    fun tr(tr:String,en:String):String = if(language=="English") en else tr
    fun setWifi(v:Boolean,c:Context){ wifiOnly=v; save(c) }
    fun setAnimations(v:Boolean,c:Context){ animationsEnabled=v; save(c) }
    fun setNotifications(v:Boolean,c:Context){ notificationsEnabled=v; save(c) }
    fun setDaily(v:Boolean,c:Context){ dailyEnabled=v; save(c) }
    fun setLanguage(v:String,c:Context){ language=v; save(c) }
    fun signIn(email:String,name:String,admin:Boolean,c:Context){ currentUserEmail=email; currentUserName=name; isAdmin=admin; save(c) }
    fun updateName(name: String, c: Context) { currentUserName = name; save(c) }
    fun signOut(c:Context){ FirebaseAuth.getInstance().signOut(); currentUserEmail=null; currentUserName="Wextra Kullanıcı"; isAdmin=false; save(c) }
    fun logout(c: Context) = signOut(c)
}
@Composable
fun WextraApp(vm: WallpaperViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { vm.loadFavorites(context); vm.loadAppState(context) }
    WextraTheme(dark = vm.themeDark, accent = vm.currentAccent, textColor = vm.currentTextColor) {
        val nav = rememberNavController()
        NavHost(navController = nav, startDestination = "splash") {
            composable("splash") { SplashScreen(vm) { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
            composable("home") { MainScaffold(nav, vm, "home") { HomeScreen(vm, nav) } }
            composable("latest") { LatestScreen(vm, nav) }
            composable("swipe") { SwipeScreen(vm, nav) }
            composable("colors") { ColorExploreScreen(vm, nav) }
            composable("categories") { MainScaffold(nav, vm, "categories") { CategoriesScreen(vm, nav) } }
            composable("category/{name}", arguments = listOf(navArgument("name") { type = NavType.StringType })) {
                CategoryWallpapersScreen(it.arguments?.getString("name").orEmpty(), vm, nav)
            }
            composable("favorites") { MainScaffold(nav, vm, "favorites") { FavoritesScreen(vm, nav) } }
            composable("profile") { MainScaffold(nav, vm, "profile") { ProfileScreen(nav, vm) } }
            composable("history") { SimpleUserListScreen("Geçmişim", "Henüz görüntüleme geçmişi yok.", nav) }
            composable("collections") { SimpleUserListScreen("Koleksiyonlarım", "Henüz koleksiyon oluşturmadın.", nav) }
            composable("downloads") { SimpleUserListScreen("İndirdiklerim", "Henüz indirilen duvar kâğıdı yok.", nav) }
            composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
                val item = vm.wallpapers.first { w -> w.id == it.arguments?.getString("id") }
                DetailScreen(item, vm, item.id in vm.favorites, { vm.toggleFavorite(item.id, context) }, nav)
            }
            composable("login") { LoginScreen(nav, vm) }
            composable("register") { RegisterScreen(nav, vm) }
            composable("settings") { MainScaffold(nav, vm, "settings") { SettingsScreen(nav, vm) } }
            composable("adminLogin") { AdminLoginScreen(nav, vm) }
            composable("admin") { AdminScreen(nav, vm) }
            composable("adminAdd") { AdminAddWallpaperScreen(nav, vm) }
        }
    }
}
@Composable
fun SplashScreen(vm: WallpaperViewModel, onStart: () -> Unit) {
    var introStarted by remember { mutableStateOf(false) }
    val logoScale by animateFloatAsState(if (introStarted) 1.06f else 1f, tween(380), label = "logoScale")
    LaunchedEffect(introStarted) { if (introStarted) { ToneGenerator(AudioManager.STREAM_MUSIC, 35).startTone(ToneGenerator.TONE_PROP_ACK, 120); delay(420); onStart() } }

    Box(Modifier.fillMaxSize().background(Color(0xFF050817))) {
        AsyncImage(
            model = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1800&q=90",
            contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = .48f
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0xFF071027).copy(alpha=.72f), Color(0xFF171033).copy(alpha=.42f), Color(0xFF030611).copy(alpha=.92f)
        ))))
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(.18f))
            // PNG'nin koyu kutusu kaldırılmış şeffaf logo: yalnızca W ve nokta halkaları görünür.
            Image(painterResource(R.drawable.wextra_logo), "Wextra logosu",
                Modifier.size(196.dp).graphicsLayer { scaleX=logoScale; scaleY=logoScale })
            Spacer(Modifier.height(14.dp))
            Text("WEXTRA", fontSize=34.sp, fontWeight=FontWeight.ExtraBold, color=vm.currentAccent, letterSpacing=2.sp)
            Spacer(Modifier.height(8.dp))
            Text(vm.tr("Hayalindeki duvar kâğıtları şimdi cebinde!","Your dream wallpapers are now in your pocket!"),
                color=Color.White.copy(alpha=.82f), fontSize=16.sp)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                IntroFeature(Icons.Default.HighQuality, vm.tr("Yüksek kalite","High quality"), "4K & HD")
                IntroFeature(Icons.Default.Diamond, vm.tr("Özenle seçilmiş","Curated"), vm.tr("Kategoriler","Categories"))
                IntroFeature(Icons.Default.FavoriteBorder, vm.tr("Favorilerine","Favorites"), vm.tr("Ekle","Save"))
            }
            Spacer(Modifier.height(26.dp))
            Button(onClick={introStarted=true}, modifier=Modifier.fillMaxWidth().height(62.dp),
                shape=RoundedCornerShape(28.dp), colors=ButtonDefaults.buttonColors(containerColor=vm.currentAccent)) {
                Text(vm.tr("Başla","Start"), fontSize=20.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.width(16.dp)); Icon(Icons.Default.ArrowForward,null)
            }
            Spacer(Modifier.height(26.dp))
        }
    }
}

@Composable
private fun IntroFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Column(
        modifier = Modifier.width(100.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(76.dp),
            shape = CircleShape,
            color = Color(0xFF071021).copy(alpha = .76f),
            border = BorderStroke(1.dp, Color(0xFF7B78FF).copy(alpha = .36f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    icon,
                    null,
                    modifier = Modifier.size(32.dp),
                    tint = Accent
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color(0xFFE7E7F0), fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = Color(0xFFB9BBC8), fontSize = 13.sp)
    }
}

@Composable
fun MainScaffold(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, selected: String, content: @Composable () -> Unit) {
    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                listOf(
                    Triple("home",vm.tr("Ana Sayfa","Home"),Icons.Default.Home),
                    Triple("categories",vm.tr("Kategoriler","Categories"),Icons.Default.GridView),
                    Triple("favorites",vm.tr("Favoriler","Favorites"),Icons.Default.Favorite),
                    Triple("profile",vm.tr("Profil","Profile"),Icons.Default.Person),
                    Triple("settings",vm.tr("Ayarlar","Settings"),Icons.Default.Settings)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = selected == route,
                        onClick = { if (selected != route) nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, null) },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding -> Box(Modifier.padding(padding)) { content() } }
}

@Composable
fun HomeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    var query by remember { mutableStateOf("") }
    val filtered = vm.wallpapers.filter { it.title.contains(query, true) || it.category.contains(query, true) }
    val daily = vm.dailyWallpaper()
    val popular = filtered.take(5)
    val latest = filtered.drop(5).take(5).ifEmpty { vm.wallpapers.drop(5).take(5) }

    // Ana ekran sabit: dikey kaydırma yok. Kategori bölümü kaldırıldı.
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().height(58.dp)) {
            Image(
                painter = painterResource(id = R.drawable.wextra_logo),
                contentDescription = "Wextra",
                modifier = Modifier.size(54.dp)
            )
            Spacer(Modifier.weight(1f))
            Surface(shape = CircleShape, color = Surface, border = BorderStroke(1.dp, Accent.copy(alpha=.18f))) {
                IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "Bildirim") }
            }
        }

        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Surface,
            border = BorderStroke(1.dp, Accent.copy(alpha=.48f)),
            modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
            Row(Modifier.padding(horizontal=12.dp), verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint=Color.White.copy(alpha=.85f), modifier=Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                TextField(
                    value=query,
                    onValueChange={query=it},
                    placeholder={Text("Duvar kâğıdı ara...", color=TextMuted, fontSize=14.sp)},
                    singleLine=true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                    modifier=Modifier.weight(1f),
                    colors=TextFieldDefaults.colors(
                        focusedContainerColor=Color.Transparent,
                        unfocusedContainerColor=Color.Transparent,
                        focusedIndicatorColor=Color.Transparent,
                        unfocusedIndicatorColor=Color.Transparent
                    )
                )
                if(query.isNotBlank()) IconButton(onClick={query=""}, modifier=Modifier.size(36.dp)) {
                    Icon(Icons.Default.Close,null,tint=TextMuted, modifier=Modifier.size(18.dp))
                }
                Button(
                    onClick = {},
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(horizontal = 17.dp, vertical = 0.dp),
                    modifier = Modifier.height(34.dp)
                ) { Text("Ara", fontSize = 13.sp) }
            }
        }

        Card(
            modifier=Modifier.fillMaxWidth().height(145.dp).clickable{nav.navigate("detail/${daily.id}")},
            shape=RoundedCornerShape(22.dp),
            border=BorderStroke(1.dp, Color.White.copy(alpha=.12f))
        ) {
            Box(Modifier.fillMaxSize()) {
                AsyncImage(vm.imageFor(daily), daily.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Background.copy(alpha=.92f), Background.copy(alpha=.20f), Color.Transparent))))
                Column(
                    Modifier.align(Alignment.CenterStart).padding(horizontal=20.dp, vertical=14.dp),
                    verticalArrangement=Arrangement.Center
                ) {
                    Surface(color=Accent.copy(alpha=.24f), shape=RoundedCornerShape(10.dp)) {
                        Text("✦ Günün Seçimi", color=Color(0xFFCDBBFF), fontSize=10.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=8.dp,vertical=5.dp))
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(daily.title, fontSize=22.sp, fontWeight=FontWeight.Bold, maxLines=1)
                    Text("Yüksek kaliteli duvar kâğıtlarını keşfet", color=Color.White.copy(alpha=.72f), fontSize=11.sp)
                }
            }
        }

        CompactHomeSection("Popüler 🔥", popular, vm, nav, Modifier.weight(1f))
        CompactHomeSection("Yeni Eklenenler ✨", latest, vm, nav, Modifier.weight(1f))
    }
}

@Composable
private fun CompactHomeSection(
    title: String,
    items: List<Wallpaper>,
    vm: WallpaperViewModel,
    nav: androidx.navigation.NavHostController,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, fontWeight=FontWeight.Bold, fontSize=17.sp, modifier=Modifier.weight(1f))
            TextButton(onClick={nav.navigate("categories")}, contentPadding=PaddingValues(horizontal=4.dp, vertical=0.dp)) {
                Text("Tümünü Gör", fontSize=12.sp); Icon(Icons.Default.ChevronRight,null,modifier=Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items.take(5).forEach { item ->
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { nav.navigate("detail/${item.id}") }
                ) {
                    Card(
                        shape=RoundedCornerShape(13.dp),
                        border=BorderStroke(1.dp, Color.White.copy(alpha=.12f)),
                        modifier=Modifier.fillMaxWidth().weight(1f)
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                            Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(5.dp).align(Alignment.TopEnd).size(16.dp))
                            Surface(color=Accent.copy(alpha=.82f), shape=RoundedCornerShape(6.dp), modifier=Modifier.padding(5.dp).align(Alignment.BottomStart)) {
                                Text(item.resolutionLabel ?: "4K", fontSize=8.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=5.dp,vertical=2.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(item.title, fontWeight=FontWeight.SemiBold, maxLines=1, fontSize=10.sp)
                    Text("⇩ ${((item.id.hashCode().toUInt().toLong()%80)+42)/10.0}K", color=TextMuted, fontSize=8.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String, onAction: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Text(title, fontWeight=FontWeight.Bold, fontSize=20.sp, modifier=Modifier.weight(1f))
        TextButton(onClick=onAction) { Text(action); Icon(Icons.Default.ChevronRight,null,modifier=Modifier.size(18.dp)) }
    }
}

@Composable
private fun WallpaperHorizontalRow(items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    LazyRow(horizontalArrangement=Arrangement.spacedBy(14.dp), contentPadding=PaddingValues(top=6.dp)) {
        items(items) { item ->
            Column(Modifier.width(150.dp).clickable{nav.navigate("detail/${item.id}")}) {
                Card(shape=RoundedCornerShape(18.dp), border=BorderStroke(1.dp, Color.White.copy(alpha=.14f)), modifier=Modifier.fillMaxWidth().height(200.dp)) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale=ContentScale.Crop)
                        Icon(Icons.Default.FavoriteBorder,null,tint=Color.White,modifier=Modifier.padding(9.dp).align(Alignment.TopEnd))
                        Surface(color=Accent.copy(alpha=.78f), shape=RoundedCornerShape(8.dp), modifier=Modifier.padding(8.dp).align(Alignment.BottomStart)) { Text(vm.selectedResolution.label, fontSize=10.sp, fontWeight=FontWeight.Bold, modifier=Modifier.padding(horizontal=7.dp,vertical=4.dp)) }
                    }
                }
                Spacer(Modifier.height(7.dp)); Text(item.title, fontWeight=FontWeight.SemiBold, maxLines=1, fontSize=13.sp)
                Text("⇩ ${((item.id.hashCode().toUInt().toLong()%80)+42)/10.0}K", color=TextMuted, fontSize=11.sp)
            }
        }
    }
}
@Composable
fun ResolutionSelector(vm: WallpaperViewModel) {
    Card(
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.94f))
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Çözünürlük", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Uygulama içi görüntüleme kalitesi", color = TextMuted, fontSize = 9.sp)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                vm.resolutions.forEachIndexed { index, option ->
                    val selected = vm.selectedResolution == option
                    val tone = CategoryColors[index % CategoryColors.size]
                    FilledTonalButton(
                        onClick = { vm.selectResolution(option) },
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(horizontal = 1.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (selected) tone.copy(alpha = 0.32f) else tone.copy(alpha = 0.10f),
                            contentColor = if (selected) Color.White else tone
                        )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(option.label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(option.detail, fontSize = 7.sp, color = if (selected) Color.White.copy(alpha = 0.8f) else tone.copy(alpha = 0.85f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WallpaperGrid(items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController, modifier: Modifier = Modifier) {
    LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier.fillMaxWidth()) {
        items(items) { item ->
            Card(modifier = Modifier.fillMaxWidth().aspectRatio(.72f).clickable { nav.navigate("detail/${item.id}") }, shape = RoundedCornerShape(14.dp)) {
                Box {
                    AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Icon(Icons.Default.FavoriteBorder, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(7.dp).align(Alignment.TopEnd).size(20.dp))
                    Surface(color = Background.copy(alpha = .72f), modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()) {
                        Column(Modifier.padding(7.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                            Text(vm.selectedResolution.label, color = Accent, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoriesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val orderedNames = vm.categories
    val icons = listOf(Icons.Default.Landscape, Icons.Default.AutoAwesome, Icons.Default.LocationCity, Icons.Default.DirectionsCar, Icons.Default.Eco, Icons.Default.BlurOn, Icons.Default.SportsEsports)
    val categories = orderedNames.mapNotNull { name ->
        vm.wallpapers.filter { it.category == name }.takeIf { it.isNotEmpty() }?.let { name to it }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Kategoriler", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("En iyi duvar kâğıtlarını kategorilere göre keşfet", color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(categories) { (name, list) ->
                val index = orderedNames.indexOf(name)
                val tone = CategoryColors[index % CategoryColors.size]
                Card(
                    modifier = Modifier.height(205.dp).clickable { nav.navigate("category/$name") },
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, tone.copy(alpha = .75f)),
                    colors = CardDefaults.cardColors(containerColor = Surface)
                ) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(vm.imageFor(list.first()), name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Surface(
                            color = tone.copy(alpha = .25f),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.padding(10.dp).size(42.dp).align(Alignment.TopCenter)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(icons[index], null, tint = Color.White, modifier = Modifier.size(23.dp))
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().height(72.dp).align(Alignment.BottomCenter)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Background.copy(alpha = .92f))))
                        ) {
                            Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp).align(Alignment.BottomStart)) {
                                Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("• ${list.size}", color = Color.White.copy(alpha = .78f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryWallpapersScreen(categoryName: String, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val categoryItems = vm.wallpapers.filter { it.category == categoryName }
    Scaffold(
        containerColor = Background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(categoryName, fontWeight = FontWeight.Bold)
                        Text("${categoryItems.size} duvar kâğıdı", fontSize = 12.sp, color = TextMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Background)
            )
        }
    ) { padding ->
        if (categoryItems.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Bu kategoride henüz görsel yok.", color = TextMuted)
            }
        } else {
            WallpaperGrid(
                categoryItems,
                vm,
                nav,
                Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun WallpaperCard(
    item: Wallpaper,
    vm: WallpaperViewModel,
    nav: androidx.navigation.NavHostController
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val isFavorite = item.id in vm.favorites

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .clickable { nav.navigate("detail/${item.id}") },
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Box(Modifier.fillMaxSize()) {
            AsyncImage(
                model = vm.imageFor(item),
                contentDescription = item.title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(88.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Background.copy(alpha = 0.94f))
                        )
                    )
            )

            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(38.dp),
                shape = CircleShape,
                color = Background.copy(alpha = 0.72f)
            ) {
                IconButton(onClick = { vm.toggleFavorite(item.id, context) }) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (isFavorite) "Favorilerden kaldır" else "Favorilere ekle",
                        tint = if (isFavorite) vm.currentAccent else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(9.dp),
                shape = RoundedCornerShape(8.dp),
                color = vm.currentAccent.copy(alpha = 0.88f)
            ) {
                Text(
                    item.resolutionLabel ?: vm.selectedResolution.label,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(start = 9.dp, end = 9.dp, bottom = 9.dp)
                    .padding(top = 34.dp)
            ) {
                Text(
                    item.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Spacer(Modifier.height(3.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "❤️ ${((item.id.hashCode().toUInt().toLong() % 28) + 4) / 10.0}K",
                        color = Color.White.copy(alpha = 0.78f),
                        fontSize = 9.sp
                    )
                    Text(
                        "👁 ${((item.id.hashCode().toUInt().toLong() % 180) + 42) / 10.0}K",
                        color = Color.White.copy(alpha = 0.78f),
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
fun LatestScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val latest = vm.wallpapers.take(50)
    Scaffold(topBar={TopAppBar(title={Text("Yeni Eklenenler")},navigationIcon={IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)}})}){pad->
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.padding(pad).fillMaxSize().padding(12.dp), verticalArrangement=Arrangement.spacedBy(10.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)){
            items(latest){w-> WallpaperCard(w, vm, nav)}
        }
    }
}
@Composable
fun ColorExploreScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController){
    val colors=listOf("Mor" to Color(0xFF8B5CF6),"Mavi" to Color(0xFF3B82F6),"Pembe" to Color(0xFFEC4899),"Yeşil" to Color(0xFF22C55E),"Turuncu" to Color(0xFFF97316),"Altın" to Color(0xFFEAB308),"Turkuaz" to Color(0xFF14B8A6),"Kırmızı" to Color(0xFFEF4444))
    var selected by remember{mutableStateOf<String?>(null)}
    Column(Modifier.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text("Renge Göre Keşfet",fontSize=23.sp,fontWeight=FontWeight.Bold)};Text("Bir renk seç ve keşfet",color=TextMuted);Spacer(Modifier.height(18.dp));LazyVerticalGrid(GridCells.Fixed(4),modifier=Modifier.height(100.dp)){items(colors){c->Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{selected=c.first}){Surface(Modifier.size(48.dp),shape=CircleShape,color=c.second,border=BorderStroke(if(selected==c.first)3.dp else 0.dp,Color.White)){};Text(c.first,fontSize=10.sp)}}};Spacer(Modifier.height(10.dp));val shown=if(selected==null) vm.wallpapers else vm.wallpapers.filter{it.title.hashCode()%8==colors.indexOfFirst{c->c.first==selected}.mod(8)};LazyVerticalGrid(GridCells.Fixed(2),Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){items(shown){w->WallpaperCard(w,vm,nav)}}}
}
@Composable
fun SwipeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var index by remember { mutableStateOf(0) }
    if (vm.wallpapers.isEmpty()) return
    val w = vm.wallpapers[index % vm.wallpapers.size]

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, null)
            }
            Text("Wallpaper Swipe", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Text("Kaydır, beğen, keşfet", color = TextMuted)
        Spacer(Modifier.height(20.dp))
        AsyncImage(
            model = vm.imageFor(w),
            contentDescription = w.title,
            modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(18.dp))
        Text(w.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(onClick = { index++ }) {
                Icon(Icons.Default.Close, null)
                Text(" Geç")
            }
            Button(onClick = {
                vm.toggleFavorite(w.id, context)
                index++
            }) {
                Icon(Icons.Default.Favorite, null)
                Text(" Beğen")
            }
            OutlinedButton(onClick = { nav.navigate("detail/${w.id}") }) {
                Icon(Icons.Default.Info, null)
                Text(" Detay")
            }
        }
    }
}

@Composable
fun FavoritesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val list = vm.wallpapers.filter { it.id in vm.favorites }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal=16.dp,vertical=14.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text(vm.tr("Favoriler","Favorites"),fontSize=30.sp,fontWeight=FontWeight.Bold);Text(vm.tr("Beğendiğin duvar kâğıtlarına buradan hızlıca erişebilirsin.","Quickly access wallpapers you like from here."),color=TextMuted,fontSize=12.sp)}
            Surface(Modifier.size(48.dp),shape=CircleShape,color=vm.currentAccent.copy(alpha=.12f),border=BorderStroke(1.dp,vm.currentAccent.copy(alpha=.25f))){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Tune,null,tint=vm.currentAccent)}}
        }
        Spacer(Modifier.height(16.dp))
        if(list.isEmpty()){
            Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Surface(Modifier.size(86.dp),shape=CircleShape,color=vm.currentAccent.copy(alpha=.10f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.FavoriteBorder,null,Modifier.size(38.dp),tint=vm.currentAccent)}};Spacer(Modifier.height(14.dp));Text(vm.tr("Henüz favorin yok","No favorites yet"),fontWeight=FontWeight.Bold);Text(vm.tr("Beğendiğin duvar kâğıtları burada görünür.","Wallpapers you like will appear here."),color=TextMuted,fontSize=13.sp)}}
        } else {
            LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),modifier=Modifier.fillMaxSize()){
                items(list){item->
                    Card(onClick={nav.navigate("detail/${item.id}")},shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth().height(250.dp),border=BorderStroke(1.dp,Color.White.copy(alpha=.08f))){
                        Box(Modifier.fillMaxSize()){
                            AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent,Color(0xFF07101F).copy(alpha=.92f)))) )
                            Surface(Modifier.padding(10.dp).size(42.dp).align(Alignment.TopEnd),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)){Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Favorite,null,tint=Color.White)}}
                            Surface(color=vm.currentAccent.copy(alpha=.84f),shape=RoundedCornerShape(8.dp),modifier=Modifier.padding(10.dp).align(Alignment.TopStart)){Text(item.resolutionLabel?:vm.selectedResolution.label,fontSize=10.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=7.dp,vertical=3.dp))}
                            Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp)){Text(item.title,fontWeight=FontWeight.Bold,fontSize=16.sp,maxLines=1);Text("${item.category} • ${vm.selectedResolution.detail}",color=Color.White.copy(alpha=.72f),fontSize=11.sp)}
                        }
                    }
                }
            }
        }
    }
}


private suspend fun loadWallpaperBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.doInput = true
        connection.connect()
        connection.inputStream.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) {
        null
    }
}

private suspend fun applyWallpaper(context: Context, item: Wallpaper, imageModel: Any, which: Int): Boolean =
    withContext(Dispatchers.IO) {
        try {
            val bitmap = when (imageModel) {
                is Int -> BitmapFactory.decodeResource(context.resources, imageModel)
                is String -> loadWallpaperBitmap(imageModel)
                else -> null
            } ?: return@withContext false
            val manager = WallpaperManager.getInstance(context)
            manager.setBitmap(bitmap, null, true, which)
            true
        } catch (_: Exception) {
            false
        }
    }

@Composable
fun DetailScreen(item: Wallpaper, vm: WallpaperViewModel, isFavorite: Boolean, onFavorite: () -> Unit, nav: androidx.navigation.NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var showWallpaperChoice by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    if(showWallpaperChoice) AlertDialog(onDismissRequest={if(!working)showWallpaperChoice=false},title={Text(vm.tr("Duvar kâğıdı yap","Set wallpaper"))},text={Text(vm.tr("Nerede kullanmak istiyorsun?","Where would you like to use it?"))},confirmButton={TextButton(enabled=!working,onClick={working=true;scope.launch{val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Duvar kâğıdı ayarlandı","Wallpaper applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_LONG).show()}}){Text(vm.tr("Her ikisi","Both"))}},dismissButton={Row{TextButton(enabled=!working,onClick={scope.launch{working=true;val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_SYSTEM);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Ana ekran ayarlandı","Home screen applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_SHORT).show()}}){Text(vm.tr("Ana ekran","Home screen"))};TextButton(enabled=!working,onClick={scope.launch{working=true;val ok=applyWallpaper(context,item,vm.imageFor(item),WallpaperManager.FLAG_LOCK);working=false;showWallpaperChoice=false;Toast.makeText(context,if(ok)vm.tr("Kilit ekranı ayarlandı","Lock screen applied") else vm.tr("İşlem başarısız","Operation failed"),Toast.LENGTH_SHORT).show()}}){Text(vm.tr("Kilit ekranı","Lock screen"))}}})
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){
        Column(Modifier.fillMaxSize()){
            Box(Modifier.fillMaxWidth().weight(1f)){
                AsyncImage(vm.imageFor(item),item.title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha=.28f),Color.Transparent,Color.Black.copy(alpha=.18f)))))
                Row(Modifier.fillMaxWidth().padding(18.dp).statusBarsPadding(),horizontalArrangement=Arrangement.SpaceBetween){Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null,tint=Color.White)}};Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)){IconButton(onClick=onFavorite){Icon(if(isFavorite)Icons.Default.Favorite else Icons.Default.FavoriteBorder,null,tint=if(isFavorite)vm.currentAccent else Color.White)}};Surface(Modifier.size(52.dp),shape=CircleShape,color=Color(0xFF07101F).copy(alpha=.72f)){IconButton(onClick={Toast.makeText(context,vm.tr("Paylaşım yakında","Sharing coming soon"),Toast.LENGTH_SHORT).show()}){Icon(Icons.Default.Share,null,tint=Color.White)}}}}
                Row(Modifier.align(Alignment.BottomCenter).padding(bottom=18.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){repeat(4){i->Box(Modifier.size(if(i==0)24.dp else 10.dp,8.dp).clip(RoundedCornerShape(6.dp)).background(if(i==0)vm.currentAccent else Color.White.copy(alpha=.38f)))}}
            }
            Card(shape=RoundedCornerShape(topStart=30.dp,topEnd=30.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.background),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(horizontal=20.dp,vertical=14.dp)){
                    Box(Modifier.width(42.dp).height(4.dp).align(Alignment.CenterHorizontally).clip(RoundedCornerShape(4.dp)).background(TextMuted.copy(alpha=.6f)))
                    Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(item.title,fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Text("♧  ${item.category}",color=CategoryColors.first(),fontSize=15.sp)};Surface(shape=RoundedCornerShape(16.dp),color=vm.currentAccent.copy(alpha=.13f)){Text("${item.resolutionLabel?:"4K"} Ultra HD",color=vm.currentAccent,fontWeight=FontWeight.Bold,modifier=Modifier.padding(horizontal=14.dp,vertical=10.dp))}}
                    Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){DetailInfo(Modifier.weight(1f),Icons.Default.AspectRatio,vm.selectedResolution.detail,vm.tr("Çözünürlük","Resolution"),vm);DetailInfo(Modifier.weight(1f),Icons.Default.PhotoSizeSelectLarge,"9:16",vm.tr("Oran","Ratio"),vm);DetailInfo(Modifier.weight(1f),Icons.Default.Storage,"3,2 MB",vm.tr("Boyut","Size"),vm)}
                    Spacer(Modifier.height(14.dp));Text(vm.tr("Doğanın büyüleyici güzelliğini yansıtan bu duvar kâğıdı, cihazınıza huzur ve ferahlık getirir.","This wallpaper reflects the captivating beauty of nature and brings calm to your device."),color=TextMuted,fontSize=13.sp,lineHeight=20.sp)
                    Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){Button(enabled=!working,onClick={ if(vm.currentUserEmail==null) nav.navigate("login") else showWallpaperChoice=true },modifier=Modifier.weight(1f).height(58.dp),shape=RoundedCornerShape(20.dp)){Icon(Icons.Default.Wallpaper,null);Spacer(Modifier.width(8.dp));Text(if(working)vm.tr("İşleniyor...","Working...")else vm.tr("Duvar Kâğıdı Yap","Set Wallpaper"),fontWeight=FontWeight.Bold)};OutlinedButton(onClick={Toast.makeText(context,vm.tr("Paylaşım yakında","Sharing coming soon"),Toast.LENGTH_SHORT).show()},modifier=Modifier.width(86.dp).height(58.dp),shape=RoundedCornerShape(20.dp)){Icon(Icons.Default.Share,null)}}
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}
@Composable private fun DetailInfo(modifier:Modifier,icon:androidx.compose.ui.graphics.vector.ImageVector,value:String,label:String,vm:WallpaperViewModel){Card(modifier=modifier.height(72.dp),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=vm.currentAccent,modifier=Modifier.size(22.dp));Spacer(Modifier.width(7.dp));Column{Text(value,fontWeight=FontWeight.Bold,fontSize=13.sp);Text(label,color=TextMuted,fontSize=10.sp)}}}}


@Composable
fun LoginScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    fun Context.findActivity(): Activity? = when (this) { is Activity -> this; is ContextWrapper -> baseContext.findActivity(); else -> null }
    val activity=context.findActivity(); val auth=remember{FirebaseAuth.getInstance()}
    var email by remember{mutableStateOf("")}; var password by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(false)}; var error by remember{mutableStateOf("")}
    fun finishLogin(user: FirebaseUser?) { if(user==null){loading=false;error=vm.tr("Kullanıcı bulunamadı.","User not found.");return}; vm.signIn(user.email.orEmpty(),user.displayName?:user.email?.substringBefore("@").orEmpty(),false,context);loading=false;nav.navigate("profile"){popUpTo("login"){inclusive=true}} }
    val googleLauncher=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ r->
        if(r.resultCode==Activity.RESULT_OK){ val task=GoogleSignIn.getSignedInAccountFromIntent(r.data); try{val account=task.result;val token=account.idToken;if(token.isNullOrBlank()){loading=false;error="Google token alınamadı."}else auth.signInWithCredential(GoogleAuthProvider.getCredential(token,null)).addOnSuccessListener{finishLogin(it.user)}.addOnFailureListener{ex->loading=false;error=ex.message?:"Google ile giriş başarısız."}}catch(ex:Exception){loading=false;error=ex.message?:"Google ile giriş başarısız."}}
        else { loading=false; error=vm.tr("Google girişi iptal edildi.","Google sign-in was cancelled.") }
    }
    fun googleLogin(){ if(activity==null){error="Google girişi başlatılamadı.";return}; val id=try{context.getString(R.string.default_web_client_id)}catch(_:Exception){""}; if(id.isBlank()){error="Google yapılandırması eksik.";return}; loading=true;error=""; val client=GoogleSignIn.getClient(context,GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(id).requestEmail().build()); client.signOut().addOnCompleteListener{googleLauncher.launch(client.signInIntent)} }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).statusBarsPadding().navigationBarsPadding(), horizontalAlignment=Alignment.CenterHorizontally){
            Spacer(Modifier.height(34.dp))
            Surface(Modifier.size(116.dp),shape=CircleShape,color=vm.currentAccent.copy(alpha=.12f),border=BorderStroke(1.dp,vm.currentAccent.copy(alpha=.32f))){Box(contentAlignment=Alignment.Center){Image(painterResource(R.drawable.wextra_logo),"Wextra",Modifier.size(86.dp))}}
            Spacer(Modifier.height(22.dp))
            Text(vm.tr("Tekrar hoş geldin","Welcome back"),fontSize=30.sp,fontWeight=FontWeight.Bold)
            Text(vm.tr("Favorilerin ve hesabın seni bekliyor.","Your favorites and account are waiting for you."),color=TextMuted,fontSize=14.sp)
            Spacer(Modifier.height(28.dp))
            Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(18.dp)){
                    Text(vm.tr("Hesabına giriş yap","Sign in to your account"),fontWeight=FontWeight.SemiBold,fontSize=18.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(email,{email=it},label={Text(vm.tr("E-posta","Email"))},leadingIcon={Icon(Icons.Default.Email,null)},singleLine=true,enabled=!loading,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(password,{password=it},label={Text(vm.tr("Şifre","Password"))},leadingIcon={Icon(Icons.Default.Lock,null)},singleLine=true,enabled=!loading,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
                    if(error.isNotEmpty()) Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
                    Spacer(Modifier.height(16.dp))
                    Button(enabled=!loading,onClick={if(email.isBlank()||password.isBlank()){error=vm.tr("E-posta ve şifreyi gir.","Enter email and password.");return@Button};loading=true;error="";auth.signInWithEmailAndPassword(email.trim(),password).addOnSuccessListener{finishLogin(it.user)}.addOnFailureListener{ex->loading=false;error=ex.message?:vm.tr("Giriş başarısız.","Sign-in failed.")}},modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(20.dp)){Text(if(loading)vm.tr("Giriş yapılıyor...","Signing in...")else vm.tr("Giriş yap","Sign in"),fontWeight=FontWeight.Bold)}
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(enabled=!loading,onClick=::googleLogin,modifier=Modifier.fillMaxWidth().height(54.dp),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.AccountCircle,null,tint=vm.currentAccent);Spacer(Modifier.width(10.dp));Text(vm.tr("Google ile devam et","Continue with Google"))}
                }
            }
            TextButton(onClick={nav.navigate("register")},modifier=Modifier.padding(top=12.dp)){Text(vm.tr("Hesabın yok mu? Hesap oluştur","No account? Create one"),color=vm.currentAccent)}
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
fun RegisterScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.PersonAdd, null, modifier = Modifier.size(72.dp), tint = Accent)
        Spacer(Modifier.height(14.dp))
        Text("Hesap oluştur", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("E-posta veya Google hesabınla kayıt ol", color = TextMuted)
        Spacer(Modifier.height(18.dp))
        GoogleSignInButton(nav, vm, "Google ile kayıt ol")
        Text("veya", color=TextMuted, fontSize=12.sp, modifier=Modifier.padding(vertical=8.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Kullanıcı adı") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !loading)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(email, { email = it }, label = { Text("E-posta") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !loading)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Şifre (en az 6 karakter)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, enabled = !loading)
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        Button(enabled = !loading, onClick = {
            val cleanName = name.trim()
            if (cleanName.isBlank() || email.isBlank() || password.length < 6) { error = "Tüm alanları doldur ve en az 6 karakterli şifre kullan."; return@Button }
            loading = true; error = ""
            auth.createUserWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (user == null) { loading = false; error = "Hesap oluşturulamadı."; return@addOnSuccessListener }
                    val request = com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(cleanName).build()
                    user.updateProfile(request).addOnCompleteListener {
                        vm.signIn(user.email.orEmpty(), cleanName, false, context)
                        loading = false
                        nav.navigate("profile") { popUpTo("register") { inclusive = true } }
                    }
                }
                .addOnFailureListener { ex -> loading = false; error = ex.message ?: "Kayıt başarısız." }
        }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(if (loading) "Hesap oluşturuluyor..." else "E-posta ile kayıt ol") }
        TextButton(enabled = !loading, onClick = { nav.popBackStack() }) { Text("Zaten hesabın var mı? Giriş yap") }
    }
}

@Composable
private fun GoogleSignInButton(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, label: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    fun Context.findActivity(): Activity? = when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }
    val activity = context.findActivity()
    val auth = remember { FirebaseAuth.getInstance() }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    fun finish(user: FirebaseUser?) {
        if (user == null) { loading=false; error="Google hesabı alınamadı."; return }
        vm.signIn(user.email.orEmpty(), user.displayName ?: user.email?.substringBefore("@").orEmpty(), false, context)
        loading=false
        nav.navigate("profile") { launchSingleTop = true }
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK) {
            loading=false
            error="Google hesabı seçilmedi veya giriş iptal edildi."
            return@rememberLauncherForActivityResult
        }
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                .getResult(com.google.android.gms.common.api.ApiException::class.java)
            val token = account.idToken
            if (token.isNullOrBlank()) {
                loading=false; error="Google kimlik belirteci alınamadı. google-services.json ve OAuth istemci yapılandırmasını kontrol et."
            } else {
                auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null))
                    .addOnSuccessListener { finish(it.user) }
                    .addOnFailureListener { ex -> loading=false; error=ex.message ?: "Firebase Google girişi başarısız." }
            }
        } catch (ex: com.google.android.gms.common.api.ApiException) {
            loading=false
            error = "Google giriş hatası (${ex.statusCode}): " + when(ex.statusCode) {
                10 -> "Bu APK'nın SHA-1/SHA-256 değeri Firebase'e eklenmemiş veya OAuth Android istemcisi eşleşmiyor."
                12500 -> "OAuth istemcisi yapılandırılmamış."
                7 -> "Ağ bağlantısını kontrol et."
                else -> (ex.message ?: "Google hesabı doğrulanamadı.")
            }
        } catch (ex: Exception) { loading=false; error=ex.message ?: "Google girişi başarısız." }
    }

    OutlinedButton(enabled=!loading, onClick={
        if (activity == null) { error="Google girişi bu cihazda başlatılamadı."; return@OutlinedButton }
        val webClientId = try { context.getString(R.string.default_web_client_id) } catch (_: Exception) { "" }
        if (webClientId.isBlank()) { error="default_web_client_id bulunamadı. Güncel google-services.json gerekli."; return@OutlinedButton }
        loading=true; error=""
        val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId).requestEmail().build()
        val client = GoogleSignIn.getClient(context, options)
        client.signOut().addOnCompleteListener { launcher.launch(client.signInIntent) }
    }, modifier=Modifier.fillMaxWidth().height(50.dp)) {
        Icon(Icons.Default.AccountCircle, null); Spacer(Modifier.width(8.dp)); Text(if(loading) "Google açılıyor..." else label)
    }
    if(error.isNotEmpty()) Text(error, color=MaterialTheme.colorScheme.error, fontSize=11.sp, modifier=Modifier.padding(top=6.dp))
}

@Composable
fun GuestProfileScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    Column(
        Modifier.fillMaxSize().background(Background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Person, null, modifier = Modifier.size(74.dp), tint = vm.currentAccent)
        Spacer(Modifier.height(18.dp))
        Text(vm.tr("Kullanıcı Profili","User Profile"), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(vm.tr("Favorilerin, geçmişin ve hesabın için giriş yap.","Sign in for your favorites, history and account."), color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { nav.navigate("login") }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Giriş yap") }
        Spacer(Modifier.height(10.dp))
        GoogleSignInButton(nav, vm, "Google ile devam et")
        OutlinedButton(onClick = { nav.navigate("register") }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(52.dp)) { Text("Hesap oluştur") }
    }
}

@Composable
fun ProfileScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var nameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    val firebaseUser = FirebaseAuth.getInstance().currentUser
    if (firebaseUser == null && vm.currentUserEmail == null) {
        GuestProfileScreen(nav, vm)
        return
    }
    val email = firebaseUser?.email ?: vm.currentUserEmail
    val displayName = firebaseUser?.displayName ?: vm.currentUserName.ifBlank { "Wextra Kullanıcısı" }
    val photo = firebaseUser?.photoUrl
    val favoriteCount = vm.favorites.size
    val badge = when {
        favoriteCount >= 25 -> "🥇 Wextra Explorer"
        favoriteCount >= 10 -> "🥈 Aktif Kullanıcı"
        else -> "🥉 Yeni Kullanıcı"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Kullanıcı", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Hesabın, koleksiyonların ve aktivitelerin", color = TextMuted, fontSize = 13.sp)
        }

        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Surface)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (photo != null) {
                        AsyncImage(photo, "Profil fotoğrafı", Modifier.size(88.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    } else {
                        Box(
                            Modifier.size(88.dp).clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Color(0xFF8B5CFF), Color(0xFF19C6E8)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(displayName.take(1).uppercase(), fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(displayName, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(email ?: "Misafir kullanıcı", color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    AssistChip(onClick = {}, label = { Text(badge) })
                }
            }
        }

        item { Text("Kullanıcı Alanlarım", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item {
            Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface)) {
                Column {
                    UserActionRow(Icons.Default.Favorite, "Favorilerim", "$favoriteCount duvar kâğıdı") { nav.navigate("favorites") }
                    HorizontalDivider(color = TextMuted.copy(alpha = .12f))
                    UserActionRow(Icons.Default.History, "Geçmişim", "Görüntülediklerin") { nav.navigate("history") }
                    HorizontalDivider(color = TextMuted.copy(alpha = .12f))
                    UserActionRow(Icons.Default.Folder, "Koleksiyonlarım", "Kendi listelerin") { nav.navigate("collections") }
                    HorizontalDivider(color = TextMuted.copy(alpha = .12f))
                    UserActionRow(Icons.Default.Download, "İndirdiklerim", "Kaydedilen duvar kâğıtları") { nav.navigate("downloads") }
                }
            }
        }

        item { Text("Hesabım", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        item {
            Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface)) {
                Column {
                    UserActionRow(Icons.Default.Edit, "Kullanıcı adını değiştir", "Profil adını güncelle") {
                        newName = displayName
                        nameDialog = true
                    }
                    HorizontalDivider(color = TextMuted.copy(alpha = .12f))
                    UserActionRow(Icons.Default.Logout, "Çıkış yap", "Hesaptan güvenli çıkış") {
                        vm.signOut(context)
                        nav.navigate("login") { popUpTo(0) }
                    }
                    HorizontalDivider(color = TextMuted.copy(alpha = .12f))
                    UserActionRow(Icons.Default.Delete, "Hesabımı kalıcı olarak sil", "Bu işlem geri alınamaz") {
                        deleteDialog = true
                    }
                }
            }
        }
    }

    if (nameDialog) {
        AlertDialog(
            onDismissRequest = { nameDialog = false },
            title = { Text("Kullanıcı adını değiştir") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Yeni kullanıcı adı") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmed = newName.trim()
                    if (trimmed.isNotEmpty()) {
                        val request = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                            .setDisplayName(trimmed)
                            .build()
                        FirebaseAuth.getInstance().currentUser?.updateProfile(request)
                        vm.updateName(trimmed, context)
                        Toast.makeText(context, "Kullanıcı adı güncellendi.", Toast.LENGTH_SHORT).show()
                    }
                    nameDialog = false
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { nameDialog = false }) { Text("İptal") } }
        )
    }

    if (deleteDialog) {
        AlertDialog(
            onDismissRequest = { deleteDialog = false },
            title = { Text("Hesabı sil") },
            text = { Text("Hesabın kalıcı olarak silinecek. Bu işlem geri alınamaz. Devam etmek istiyor musun?") },
            confirmButton = {
                TextButton(onClick = {
                    FirebaseAuth.getInstance().currentUser?.delete()
                        ?.addOnCompleteListener {
                            vm.signOut(context)
                            nav.navigate("login") { popUpTo(0) }
                        }
                    deleteDialog = false
                }) { Text("Kalıcı olarak sil", color = Color.Red) }
            },
            dismissButton = { TextButton(onClick = { deleteDialog = false }) { Text("Vazgeç") } }
        )
    }
}

@Composable
fun UserActionRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Accent)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextMuted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
    }
}

@Composable
fun SimpleUserListScreen(
    title: String,
    emptyMessage: String,
    nav: androidx.navigation.NavHostController
) {
    Column(Modifier.fillMaxSize().background(Background).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyMessage, color = TextMuted)
        }
    }
}

@Composable
fun SettingsScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    val context=androidx.compose.ui.platform.LocalContext.current
    var dialog by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text(vm.tr("Ayarlar","Settings"),fontSize=27.sp,fontWeight=FontWeight.Bold)}
        Text(vm.tr("Görünümünü ve uygulama deneyimini kişiselleştir.","Personalize the appearance and your app experience."),color=TextMuted,fontSize=13.sp)
        Spacer(Modifier.height(16.dp));Text(vm.tr("Görünüm","Appearance"),color=vm.currentAccent,fontSize=14.sp,fontWeight=FontWeight.Bold)
        SettingsRow(Icons.Default.DarkMode,vm.tr("Tema","Theme"),if(vm.themeDark) vm.tr("Koyu","Dark") else vm.tr("Açık","Light")){vm.setTheme(!vm.themeDark,context)}
        SettingsRow(Icons.Default.Palette,vm.tr("Renk Teması","Color Theme"),vm.accentOptions[vm.accentIndex].first){dialog="accent"}
        SettingsRow(Icons.Default.FormatColorText,vm.tr("Yazı Rengi","Text Color"),vm.textColorOptions[vm.textColorIndex].first){dialog="textColor"}
        Spacer(Modifier.height(14.dp));Text(vm.tr("Bildirimler","Notifications"),color=vm.currentAccent,fontSize=14.sp,fontWeight=FontWeight.Bold)
        SettingsSwitch(Icons.Default.Notifications,vm.tr("Yeni duvar kâğıdı bildirimi","New wallpaper notifications"),vm.notificationsEnabled){vm.setNotifications(it,context)}
        SettingsSwitch(Icons.Default.AutoAwesome,vm.tr("Günün duvar kâğıdı","Wallpaper of the day"),vm.dailyEnabled){vm.setDaily(it,context)}
        Spacer(Modifier.height(14.dp));Text(vm.tr("Duvar Kâğıdı","Wallpaper"),color=vm.currentAccent,fontSize=14.sp,fontWeight=FontWeight.Bold)
        SettingsRow(Icons.Default.HighQuality,vm.tr("Varsayılan kalite","Default quality"),vm.selectedResolution.label){dialog="resolution"}
        SettingsSwitch(Icons.Default.Wifi,vm.tr("Yalnızca Wi‑Fi ile yüksek kalite","High quality on Wi‑Fi only"),vm.wifiOnly){vm.setWifi(it,context)}
        SettingsSwitch(Icons.Default.Animation,vm.tr("Önizleme animasyonu","Preview animation"),vm.animationsEnabled){vm.setAnimations(it,context)}
        Spacer(Modifier.height(14.dp));Text(vm.tr("Uygulama","Application"),color=vm.currentAccent,fontSize=14.sp,fontWeight=FontWeight.Bold)
        SettingsRow(Icons.Default.Language,vm.tr("Dil","Language"),vm.language){dialog="language"}
        SettingsRow(Icons.Default.DeleteSweep,vm.tr("Önbelleği temizle","Clear cache"),vm.tr("Yerel önbellek","Local cache")){Toast.makeText(context,vm.tr("Önbellek temizlendi","Cache cleared"),Toast.LENGTH_SHORT).show()}
        SettingsRow(Icons.Default.Info,vm.tr("Uygulama hakkında","About app"),"Wextra 1.1"){}
        Spacer(Modifier.height(14.dp));Text(vm.tr("Yönetim","Management"),color=vm.currentAccent,fontSize=14.sp,fontWeight=FontWeight.Bold)
        SettingsRow(Icons.Default.AdminPanelSettings,if(vm.currentUserEmail != null && vm.isAdmin) vm.tr("Admin Paneli","Admin Panel") else vm.tr("Admin Girişi","Admin Login"),if(vm.currentUserEmail != null && vm.isAdmin) vm.tr("Yönetim panelini aç","Open management panel") else vm.tr("Yetkili hesapla giriş yap","Sign in with an authorized account")){if(vm.currentUserEmail == null || !vm.isAdmin) nav.navigate("adminLogin") else nav.navigate("admin")}
        Spacer(Modifier.height(24.dp))
    }
    when(dialog){
        "accent"->ColorChoiceDialog(vm.tr("Renk Teması","Color Theme"),vm.accentOptions,vm.accentIndex){vm.setAccent(it,context);dialog=null}
        "textColor"->ColorChoiceDialog(vm.tr("Yazı Rengi","Text Color"),vm.textColorOptions,vm.textColorIndex){vm.setTextColor(it,context);dialog=null}
        "resolution"->ChoiceDialog(vm.tr("Varsayılan kalite","Default quality"),vm.resolutions.map{it.label},vm.resolutions.indexOf(vm.selectedResolution)){vm.selectResolution(vm.resolutions[it]);dialog=null}
        "language"->ChoiceDialog(vm.tr("Dil","Language"),listOf("Türkçe","English"),if(vm.language=="Türkçe")0 else 1){vm.setLanguage(if(it==0)"Türkçe" else "English",context);dialog=null}
    }
}
@Composable fun ColorChoiceDialog(title:String, options:List<Pair<String,Color>>, selected:Int, onPick:(Int)->Unit){
    AlertDialog(onDismissRequest={},title={Text(title)},text={
        Column{ Text("${options.size} ${if(title.contains("Renk")) "renk seçeneği" else "options"}",color=TextMuted,fontSize=12.sp);Spacer(Modifier.height(12.dp));
        options.chunked(2).forEachIndexed{rowIndex,row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){row.forEachIndexed{colIndex,item->val index=rowIndex*2+colIndex;Card(onClick={onPick(index)},modifier=Modifier.weight(1f).height(76.dp),shape=RoundedCornerShape(16.dp),border=if(index==selected)BorderStroke(2.dp,item.second) else BorderStroke(1.dp,TextMuted.copy(alpha=.2f))){Column(Modifier.fillMaxSize().padding(10.dp),verticalArrangement=Arrangement.SpaceBetween){Surface(Modifier.size(28.dp),shape=CircleShape,color=item.second){};Text(item.first,fontSize=13.sp,maxLines=1)}}}};Spacer(Modifier.height(10.dp))}
        }
    },confirmButton={})
}
@Composable fun ChoiceDialog(title:String, options:List<String>, selected:Int, onPick:(Int)->Unit){AlertDialog(onDismissRequest={},title={Text(title)},text={Column{options.forEachIndexed{i,v->Row(Modifier.fillMaxWidth().clickable{onPick(i)}.padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selected=i==selected,onClick={onPick(i)});Text(v,modifier=Modifier.padding(start=8.dp))}}}},confirmButton={})}
@Composable fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,value:String,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(top=7.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(horizontal=15.dp,vertical=15.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(38.dp),shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.width(12.dp));Text(title,modifier=Modifier.weight(1f));Text(value,color=TextMuted,fontSize=12.sp);Icon(Icons.Default.ChevronRight,null,tint=TextMuted)}}}
@Composable fun SettingsSwitch(icon: androidx.compose.ui.graphics.vector.ImageVector,title:String,checked:Boolean,onChecked:(Boolean)->Unit){Card(modifier=Modifier.fillMaxWidth().padding(top=7.dp),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(horizontal=15.dp,vertical=11.dp),verticalAlignment=Alignment.CenterVertically){Surface(Modifier.size(38.dp),shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.primary.copy(alpha=.12f)){Box(contentAlignment=Alignment.Center){Icon(icon,null,tint=MaterialTheme.colorScheme.primary)}};Spacer(Modifier.width(12.dp));Text(title,modifier=Modifier.weight(1f),fontSize=14.sp);Switch(checked=checked,onCheckedChange=onChecked)}}}

@Composable
fun AdminLoginScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel){
    val context=androidx.compose.ui.platform.LocalContext.current; val auth=remember{FirebaseAuth.getInstance()}
    var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var loading by remember{mutableStateOf(false)}
    fun openAdmin(user:FirebaseUser){val e=user.email?.trim()?.lowercase().orEmpty();user.getIdToken(false).addOnSuccessListener{token->loading=false;if(token.claims["admin"]==true||e=="wextra.project@gmail.com"){vm.signIn(e,"Wextra",true,context);nav.navigate("admin"){popUpTo("adminLogin"){inclusive=true}}}else{auth.signOut();error=vm.tr("Bu hesap için admin yetkisi yok.","This account has no admin permission.")}}.addOnFailureListener{ex->loading=false;auth.signOut();error=ex.message?:vm.tr("Admin yetkisi doğrulanamadı.","Admin permission could not be verified.")}}
    fun submit(){val e=email.trim().lowercase();if(e.isBlank()||password.isBlank()){error=vm.tr("E-posta ve şifreyi gir.","Enter email and password.");return};loading=true;error="";auth.signInWithEmailAndPassword(e,password).addOnSuccessListener{r->r.user?.let(::openAdmin)?:run{loading=false;error=vm.tr("Kullanıcı bulunamadı.","User not found.")}}.addOnFailureListener{ex->loading=false;error=ex.message?:vm.tr("E-posta veya şifre hatalı.","Incorrect email or password.")}}
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=24.dp).statusBarsPadding().navigationBarsPadding(),horizontalAlignment=Alignment.CenterHorizontally){
            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Spacer(Modifier.width(4.dp));Text("WEXTRA",fontWeight=FontWeight.ExtraBold,color=vm.currentAccent,letterSpacing=2.sp)}
            Spacer(Modifier.height(30.dp))
            Surface(Modifier.size(132.dp),shape=RoundedCornerShape(34.dp),color=vm.currentAccent.copy(alpha=.10f),border=BorderStroke(1.dp,vm.currentAccent.copy(alpha=.28f))){Box(contentAlignment=Alignment.Center){Image(painterResource(R.drawable.wextra_logo),"Wextra Admin",Modifier.size(104.dp))}}
            Spacer(Modifier.height(22.dp));Text(vm.tr("Yönetim Merkezi","Management Center"),fontSize=30.sp,fontWeight=FontWeight.Bold)
            Text(vm.tr("Yetkili yöneticiler için güvenli erişim","Secure access for authorized administrators"),color=TextMuted,fontSize=14.sp)
            Spacer(Modifier.height(24.dp))
            Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(18.dp)){
                    Text(vm.tr("Yönetici doğrulaması","Administrator verification"),fontWeight=FontWeight.SemiBold,fontSize=18.sp)
                    Text(vm.tr("Hesabın ve yetkin Firebase üzerinden kontrol edilir.","Your account and permissions are checked through Firebase."),color=TextMuted,fontSize=12.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(email,{email=it},label={Text(vm.tr("Admin e-posta","Admin email"))},leadingIcon={Icon(Icons.Default.AdminPanelSettings,null)},singleLine=true,enabled=!loading,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
                    Spacer(Modifier.height(10.dp));OutlinedTextField(password,{password=it},label={Text(vm.tr("Şifre","Password"))},leadingIcon={Icon(Icons.Default.Lock,null)},singleLine=true,enabled=!loading,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp))
                    if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp,modifier=Modifier.padding(top=8.dp))
                    Spacer(Modifier.height(16.dp));Button(enabled=!loading,onClick=::submit,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(20.dp)){Icon(Icons.Default.Lock,null);Spacer(Modifier.width(8.dp));Text(if(loading)vm.tr("Doğrulanıyor...","Verifying...")else vm.tr("Yönetim paneline giriş yap","Enter admin panel"),fontWeight=FontWeight.Bold)}
                }
            }
            Spacer(Modifier.height(18.dp));Text(vm.tr("Yetkisiz erişim engellenir.","Unauthorized access is blocked."),color=TextMuted,fontSize=12.sp)
        }
    }
}

@Composable
fun AdminScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    if(!vm.isAdmin){ LaunchedEffect(Unit){ nav.navigate("adminLogin") }; return }
    var query by remember { mutableStateOf("") }
    val shown = vm.wallpapers.filter { it.title.contains(query,true) || it.category.contains(query,true) }
    LazyColumn(Modifier.fillMaxSize().background(Background).padding(horizontal=16.dp), contentPadding=PaddingValues(vertical=12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.Menu,null)}
                Text("Admin Paneli", fontSize=23.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                BadgedBox(badge={Badge{}}){IconButton(onClick={}){Icon(Icons.Default.Notifications, null)}}
            }
        }
        item {
            Text("Genel Bakış", fontWeight=FontWeight.Bold, color=TextMuted)
            LazyVerticalGrid(columns=GridCells.Fixed(2), modifier=Modifier.height(190.dp), verticalArrangement=Arrangement.spacedBy(9.dp), horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                item{AdminStat("Toplam Duvar Kâğıdı", vm.wallpapers.size.toString(), Icons.Default.Wallpaper, Color(0xFF8B7BFF))}
                item{AdminStat("Toplam Kullanıcı", "18.256", Icons.Default.People, Color(0xFF4CB7FF))}
                item{AdminStat("Toplam Görüntülenme", "245.7K", Icons.Default.Visibility, Color(0xFF39D6A3))}
                item{AdminStat("Toplam Beğeni", "89.3K", Icons.Default.Favorite, Color(0xFFFF6FA8))}
            }
        }
        item {
            Text("Hızlı İşlemler", fontWeight=FontWeight.Bold)
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) {
                AdminAction(Modifier.weight(1f),"Duvar Kâğıdı Ekle",Icons.Default.AddPhotoAlternate,Color(0xFF7A4DFF)){nav.navigate("adminAdd")}
                AdminAction(Modifier.weight(1f),"Kategoriler",Icons.Default.GridView,Color(0xFF377DFF)){nav.navigate("categories")}
            }
        }
        item { OutlinedTextField(query,{query=it},leadingIcon={Icon(Icons.Default.Search,null)},label={Text("Duvar kâğıtlarında ara")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item { Text("Duvar Kâğıtları", fontWeight=FontWeight.Bold, fontSize=19.sp) }
        items(shown.take(40)) { w ->
            Card(shape=RoundedCornerShape(17.dp), colors=CardDefaults.cardColors(containerColor=Surface)) {
                Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment=Alignment.CenterVertically) {
                    AsyncImage(vm.imageFor(w),w.title,Modifier.size(74.dp).clip(RoundedCornerShape(12.dp)),contentScale=ContentScale.Crop)
                    Spacer(Modifier.width(11.dp)); Column(Modifier.weight(1f)) { Text(w.title,fontWeight=FontWeight.SemiBold); Text("${w.category} • ${w.resolutionLabel ?: vm.selectedResolution.label}",color=TextMuted,fontSize=11.sp) }
                    IconButton(onClick={}){Icon(Icons.Default.Edit,null,tint=Accent)}
                    Switch(checked=true,onCheckedChange={})
                }
            }
        }
    }
}

@Composable
fun AdminAddWallpaperScreen(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel) {
    var title by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(vm.categories.first()) }
    var resolution by remember { mutableStateOf(vm.resolutions[2]) }
    var saved by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().background(Background).padding(18.dp), contentPadding=PaddingValues(bottom=24.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
        item { Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick={nav.popBackStack()}){Icon(Icons.Default.ArrowBack,null)};Text("Yeni Duvar Kâğıdı Ekle",fontSize=23.sp,fontWeight=FontWeight.Bold)} }
        item {
            Card(shape=RoundedCornerShape(20.dp), border=BorderStroke(1.dp, Accent.copy(alpha=.3f)), colors=CardDefaults.cardColors(containerColor=Surface)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CloudUpload,null,tint=Accent,modifier=Modifier.size(52.dp)); Spacer(Modifier.height(9.dp)); Text("Görsel bağlantısı ekle",fontWeight=FontWeight.Bold); Text("Yüksek kaliteli doğrudan resim URL'si",color=TextMuted,fontSize=12.sp)
                }
            }
        }
        item { OutlinedTextField(title,{title=it},label={Text("Başlık")},placeholder={Text("Örn: Gizli Şelale")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item { OutlinedTextField(url,{url=it},label={Text("Görsel bağlantısı")},placeholder={Text("https://...")},modifier=Modifier.fillMaxWidth(),singleLine=true) }
        item {
            Text("Kategori",fontWeight=FontWeight.SemiBold)
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(top=7.dp)) {
                items(vm.categories){ name -> FilterChip(selected=category==name,onClick={category=name},label={Text(name)}) }
            }
        }
        item {
            Text("Çözünürlük",fontWeight=FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) { vm.resolutions.forEach { option -> FilterChip(selected=resolution==option,onClick={resolution=option},label={Text(option.label)},modifier=Modifier.weight(1f)) } }
        }
        item { SwitchRow("Aktif", true) }
        item {
            Button(onClick={vm.addWallpaper(title,category,url,resolution);saved=true}, enabled=title.isNotBlank()&&url.startsWith("http"), modifier=Modifier.fillMaxWidth().height(54.dp), shape=RoundedCornerShape(16.dp)) { Text("Kaydet") }
        }
        if(saved) item { Text("Duvar kâğıdı eklendi. Kategori ve çözünürlük seçimi kaydedildi.",color=Color(0xFF39D6A3)) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean) {
    Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Surface),modifier=Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(label,modifier=Modifier.weight(1f));Switch(checked=checked,onCheckedChange={})} }
}
@Composable fun AdminStat(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color){Card(shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Surface)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,color=TextMuted,fontSize=10.sp);Text(value,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("↗ +8%",color=Color(0xFF39D6A3),fontSize=10.sp)};Icon(icon,null,tint=tint)}}}
@Composable fun AdminAction(modifier:Modifier,title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color,onClick:()->Unit){Card(onClick=onClick,modifier=modifier.padding(bottom=8.dp).height(68.dp),shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=tint.copy(alpha=.18f))){Row(Modifier.fillMaxSize().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=tint);Spacer(Modifier.width(8.dp));Text(title,fontSize=11.sp)}}}

