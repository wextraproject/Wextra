package com.wextra.wallpapers

import android.app.WallpaperManager
import android.content.Context
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.content.ContentValues
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import java.net.HttpURLConnection
import org.json.JSONArray
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import kotlinx.coroutines.delay
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument

private val Background = androidx.compose.ui.graphics.Color(0xFF07101F)
private val Surface = androidx.compose.ui.graphics.Color(0xFF101E31)
private val Accent = androidx.compose.ui.graphics.Color(0xFF6572FF)
private val TextMuted = androidx.compose.ui.graphics.Color(0xFF9EABC0)
private val CategoryColors = listOf(
    Color(0xFF39D6A3),
    Color(0xFF8B7BFF),
    Color(0xFFFF7AA8),
    Color(0xFFFFB457),
    Color(0xFF4CB7FF)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { WextraTheme { WextraApp() } }
    }
}

@Composable
fun WextraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Background,
            surface = Surface,
            onPrimary = androidx.compose.ui.graphics.Color.White,
            onBackground = androidx.compose.ui.graphics.Color.White,
            onSurface = androidx.compose.ui.graphics.Color.White
        ),
        content = content
    )
}

data class Wallpaper(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String
)

data class ResolutionOption(val label: String, val detail: String, val width: Int)

class WallpaperViewModel : androidx.lifecycle.ViewModel() {
    private val wallpapersKey = "favorite_wallpapers"

    val wallpapers = listOf(
        Wallpaper("1","Dağ Manzarası","Doğa","https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1800"),
        Wallpaper("2","Yıldız Bulutsusu","Yıldızlar","https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=1800"),
        Wallpaper("3","Gün Batımı","Doğa","https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=1800"),
        Wallpaper("4","Gece Şehri","Şehir","https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=1800"),
        Wallpaper("5","Orman Işıltısı","Doğa","https://images.unsplash.com/photo-1448375240586-882707db888b?w=1800"),
        Wallpaper("6","Spor Araba","Araçlar","https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=1800"),
        Wallpaper("7","Kuzey Işıkları","Doğa","https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=1800"),
        Wallpaper("8","Göl Kenarı","Doğa","https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1800"),
        Wallpaper("9","Soyut Dalga","Minimal","https://images.unsplash.com/photo-1557683316-973673baf926?w=1800")
    )

    val resolutions = listOf(
        ResolutionOption("1080P", "FHD", 1080),
        ResolutionOption("2K", "1440p", 1440),
        ResolutionOption("4K", "2160p", 2160),
        ResolutionOption("8K", "4320p", 4320)
    )

    var selectedResolution by mutableStateOf(resolutions[1])
        private set
    fun selectResolution(option: ResolutionOption) { selectedResolution = option }

    var favorites by mutableStateOf(setOf<String>())
        private set
    var randomWallpaperId by mutableStateOf(wallpapers.first().id)
        private set

    fun loadFavorites(context: Context) {
        val prefs = context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE)
        favorites = prefs.getStringSet(wallpapersKey, emptySet()) ?: emptySet()
    }
    fun toggleFavorite(id: String, context: Context) {
        favorites = if (id in favorites) favorites - id else favorites + id
        context.getSharedPreferences("wextra_prefs", Context.MODE_PRIVATE).edit().putStringSet(wallpapersKey, favorites).apply()
    }
    fun pickRandom() { if (wallpapers.isNotEmpty()) randomWallpaperId = wallpapers.random().id }
    fun dailyWallpaper(): Wallpaper {
        val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        return wallpapers[day % wallpapers.size]
    }
    fun imageFor(item: Wallpaper): String = item.imageUrl.substringBefore("?") + "?w=${selectedResolution.width}&q=90"
}

@Composable
fun WextraApp(vm: WallpaperViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { vm.loadFavorites(context) }
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "splash") {
        composable("splash") { SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
        composable("home") { MainScaffold(nav, vm, "home") { HomeScreen(vm, nav) } }
        composable("categories") { MainScaffold(nav, vm, "categories") { CategoriesScreen(vm, nav) } }
        composable("favorites") { MainScaffold(nav, vm, "favorites") { FavoritesScreen(vm, nav) } }
        composable("profile") { MainScaffold(nav, vm, "profile") { ProfileScreen(nav) } }
        composable("detail/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) {
            val item = vm.wallpapers.first { w -> w.id == it.arguments?.getString("id") }
            DetailScreen(item, vm, item.id in vm.favorites, { vm.toggleFavorite(item.id, context) }, nav)
        }
        composable("login") { LoginScreen(nav) }
        composable("register") { RegisterScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
    }
}

@Composable
fun SplashScreen(onStart: () -> Unit) {
    var introStarted by remember { mutableStateOf(false) }
    val logoScale by animateFloatAsState(
        targetValue = if (introStarted) 1.55f else 1f,
        animationSpec = tween(750),
        label = "logoScale"
    )
    val contentAlpha by animateFloatAsState(
        targetValue = if (introStarted) 0f else 1f,
        animationSpec = tween(420),
        label = "contentAlpha"
    )

    LaunchedEffect(introStarted) {
        if (introStarted) {
            delay(1050)
            onStart()
        }
    }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color(0xFF060A19), Color(0xFF11102A), Color(0xFF07101F))
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        // Intro geçişinde ekranda büyüyen W logosu kalır.
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 28.dp)
        ) {
            Spacer(Modifier.weight(1f))
            Image(
                painter = painterResource(id = R.drawable.wextra_logo),
                contentDescription = "Wextra logosu",
                modifier = Modifier.size(132.dp).graphicsLayer {
                    scaleX = logoScale
                    scaleY = logoScale
                    alpha = if (introStarted) 1f else 1f
                }
            )
            AnimatedVisibility(
                visible = !introStarted,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut(animationSpec = tween(350)) + scaleOut(targetScale = .96f)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(18.dp))
                    Text("Wextra", fontSize = 42.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Hayalindeki duvar kâğıtları şimdi cebinde!",
                        color = TextMuted,
                        fontSize = 17.sp
                    )
                }
            }
            AnimatedVisibility(
                visible = introStarted,
                enter = fadeIn(animationSpec = tween(250, delayMillis = 250))
            ) {
                Text(
                    "Keşfetmeye hazır mısın?",
                    color = Color.White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 26.dp)
                )
            }
            Spacer(Modifier.weight(1f))
            if (!introStarted) {
                Button(
                    onClick = { introStarted = true },
                    modifier = Modifier.fillMaxWidth().height(60.dp).graphicsLayer { alpha = contentAlpha },
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Text("Başla", fontSize = 18.sp)
                    Spacer(Modifier.width(10.dp))
                    Icon(Icons.Default.ArrowForward, null)
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
fun MainScaffold(nav: androidx.navigation.NavHostController, vm: WallpaperViewModel, selected: String, content: @Composable () -> Unit) {
    Scaffold(
        containerColor = Background,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                listOf(
                    Triple("home","Ana Sayfa",Icons.Default.Home),
                    Triple("categories","Kategoriler",Icons.Default.GridView),
                    Triple("favorites","Favoriler",Icons.Default.Favorite),
                    Triple("profile","Profil",Icons.Default.Person)
                ).forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = selected == route,
                        onClick = { if (selected != route) nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, null) },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding -> Box(Modifier.padding(padding)) { content() } }
}

@Composable
fun HomeScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    val filtered = vm.wallpapers.filter { it.title.contains(query, true) || it.category.contains(query, true) }
    val daily = vm.dailyWallpaper()
    val categoryInfo = listOf(
        "Doğa" to Icons.Default.Landscape,
        "Yıldızlar" to Icons.Default.AutoAwesome,
        "Şehir" to Icons.Default.LocationCity,
        "Araçlar" to Icons.Default.DirectionsCar,
        "Minimal" to Icons.Default.Eco
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(id = R.drawable.wextra_logo), contentDescription = "Wextra logosu", modifier = Modifier.size(52.dp))
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Wextra", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text("Bugün ne keşfetmek istersin?", color = TextMuted, fontSize = 14.sp)
            }
            IconButton(onClick = { searching = !searching }) { Icon(Icons.Default.Search, "Ara", modifier = Modifier.size(28.dp)) }
        }
        if (searching) {
            OutlinedTextField(value = query, onValueChange = { query = it }, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Duvar kâğıdı ara") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(8.dp))

        Card(modifier = Modifier.fillMaxWidth().height(150.dp).clickable { nav.navigate("detail/${daily.id}") }, shape = RoundedCornerShape(22.dp)) {
            Box {
                AsyncImage(vm.imageFor(daily), daily.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Surface(color = Background.copy(alpha = .55f), shape = RoundedCornerShape(10.dp), modifier = Modifier.padding(14.dp).align(Alignment.TopStart)) {
                    Text("✨ Günün Duvar Kâğıdı", color = Accent, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(daily.title, modifier = Modifier.padding(14.dp).align(Alignment.BottomStart), fontWeight = FontWeight.Bold, fontSize = 24.sp)
                FilledTonalIconButton(onClick = { nav.navigate("detail/${daily.id}") }, modifier = Modifier.padding(14.dp).align(Alignment.CenterEnd)) { Icon(Icons.Default.Download, null) }
            }
        }
        Spacer(Modifier.height(10.dp))
        FilledTonalButton(onClick = { vm.pickRandom(); nav.navigate("detail/${vm.randomWallpaperId}") }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(8.dp)); Text("Rastgele Duvar Kâğıdı")
        }
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categoryInfo.forEachIndexed { index, (name, icon) ->
                val categoryColor = CategoryColors[index % CategoryColors.size]
                Card(
                    modifier = Modifier.weight(1f).height(62.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = categoryColor.copy(alpha = 0.16f))
                ) {
                    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(icon, null, tint = categoryColor, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.height(3.dp))
                        Text(name, fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Popüler 🔥", fontWeight = FontWeight.Bold, fontSize = 21.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { nav.navigate("categories") }) { Text("Tümünü Gör") }
        }
        WallpaperGrid(filtered, vm, nav, Modifier.weight(1f))
        Spacer(Modifier.height(8.dp))
        ResolutionSelector(vm)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
fun ResolutionSelector(vm: WallpaperViewModel) {
    Card(
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Surface.copy(alpha = 0.94f))
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text("Çözünürlük", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("İndirme kalitesi", color = TextMuted, fontSize = 9.sp)
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                vm.resolutions.forEachIndexed { index, option ->
                    val selected = vm.selectedResolution == option
                    val tone = CategoryColors[index % CategoryColors.size]
                    FilledTonalButton(
                        onClick = { vm.selectResolution(option) },
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(horizontal = 1.dp, vertical = 0.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (selected) tone.copy(alpha = 0.32f) else tone.copy(alpha = 0.10f),
                            contentColor = if (selected) Color.White else tone
                        )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(option.label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(option.detail, fontSize = 7.sp, color = if (selected) Color.White.copy(alpha = 0.8f) else tone.copy(alpha = 0.85f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WallpaperGrid(items: List<Wallpaper>, vm: WallpaperViewModel, nav: androidx.navigation.NavHostController, modifier: Modifier = Modifier) {
    LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = modifier.fillMaxWidth()) {
        items(items) { item ->
            Card(modifier = Modifier.fillMaxWidth().aspectRatio(.72f).clickable { nav.navigate("detail/${item.id}") }, shape = RoundedCornerShape(14.dp)) {
                Box {
                    AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Icon(Icons.Default.FavoriteBorder, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(7.dp).align(Alignment.TopEnd).size(20.dp))
                    Surface(color = Background.copy(alpha = .72f), modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()) {
                        Column(Modifier.padding(7.dp)) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                            Text(vm.selectedResolution.label, color = Accent, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoriesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val orderedNames = listOf("Doğa", "Yıldızlar", "Şehir", "Araçlar", "Minimal")
    val icons = listOf(Icons.Default.Landscape, Icons.Default.AutoAwesome, Icons.Default.LocationCity, Icons.Default.DirectionsCar, Icons.Default.Eco)
    val categories = orderedNames.mapNotNull { name ->
        vm.wallpapers.filter { it.category == name }.takeIf { it.isNotEmpty() }?.let { name to it }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Kategoriler", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("En iyi duvar kâğıtlarını kategorilere göre keşfet", color = TextMuted, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(categories) { (name, list) ->
                val index = orderedNames.indexOf(name)
                val tone = CategoryColors[index % CategoryColors.size]
                Card(
                    modifier = Modifier.height(205.dp).clickable { nav.navigate("detail/${list.first().id}") },
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, tone.copy(alpha = .75f)),
                    colors = CardDefaults.cardColors(containerColor = Surface)
                ) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(list.first().imageUrl, name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Surface(
                            color = tone.copy(alpha = .25f),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.padding(10.dp).size(42.dp).align(Alignment.TopCenter)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(icons[index], null, tint = Color.White, modifier = Modifier.size(23.dp))
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().height(72.dp).align(Alignment.BottomCenter)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, Background.copy(alpha = .92f))))
                        ) {
                            Column(Modifier.padding(horizontal = 11.dp, vertical = 9.dp).align(Alignment.BottomStart)) {
                                Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("• ${list.size}", color = Color.White.copy(alpha = .78f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FavoritesScreen(vm: WallpaperViewModel, nav: androidx.navigation.NavHostController) {
    val list = vm.wallpapers.filter { it.id in vm.favorites }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Favoriler", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Henüz favori duvar kâğıdın yok.", color = TextMuted)
            }
        } else WallpaperGrid(list, vm, nav, Modifier.fillMaxSize())
    }
}


private suspend fun loadWallpaperBitmap(url: String): Bitmap? = withContext(Dispatchers.IO) {
    try {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.doInput = true
        connection.connect()
        connection.inputStream.use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) {
        null
    }
}

private suspend fun saveWallpaperToGallery(context: Context, item: Wallpaper, imageUrl: String): Boolean =
    withContext(Dispatchers.IO) {
        try {
            val bitmap = loadWallpaperBitmap(imageUrl) ?: return@withContext false
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Wextra_${item.title.replace(" ", "_")}_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Wextra")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext false

            resolver.openOutputStream(uri)?.use { output ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)
            } ?: return@withContext false

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

private suspend fun applyWallpaper(context: Context, item: Wallpaper, imageUrl: String, which: Int): Boolean =
    withContext(Dispatchers.IO) {
        try {
            val bitmap = loadWallpaperBitmap(imageUrl) ?: return@withContext false
            val manager = WallpaperManager.getInstance(context)
            manager.setBitmap(bitmap, null, true, which)
            true
        } catch (_: Exception) {
            false
        }
    }

@Composable
fun DetailScreen(item: Wallpaper, vm: WallpaperViewModel, isFavorite: Boolean, onFavorite: () -> Unit, nav: androidx.navigation.NavHostController) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var showWallpaperChoice by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }

    if (showWallpaperChoice) {
        AlertDialog(
            onDismissRequest = { if (!working) showWallpaperChoice = false },
            title = { Text("Duvar kâğıdı yap") },
            text = { Text("Nerede kullanmak istiyorsun?") },
            confirmButton = {
                TextButton(
                    enabled = !working,
                    onClick = {
                        working = true
                        scope.launch {
                            val ok = applyWallpaper(context, item, vm.imageFor(item), WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
                            working = false
                            showWallpaperChoice = false
                            Toast.makeText(context, if (ok) "Duvar kâğıdı ayarlandı" else "Duvar kâğıdı ayarlanamadı", Toast.LENGTH_LONG).show()
                        }
                    }
                ) { Text("Her ikisi") }
            },
            dismissButton = {
                Row {
                    TextButton(
                        enabled = !working,
                        onClick = {
                            working = true
                            scope.launch {
                                val ok = applyWallpaper(context, item, vm.imageFor(item), WallpaperManager.FLAG_SYSTEM)
                                working = false
                                showWallpaperChoice = false
                                Toast.makeText(context, if (ok) "Ana ekran duvar kâğıdı ayarlandı" else "İşlem başarısız oldu", Toast.LENGTH_LONG).show()
                            }
                        }
                    ) { Text("Ana ekran") }
                    TextButton(
                        enabled = !working,
                        onClick = {
                            working = true
                            scope.launch {
                                val ok = applyWallpaper(context, item, vm.imageFor(item), WallpaperManager.FLAG_LOCK)
                                working = false
                                showWallpaperChoice = false
                                Toast.makeText(context, if (ok) "Kilit ekranı duvar kâğıdı ayarlandı" else "İşlem başarısız oldu", Toast.LENGTH_LONG).show()
                            }
                        }
                    ) { Text("Kilit ekranı") }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize().background(Background)) {
        Box(Modifier.fillMaxWidth().weight(1f)) {
            AsyncImage(vm.imageFor(item), item.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.padding(18.dp).align(Alignment.TopStart)) {
                Icon(Icons.Default.ArrowBack, null)
            }
            IconButton(onClick = onFavorite, modifier = Modifier.padding(18.dp).align(Alignment.TopEnd)) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (isFavorite) Accent else androidx.compose.ui.graphics.Color.White)
            }
        }
        Column(Modifier.padding(20.dp)) {
            Text(item.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(item.category, color = TextMuted)
            Text("Seçilen kalite: ${vm.selectedResolution.label} • ${vm.selectedResolution.detail}", color = Accent, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))

            Button(
                enabled = !working,
                onClick = { showWallpaperChoice = true },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Wallpaper, null)
                Spacer(Modifier.width(8.dp))
                Text(if (working) "İşleniyor..." else "Duvar Kâğıdı Yap")
            }

            Spacer(Modifier.height(10.dp))

            OutlinedButton(
                enabled = !working,
                onClick = {
                    working = true
                    scope.launch {
                        val ok = saveWallpaperToGallery(context, item, vm.imageFor(item))
                        working = false
                        Toast.makeText(
                            context,
                            if (ok) "Resim Galeri > Pictures > Wextra klasörüne indirildi"
                            else "İndirme başarısız oldu. İnternet bağlantını kontrol et.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Download, null)
                Spacer(Modifier.width(8.dp))
                Text(if (working) "İşleniyor..." else "İndir")
            }
        }
    }
}

@Composable
fun ProfileScreen(nav: androidx.navigation.NavHostController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Profil", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(22.dp))
        Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(64.dp), tint = Accent)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Misafir Kullanıcı", fontWeight = FontWeight.Bold)
                    Text("Firebase ile giriş yapabilirsin", color = TextMuted, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { nav.navigate("login") }, modifier = Modifier.fillMaxWidth()) { Text("Giriş Yap / Kayıt Ol") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { nav.navigate("settings") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Settings, null)
            Spacer(Modifier.width(8.dp))
            Text("Ayarlar")
        }
    }
}

@Composable
fun LoginScreen(nav: androidx.navigation.NavHostController) {
    AuthScreen(title = "Giriş Yap", action = "Giriş Yap", secondary = "Hesabın yok mu? Kayıt Ol", onAction = { nav.navigate("home") }, onSecondary = { nav.navigate("register") })
}

@Composable
fun RegisterScreen(nav: androidx.navigation.NavHostController) {
    AuthScreen(title = "Kayıt Ol", action = "Kayıt Ol", secondary = "Zaten hesabın var mı? Giriş Yap", onAction = { nav.navigate("home") }, onSecondary = { nav.navigate("login") })
}

@Composable
fun AuthScreen(title: String, action: String, secondary: String, onAction: () -> Unit, onSecondary: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(70.dp))
        Image(
            painter = painterResource(id = R.drawable.wextra_logo),
            contentDescription = "Wextra logosu",
            modifier = Modifier.size(72.dp)
        )
        Text("Wextra", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(email, { email = it }, label = { Text("E-posta adresi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Şifre") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAction, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text(action) }
        TextButton(onClick = onSecondary) { Text(secondary) }
        Text("Firebase bağlantısından sonra gerçek giriş aktif olur.", color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(nav: androidx.navigation.NavHostController) {
    var notifications by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Ayarlar", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Bildirimler", fontWeight = FontWeight.Bold)
                    Text("Yeni duvar kâğıtlarından haberdar ol", color = TextMuted, fontSize = 12.sp)
                }
                Switch(checked = notifications, onCheckedChange = { notifications = it })
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Duvar kâğıdı ayarlama", fontWeight = FontWeight.Bold)
                Text("Gerçek duvar kâğıdı seçimi Android API ile sonraki sürümde tamamlanabilir.", color = TextMuted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        OutlinedButton(onClick = { nav.navigate("home") }, modifier = Modifier.fillMaxWidth()) {
            Text("Ana Sayfaya Dön")
        }
    }
}
