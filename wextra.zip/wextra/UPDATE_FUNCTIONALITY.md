# Wextra – İşlevsel Güncelleme

Bu pakette aşağıdaki işlevler eklendi:

- Ayarlar kalıcı olarak cihazda saklanır: koyu/açık tema, renk teması, çözünürlük, Wi‑Fi tercihi, bildirimler, günün duvar kâğıdı, animasyon ve dil.
- E-posta ile kayıt/giriş demo olarak çalışır ve oturum cihazda tutulur.
- Profil ekranı oturum durumunu ve çıkış işlemini kullanır.
- Admin paneline doğrudan erişim engellenmiştir; önce admin girişi gerekir.
- Admin demo hesabı: `admin@wextra.app` / `WextraAdmin2026`.
- Duvar kâğıdını galeriye indirme kodu kaldırıldı. Uygulama içinde önizleme ve duvar kâğıdı olarak uygulama işlemi devam eder.
- Google ile giriş düğmesi eklendi ancak gerçek OAuth için Firebase/Google yapılandırma dosyaları gerekir.

## Önemli güvenlik notu
Bu sürümde e-posta giriş sistemi yerel demo modundadır. Gerçek yayın sürümünde şifreler SharedPreferences içinde tutulmamalıdır. Firebase Authentication veya başka güvenli bir sunucu tarafı kimlik doğrulama sistemi kullanılmalıdır.

## Firebase ile gerçek giriş için gerekli dosya
`app/google-services.json` dosyası ve Firebase projesi bu ZIP'e dahil değildir. Bu dosya kullanıcıya/uygulama sahibine özeldir. Firebase projesi bağlandığında:

1. Email/Password provider açılır.
2. Google provider açılır.
3. Android uygulamasının SHA-1/SHA-256 değerleri eklenir.
4. Firebase Authentication ve Credential Manager/Google Identity bağımlılıkları etkinleştirilir.
5. Admin yetkileri istemci e-postasına göre değil Firebase Custom Claims veya güvenli sunucu tarafı kurallarıyla verilir.

Bu nedenle bu ZIP, arayüz ve yerel işlevleri çalışır hale getirilmiş proje sürümüdür; gerçek Google/Firebase oturumu için sahibinin Firebase yapılandırması ayrıca gereklidir.
