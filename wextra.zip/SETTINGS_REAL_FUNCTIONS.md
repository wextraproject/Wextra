# WEXTRA Settings Functional Update

- Theme/accent/text choices are persisted and dynamic accent can be disabled.
- Preview resolution is persisted and used by remote image URLs.
- Automatic wallpaper change is a real daily AlarmManager action at around 09:00 and applies the day's bundled wallpaper to the home screen.
- Notification permission is requested on Android 13+ and daily wallpaper notifications are emitted when enabled.
- Compact mode changes the main wallpaper grid from 2 to 3 columns.
- Content preference categories are persisted and used by the home "Picked for You" section.
- Privacy app-permission row opens Android app settings.
- About page feedback/share/rate/contact actions now perform real intents.
- Settings state is persisted in SharedPreferences.
