# wextra

Modern Android wallpaper application starter.

## Features
- Dark modern UI
- Home, Categories, Favorites, Profile
- Search wallpapers
- Wallpaper detail screen
- Favorite system (local)
- Set image as Android wallpaper
- Login/Register demo screens
- Firebase-ready architecture
- GitHub-ready project structure

## Technology
- Kotlin
- Jetpack Compose + Material 3
- Navigation Compose
- Coil
- MVVM-style ViewModel state
- Firebase setup guide included

## Open in Android Studio
1. Extract the ZIP.
2. Open the `wextra` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android emulator/device.

## Firebase
This starter compiles without a Firebase project. To connect Firebase:

1. Create a Firebase project.
2. Add Android app package: `com.wextra.wallpaper`
3. Download `google-services.json` into `app/`.
4. Add Google Services and Firebase dependencies as described in `FIREBASE_SETUP.md`.

Do not upload `google-services.json` to a public GitHub repository.

## Suggested Firestore collections
- `wallpapers`
- `categories`
- `users`

## License
Choose your own license before publishing.
