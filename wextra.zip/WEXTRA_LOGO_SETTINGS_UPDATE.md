# WEXTRA Logo + Settings Update

- Eclipse logo is now the default WEXTRA logo for APK/application icon and in-app branding.
- Settings was redesigned around the supplied reference image with separate Appearance, Wallpaper, Notifications, Content Preferences, Account & Data, Privacy & Security, and About screens.
- UI accent/text colors now use a controlled Eclipse palette so the interface stays visually consistent with the logo.
- Default accent is Eclipse Purple and default theme is Gece Eclipse.
- Wallpaper download UI was not added.
