package com.wextra.wallpaper;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class MainActivity extends AppCompatActivity {

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Firebase yapılandırmasının uygulama açılırken doğrulanması için örnek örnekler.
        FirebaseFirestore.getInstance();
        FirebaseStorage.getInstance();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(11, 15, 23));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);

        TextView title = text("Wextra", 30, Color.rgb(210, 190, 255));
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = text("Duvar Kâğıdı Uygulaması", 15, Color.rgb(170, 180, 195));
        LinearLayout.LayoutParams subtitleLp = new LinearLayout.LayoutParams(-1, -2);
        subtitleLp.topMargin = dp(3);
        root.addView(subtitle, subtitleLp);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(rounded(Color.rgb(27, 38, 55), 20));
        LinearLayout.LayoutParams heroLp = new LinearLayout.LayoutParams(-1, -2);
        heroLp.topMargin = dp(22);
        root.addView(hero, heroLp);

        TextView heroTitle = text("Doğayı Keşfet", 23, Color.WHITE);
        heroTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        hero.addView(heroTitle);

        TextView heroSub = text("En güzel duvar kâğıtlarını keşfet", 14, Color.rgb(205, 212, 224));
        LinearLayout.LayoutParams heroSubLp = new LinearLayout.LayoutParams(-1, -2);
        heroSubLp.topMargin = dp(6);
        hero.addView(heroSub, heroSubLp);

        TextView explore = text("Keşfet  →", 15, Color.WHITE);
        explore.setGravity(Gravity.CENTER);
        explore.setBackground(rounded(Color.rgb(105, 74, 210), 14));
        LinearLayout.LayoutParams exploreLp = new LinearLayout.LayoutParams(dp(130), dp(48));
        exploreLp.topMargin = dp(16);
        hero.addView(explore, exploreLp);
        explore.setOnClickListener(v -> Toast.makeText(this, "Yakında eklenecek", Toast.LENGTH_SHORT).show());

        TextView section = text("Kategoriler", 20, Color.WHITE);
        section.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams sectionLp = new LinearLayout.LayoutParams(-1, -2);
        sectionLp.topMargin = dp(26);
        root.addView(section, sectionLp);

        String[] categories = {"🌿  Doğa", "🚗  Araba", "🏙️  Şehir", "🪐  Uzay", "◼️  Minimal", "✨  Soyut"};
        for (String name : categories) {
            TextView card = text(name, 17, Color.WHITE);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(16), 0, dp(16), 0);
            card.setBackground(rounded(Color.rgb(22, 29, 41), 16));
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, dp(58));
            cardLp.topMargin = dp(10);
            root.addView(card, cardLp);
        }

        TextView footer = text("Firebase bağlı • Wextra", 13, Color.rgb(130, 140, 155));
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(-1, -2);
        footerLp.topMargin = dp(28);
        root.addView(footer, footerLp);

        setContentView(scroll);
    }
}
