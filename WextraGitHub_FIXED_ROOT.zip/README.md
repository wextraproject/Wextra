# Wextra - GitHub Build Edition

Bu ZIP'in içindeki dosyaları GitHub repository kök dizinine yükleyin.

## Önemli
GitHub ana sayfasında doğrudan şunlar görünmelidir:
- app
- .github
- build.gradle
- settings.gradle
- gradle.properties

`WextraGitHubFixed/app/...` şeklinde ekstra bir klasör oluşmamalıdır.

## Build
Actions > Build Wextra APK > Run workflow.
Başarılı olursa Artifacts bölümünde `Wextra-debug-apk` oluşur.

## Firebase
`app/google-services.json` projeye eklenmiştir.
