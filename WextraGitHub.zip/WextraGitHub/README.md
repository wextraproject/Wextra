# Wextra

GitHub Actions ile APK derlemek için hazırlanmış basit Android duvar kâğıdı uygulaması.

## Önemli
Bu proje **GitHub Actions üzerinden build almak için** Gradle 8.7 ve JDK 17 kullanır.

## GitHub'da kullanım
1. Yeni bir GitHub repository oluştur.
2. Bu ZIP'in içindeki dosyaları repository köküne yükle.
3. `Actions` sekmesine gir.
4. `Build Wextra APK` iş akışını çalıştır.
5. İşlem başarılı olursa `Artifacts` bölümünden `Wextra-debug-apk` dosyasını indir.

## Firebase
`app/google-services.json` dosyası projede bulunur ve paket adı:
`com.wextra.wallpaper`

Repository'yi herkese açık yapacaksan Firebase güvenlik kurallarını ayrıca yapılandır.
