package com.wextra.wallpaper;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class MainActivity extends AppCompatActivity {

    private final int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Firebase instances are initialized here. They do not perform any write operation.
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseStorage storage = FirebaseStorage.getInstance();

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.rgb(11, 14, 20));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(24));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("Wextra");
        title.setTextSize(30);
        title.setTextColor(Color.rgb(220, 210, 255));
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Duvar kâğıdını keşfet");
        subtitle.setTextSize(16);
        subtitle.setTextColor(Color.rgb(161, 161, 170));
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = dp(4);
        root.addView(subtitle, subtitleParams);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(20), dp(20), dp(20));
        hero.setBackground(bg(Color.rgb(30, 38, 55), 22));
        LinearLayout.LayoutParams heroParams = new LinearLayout.LayoutParams(-1, -2);
        heroParams.topMargin = dp(24);
        root.addView(hero, heroParams);

        TextView heroTitle = new TextView(this);
        heroTitle.setText("Doğayı Keşfet");
        heroTitle.setTextSize(24);
        heroTitle.setTextColor(Color.WHITE);
        hero.addView(heroTitle);

        TextView heroText = new TextView(this);
        heroText.setText("Wextra'nın ilk çalışan sürümü");
        heroText.setTextSize(14);
        heroText.setTextColor(Color.rgb(200, 205, 215));
        LinearLayout.LayoutParams heroTextParams = new LinearLayout.LayoutParams(-1, -2);
        heroTextParams.topMargin = dp(6);
        hero.addView(heroText, heroTextParams);

        Button button = new Button(this);
        button.setText("KEŞFET");
        button.setTextColor(Color.WHITE);
        button.setBackground(bg(Color.rgb(104, 73, 220), 16));
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, dp(50));
        buttonParams.topMargin = dp(16);
        hero.addView(button, buttonParams);

        TextView section = new TextView(this);
        section.setText("Kategoriler");
        section.setTextSize(19);
        section.setTextColor(Color.WHITE);
        section.setTypeface(null, 1);
        LinearLayout.LayoutParams sectionParams = new LinearLayout.LayoutParams(-1, -2);
        sectionParams.topMargin = dp(28);
        root.addView(section, sectionParams);

        String[] categories = {"🌿  Doğa", "🚗  Araba", "🏙  Şehir", "🪐  Uzay", "◼  Minimal", "✨  Soyut"};
        for (String category : categories) {
            TextView item = new TextView(this);
            item.setText(category);
            item.setTextSize(16);
            item.setTextColor(Color.WHITE);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(16), 0, dp(16), 0);
            item.setBackground(bg(Color.rgb(21, 26, 36), 16));
            LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(-1, dp(58));
            itemParams.topMargin = dp(10);
            root.addView(item, itemParams);
        }

        TextView footer = new TextView(this);
        footer.setText("Firebase hazır • Wextra v1.0");
        footer.setTextColor(Color.rgb(120, 120, 130));
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = new LinearLayout.LayoutParams(-1, -2);
        footerParams.topMargin = dp(26);
        root.addView(footer, footerParams);

        setContentView(scrollView);
    }
}
